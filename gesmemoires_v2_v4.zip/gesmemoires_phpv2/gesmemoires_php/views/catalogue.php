<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/RechercheService.php';

AuthService::requireLogin();
$user = AuthService::getCurrentUser();

$q       = trim($_GET['q']       ?? '');
$domaine = trim($_GET['domaine'] ?? '');

$memoires = RechercheService::getCatalogue($q ?: null);
// Filtrer par domaine côté PHP si demandé (domaine n'existe pas en BDD)
// $domaine ignoré — filtre supprimé

$dashboard_link = match($user['role']) {
    'etudiant'   => 'dashboard_etudiant.php',
    'professeur' => 'dashboard_professeur.php',
    'de'         => 'dashboard_de.php',
    default      => '#'
};

$title = 'Catalogue'; $base = '../';
include __DIR__ . '/partials/head.php';
include __DIR__ . '/partials/navbar.php';
?>

<div class="dashboard">
  <aside class="sidebar">
    <div class="sidebar-section-title">Navigation</div>
    <nav class="sidebar-nav">
      <a href="<?= $dashboard_link ?>">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Tableau de bord
      </a>
      <a href="catalogue.php" class="active">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        Catalogue
      </a>
    </nav>
    <div class="sidebar-section-title" style="margin-top:24px">Compte</div>
    <nav class="sidebar-nav">
      <a href="logout.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Déconnexion
      </a>
    </nav>
  </aside>

  <main class="main-content">
    <div class="flex justify-between items-center mb-4">
      <div>
        <div class="page-title">Catalogue des mémoires</div>
        <div class="page-subtitle"><?= count($memoires) ?> mémoire(s) trouvé(s)</div>
      </div>
    </div>

    <!-- Barre de recherche -->
    <form method="GET" action="" class="card mb-6" style="padding:16px">
      <div class="flex gap-3">
        <input class="form-control" type="text" name="q"
               placeholder="Rechercher par titre..."
               value="<?= htmlspecialchars($q) ?>" style="flex:1"/>
        <button type="submit" class="btn btn-primary">Rechercher</button>
        <?php if ($q): ?>
          <a href="catalogue.php" class="btn btn-secondary">Réinitialiser</a>
        <?php endif; ?>
      </div>
    </form>

    <!-- Grille mémoires -->
    <?php if (empty($memoires)): ?>
      <div class="card text-center" style="padding:60px">
        <div style="font-size:40px;margin-bottom:12px">📚</div>
        <p style="font-weight:600;font-size:15px;color:var(--primary)">Aucun mémoire trouvé</p>
        <p class="text-muted text-sm mt-2">Essayez d'autres mots-clés</p>
        <a href="catalogue.php" class="btn btn-secondary mt-4">Voir tous les mémoires</a>
      </div>
    <?php else: ?>
      <div class="memoir-grid">
        <?php foreach ($memoires as $m): ?>
          <div class="memoir-card">
            <div class="flex justify-between items-center mb-3">
              <span class="badge <?= $m['statut'] === 'archive' ? 'badge-archive' : 'badge-valide' ?>">
                <?= $m['statut'] === 'archive' ? 'Archive' : 'Validé' ?>
              </span>
              <span class="text-sm text-muted"><?= $m['annee'] ?></span>
            </div>

            <h3 style="font-size:14px;font-weight:700;color:var(--primary);margin-bottom:8px;line-height:1.4">
              <?= htmlspecialchars($m['titre']) ?>
            </h3>

            <div class="text-sm text-muted" style="margin-bottom:12px">
              <?php if (!empty($m['etudiant_nom'])): ?>
                <div>Par : <strong style="color:var(--on-surface)"><?= htmlspecialchars($m['etudiant_nom']) ?></strong></div>
              <?php endif; ?>
            </div>

            <div class="flex gap-2" style="border-top:1px solid var(--outline-variant);padding-top:12px;margin-top:auto">
              <?php if ($m['fichier']): ?>
                <a href="download.php?id=<?= $m['id_memoire'] ?>" target="_blank"
                   class="btn btn-primary btn-sm" style="flex:1;justify-content:center">
                  Lire le mémoire
                </a>
              <?php else: ?>
                <span class="text-sm text-muted" style="align-self:center">Fichier non disponible</span>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
