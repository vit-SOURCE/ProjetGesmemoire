<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/MemoireService.php';

AuthService::requireRole('professeur');
$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();
$matricule = $role_data['Prof_matricule'];
$memoires  = MemoireService::getMemoiresProfesseur($matricule);

// Traitement annotation/validation/rejet
$message = ''; $msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action      = $_POST['action']      ?? '';
    $id_memoire  = (int)($_POST['id_memoire'] ?? 0);
    $commentaire = trim($_POST['commentaire'] ?? '');

    $result = match($action) {
        'valider'      => MemoireService::valider($id_memoire, $commentaire),
        'rejeter'      => MemoireService::rejeter($id_memoire, $commentaire),
        'correction'   => MemoireService::mettreEnCorrection($id_memoire, $commentaire),
        default        => ['ok' => false, 'message' => 'Action inconnue.']
    };
    $message  = $result['message'];
    $msg_type = $result['ok'] ? 'success' : 'error';
    // Rafraîchir la liste
    $memoires = MemoireService::getMemoiresProfesseur($matricule);
}

$statuts = [
    'en_attente'    => ['label' => 'En attente',    'class' => 'badge-pending'],
    'en_correction' => ['label' => 'En correction', 'class' => 'badge-correction'],
    'valide'        => ['label' => 'Validé',         'class' => 'badge-valide'],
    'rejete'        => ['label' => 'Rejeté',         'class' => 'badge-rejete'],
];

$title = 'Dashboard Professeur'; $base = '../';
include __DIR__ . '/partials/head.php';
include __DIR__ . '/partials/navbar.php';
?>

<div class="dashboard">
  <aside class="sidebar">
    <div class="sidebar-section-title">Navigation</div>
    <nav class="sidebar-nav">
      <a href="dashboard_professeur.php" class="active">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Tableau de bord
      </a>
      <a href="catalogue.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        Catalogue
      </a>
    </nav>
    <div class="sidebar-section-title" style="margin-top:24px">Compte</div>
    <nav class="sidebar-nav">
      <a href="logout.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Déconnexion
      </a>
    </nav>
  </aside>

  <main class="main-content">
    <div class="page-title">Dashboard Professeur</div>
    <div class="page-subtitle">
      Matricule : <strong><?= htmlspecialchars($matricule) ?></strong>
      <?php if ($role_data['est_maitre_memoire']): ?>
        <span class="badge badge-diplome" style="margin-left:8px">Maître de mémoire</span>
      <?php endif; ?>
    </div>

    <?php if ($message): ?>
      <div class="alert alert-<?= $msg_type ?>" data-auto-hide><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-number"><?= count($memoires) ?></div>
        <div class="stat-label">Total assignés</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?= count(array_filter($memoires, fn($m) => $m['statut'] === 'en_attente')) ?></div>
        <div class="stat-label">En attente</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?= count(array_filter($memoires, fn($m) => $m['statut'] === 'en_correction')) ?></div>
        <div class="stat-label">En correction</div>
      </div>
      <div class="stat-card">
        <div class="stat-number"><?= count(array_filter($memoires, fn($m) => $m['statut'] === 'valide')) ?></div>
        <div class="stat-label">Validés</div>
      </div>
    </div>

    <!-- Liste des mémoires -->
    <div class="section">
      <h2 style="font-size:16px;font-weight:700;color:var(--primary);margin-bottom:16px">Mémoires assignés</h2>

      <?php if (empty($memoires)): ?>
        <div class="card text-center" style="padding:40px">
          <p class="text-muted">Aucun mémoire ne vous est assigné pour l'instant.</p>
        </div>
      <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:16px">
          <?php foreach ($memoires as $m): ?>
            <div class="card">
              <div class="flex justify-between items-center mb-2">
                <div>
                  <div style="font-size:15px;font-weight:700;color:var(--primary)"><?= htmlspecialchars($m['titre']) ?></div>
                  <div class="text-muted text-sm mt-1">
                    Étudiant : <strong><?= htmlspecialchars($m['etudiant_nom'] ?? '—') ?></strong>
                    · Année : <?= $m['annee'] ?>
                    · Soumis le : <?= $m['date_envoi'] ? date('d/m/Y', strtotime($m['date_envoi'])) : '—' ?>
                  </div>
                </div>
                <span class="badge <?= $statuts[$m['statut']]['class'] ?? '' ?>">
                  <?= $statuts[$m['statut']]['label'] ?? $m['statut'] ?>
                </span>
              </div>

              <?php if (!empty($m['commentaire_maitre'])): ?>
                <div class="annotation-box <?= $m['statut'] ?>" style="margin-top:12px;margin-bottom:12px">
                  <div class="text-sm text-muted mb-1">Votre annotation précédente :</div>
                  <div style="font-size:13px"><?= htmlspecialchars($m['commentaire_maitre']) ?></div>
                </div>
              <?php endif; ?>

              <?php if ($m['statut'] !== 'valide'): ?>
                <div style="margin-top:12px;border-top:1px solid var(--outline-variant);padding-top:14px">
                  <form method="POST" action="">
                    <input type="hidden" name="id_memoire" value="<?= $m['id_memoire'] ?>"/>
                    <div class="form-group">
                      <label class="form-label">Annotation / Commentaire</label>
                      <textarea class="form-control" name="commentaire" rows="3"
                                placeholder="Votre retour pour l'étudiant..."><?= htmlspecialchars($m['commentaire_maitre'] ?? '') ?></textarea>
                    </div>
                    <div class="flex gap-2">
                      <button type="submit" name="action" value="correction" class="btn btn-warning btn-sm">Renvoyer en correction</button>
                      <button type="submit" name="action" value="valider"
                              class="btn btn-success btn-sm"
                              onclick="return confirm('Valider définitivement ce mémoire ?')">Valider</button>
                      <button type="submit" name="action" value="rejeter"
                              class="btn btn-danger btn-sm"
                              onclick="return confirm('Rejeter ce mémoire ?')">Rejeter</button>
                      <?php if ($m['fichier']): ?>
                        <a href="../views/download.php?id=<?= $m['id_memoire'] ?>" target="_blank" class="btn btn-secondary btn-sm">Voir le PDF</a>
                      <?php endif; ?>
                    </div>
                  </form>
                </div>
              <?php else: ?>
                <div class="flex gap-2 mt-3">
                  <?php if ($m['fichier']): ?>
                    <a href="../views/download.php?id=<?= $m['id_memoire'] ?>" target="_blank" class="btn btn-secondary btn-sm">Voir le PDF</a>
                  <?php endif; ?>
                  <span class="text-sm text-muted" style="align-self:center">Mémoire validé ✓</span>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </main>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
