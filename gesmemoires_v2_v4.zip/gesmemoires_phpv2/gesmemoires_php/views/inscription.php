<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../models/Filiere.php';
require_once __DIR__ . '/../models/Specialite.php';

if (AuthService::isLoggedIn()) { header("Location: connexion.php"); exit; }

$filieres    = (new Filiere())->findAll();
$specialites = (new Specialite())->findAll();
$erreur = '';
$succes = '';
$step   = (int)($_POST['step'] ?? 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 2) {
    $data = [
        'nom'        => trim($_POST['nom']       ?? ''),
        'prenom'     => trim($_POST['prenom']    ?? ''),
        'email'      => trim($_POST['email']     ?? ''),
        'password'   => trim($_POST['password']  ?? ''),
        'role'       => $_POST['role']           ?? 'etudiant',
        'type'       => $_POST['type']           ?? 'non_diplome',
        'id_filiere' => (int)($_POST['id_filiere'] ?? 0),
        'specialites'=> $_POST['specialites']    ?? [],
    ];

    if (!$data['nom'] || !$data['prenom'] || !$data['email'] || !$data['password']) {
        $erreur = 'Veuillez remplir tous les champs obligatoires.';
        $step = 1;
    } elseif (strlen($data['password']) < 6) {
        $erreur = 'Le mot de passe doit contenir au moins 6 caractères.';
        $step = 1;
    } elseif ($data['role'] === 'etudiant' && !$data['id_filiere']) {
        $erreur = 'Veuillez sélectionner votre filière.';
        $step = 1;
    } else {
        $result = AuthService::inscrire($data);
        if ($result['ok']) {
            if ($result['statut'] === 'en_attente') {
                $succes = 'Votre demande a été transmise au Directeur des Études pour validation. Vous serez notifié par email.';
                $step = 1;
            } else {
                $login = AuthService::login($data['email'], $data['password']);
                if ($login['ok']) {
                    header("Location: dashboard_etudiant.php"); exit;
                }
                $succes = 'Inscription réussie ! Vous pouvez maintenant vous connecter.';
                $step = 1;
            }
        } else {
            $erreur = $result['message'];
            $step = 1;
        }
    }
}

$title = 'Inscription'; $base = '../';
include __DIR__ . '/partials/head.php';
?>

<div class="auth-page" style="align-items:flex-start;padding-top:40px">
  <div style="width:100%;max-width:560px;margin:0 auto">

    <div class="auth-logo" style="margin-bottom:24px">
      <div class="auth-logo-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 14l9-5-9-5-9 5 9 5z"/>
          <path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/>
        </svg>
      </div>
      <h1>Créer un compte</h1>
      <p>Rejoignez GesMemoires — UATM GASA</p>
    </div>

    <?php if ($erreur): ?>
      <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>
    <?php if ($succes): ?>
      <div class="alert alert-success"><?= htmlspecialchars($succes) ?></div>
      <div class="text-center mt-4">
        <a href="connexion.php" class="btn btn-primary">Aller à la connexion</a>
      </div>
    <?php else: ?>

    <div class="card">
      <div class="tabs-wrapper">
        <div class="tabs" id="role-tabs">
          <button type="button" class="tab-btn active" data-tab="tab-etudiant" onclick="setRole('etudiant','non_diplome',this)">Étudiant non diplômé</button>
          <button type="button" class="tab-btn" data-tab="tab-diplome"   onclick="setRole('etudiant','diplome',this)">Étudiant diplômé</button>
          <button type="button" class="tab-btn" data-tab="tab-prof"      onclick="setRole('professeur','',this)">Professeur</button>
        </div>

        <form method="POST" action="">
          <input type="hidden" name="step"  value="2"/>
          <input type="hidden" name="role"  id="hidden-role" value="etudiant"/>
          <input type="hidden" name="type"  id="hidden-type" value="non_diplome"/>

          <div class="grid-2">
            <div class="form-group">
              <label class="form-label">Prénom *</label>
              <input class="form-control" type="text" name="prenom" placeholder="Koffi" required
                     value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>"/>
            </div>
            <div class="form-group">
              <label class="form-label">Nom *</label>
              <input class="form-control" type="text" name="nom" placeholder="Zannou" required
                     value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>"/>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Email *</label>
            <input class="form-control" type="email" name="email" placeholder="nom@uac.bj" required
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"/>
          </div>

          <div class="form-group">
            <label class="form-label">Mot de passe * (min. 6 caractères)</label>
            <input class="form-control" type="password" name="password" placeholder="••••••••" required/>
          </div>

          <!-- Tab étudiant non diplômé -->
          <div class="tab-content active" id="tab-etudiant">
            <div class="form-group">
              <label class="form-label">Filière *</label>
              <select class="form-control" name="id_filiere" id="sel-filiere-non">
                <option value="">-- Sélectionnez votre filière --</option>
                <?php foreach ($filieres as $f): ?>
                  <option value="<?= $f['id_filiere'] ?>"><?= htmlspecialchars($f['nom']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <!-- Tab étudiant diplômé -->
          <div class="tab-content" id="tab-diplome" style="display:none">
            <div class="form-group">
              <label class="form-label">Filière *</label>
              <select class="form-control" name="id_filiere" id="sel-filiere-dip" disabled>
                <option value="">-- Sélectionnez votre filière --</option>
                <?php foreach ($filieres as $f): ?>
                  <option value="<?= $f['id_filiere'] ?>"><?= htmlspecialchars($f['nom']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="alert alert-info" style="font-size:12px">
              En tant qu'étudiant diplômé, vous pourrez soumettre votre mémoire après validation de votre compte.
            </div>
          </div>

          <!-- Tab professeur -->
          <div class="tab-content" id="tab-prof" style="display:none">
            <div class="form-group">
              <label class="form-label">Spécialités</label>
              <div style="display:flex;flex-wrap:wrap;gap:8px;padding:12px;border:1px solid var(--outline-variant);border-radius:10px">
                <?php foreach ($specialites as $s): ?>
                  <label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">
                    <input type="checkbox" name="specialites[]" value="<?= $s['id_specialite'] ?>"/>
                    <?= htmlspecialchars($s['libelle']) ?>
                  </label>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="alert alert-warning" style="font-size:12px">
              Votre compte sera soumis à la validation du Directeur des Études avant activation.
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-full mt-4">Créer mon compte</button>
        </form>
      </div>
    </div>

    <p class="text-center mt-4 text-sm text-muted">
      Déjà un compte ? <a href="connexion.php" style="font-weight:600">Se connecter</a>
    </p>
    <?php endif; ?>
  </div>
</div>

<?php
$extraJs = <<<JS
<script>
function setRole(role, type, btn) {
  document.getElementById('hidden-role').value = role;
  document.getElementById('hidden-type').value = type;

  // Activer/désactiver les selects filière selon l'onglet
  const selNon = document.getElementById('sel-filiere-non');
  const selDip = document.getElementById('sel-filiere-dip');
  selNon.disabled = !(role === 'etudiant' && type === 'non_diplome');
  selDip.disabled = !(role === 'etudiant' && type === 'diplome');

  // Switcher les tabs
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
  btn.classList.add('active');
  document.getElementById(btn.dataset.tab).style.display = '';
}

// Init au chargement
document.addEventListener('DOMContentLoaded', () => {
  const selNon = document.getElementById('sel-filiere-non');
  const selDip = document.getElementById('sel-filiere-dip');
  selNon.disabled = false;
  selDip.disabled = true;
});
</script>
JS;
include __DIR__ . '/partials/foot.php';
?>
