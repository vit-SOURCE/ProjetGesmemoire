<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/MemoireService.php';
require_once __DIR__ . '/../services/CompteService.php';
require_once __DIR__ . '/../models/Professeur.php';
require_once __DIR__ . '/../models/Etudiant.php';
require_once __DIR__ . '/../models/Filiere.php';
require_once __DIR__ . '/../models/Specialite.php';

AuthService::requireRole('de');
$user         = AuthService::getCurrentUser();
$role_data    = AuthService::getCurrentRoleData();
$de_matricule = $role_data['DE_matricule'];

$message = ''; $msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'valider_etudiant')        $r = CompteService::validerEtudiant($_POST['matricule']);
    elseif ($action === 'rejeter_etudiant')    $r = CompteService::rejeterEtudiant($_POST['matricule']);
    elseif ($action === 'valider_professeur')  $r = CompteService::validerProfesseur($_POST['matricule']);
    elseif ($action === 'rejeter_professeur')  $r = CompteService::rejeterProfesseur($_POST['matricule']);
    elseif ($action === 'valider_tous')        $r = CompteService::validerTous();
    elseif ($action === 'assigner') {
        $r = CompteService::assignerProfesseur($_POST['etu_matricule'], $_POST['prof_matricule']);
    }
    elseif ($action === 'publier')             $r = MemoireService::publier((int)$_POST['id_memoire']);
    elseif ($action === 'upload_archive') {
        if (!empty($_FILES['fichier']['name'])) {
            $r = MemoireService::uploadArchive([
                'titre'        => trim($_POST['titre']),
                'annee'        => (int)$_POST['annee'],
                'de_matricule' => $de_matricule,
            ], $_FILES['fichier']);
        } else {
            $r = ['ok' => false, 'message' => 'Aucun fichier sélectionné.'];
        }
    }
    else $r = ['ok' => false, 'message' => 'Action inconnue.'];

    $message  = $r['message'] ?? '';
    $msg_type = ($r['ok'] ?? false) ? 'success' : 'error';
}

$comptes_attente  = CompteService::getComptesEnAttente();
$tous_memoires    = MemoireService::getTous();
$stats            = MemoireService::getStats();
$professeurs      = (new Professeur())->findMaitresActifs();

// Étudiants diplômés actifs sans prof assigné (colonne Prof_matricule dans etudiant)
$etudiants_sans_prof = (new Etudiant())->findDiplomesActifsSansProf();

$badge = ['en_attente'=>'badge-pending','en_correction'=>'badge-correction','valide'=>'badge-valide','rejete'=>'badge-rejete','archive'=>'badge-archive'];
$label = ['en_attente'=>'En attente','en_correction'=>'En correction','valide'=>'Validé','rejete'=>'Rejeté','archive'=>'Archive'];

$nom_complet = ($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? '');
$initiales   = strtoupper(substr($user['prenom'] ?? 'D', 0, 1) . substr($user['nom'] ?? 'E', 0, 1));

$title = 'Dashboard DE'; $base = '../';
include __DIR__ . '/partials/head.php';
?>
<style>
.navbar {
  position: fixed; top: 0; left: 0; right: 0; z-index: 200;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 20px; height: 64px; background: #fff;
  border-bottom: 1px solid var(--outline-variant);
  box-shadow: 0 1px 6px rgba(0,0,0,.06); gap: 16px;
}
.navbar-left  { display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
.navbar-brand { display: flex; align-items: center; gap: 9px; font-weight: 800; font-size: 18px; color: var(--primary); text-decoration: none; }
.navbar-brand svg { width: 24px; height: 24px; }
.hamburger-btn { width: 34px; height: 34px; border-radius: 8px; border: none; background: var(--surface-container-low); cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--on-surface); flex-shrink: 0; }
.hamburger-btn:hover { background: var(--surface-container); }
.navbar-search { flex: 1; max-width: 440px; display: flex; align-items: center; gap: 8px; background: var(--surface-container-low); border: 1px solid var(--outline-variant); border-radius: 24px; padding: 0 16px; height: 38px; }
.navbar-search svg { color: var(--outline); flex-shrink: 0; width: 15px; height: 15px; }
.navbar-search input { border: none; background: transparent; font-family: inherit; font-size: 13px; color: var(--on-surface); width: 100%; outline: none; }
.navbar-right { display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
.nav-salon-btn { display: flex; align-items: center; gap: 6px; padding: 7px 14px; border-radius: 20px; border: 1.5px solid var(--outline-variant); font-size: 12px; font-weight: 600; color: var(--secondary); cursor: pointer; background: #fff; font-family: inherit; transition: border-color .2s, color .2s; white-space: nowrap; }
.nav-salon-btn:hover { border-color: var(--primary); color: var(--primary); }
.nav-notif-btn { position: relative; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; background: var(--surface-container-low); border: 1px solid var(--outline-variant); color: var(--secondary); }
.nav-notif-dot { position: absolute; top: 3px; right: 3px; width: 8px; height: 8px; border-radius: 50%; background: #ef4444; border: 1.5px solid #fff; }
.nav-user      { display: flex; align-items: center; gap: 10px; }
.nav-user-info { text-align: right; line-height: 1.3; }
.nav-user-name { font-size: 13px; font-weight: 700; color: var(--on-surface); }
.nav-user-role { font-size: 11px; color: var(--secondary); }
.nav-avatar    { width: 34px; height: 34px; border-radius: 50%; background: var(--primary-container); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800; color: #fff; flex-shrink: 0; }
.nav-quit-btn  { font-size: 12px; font-weight: 700; color: #ef4444; cursor: pointer; border: none; background: none; font-family: inherit; padding: 0; white-space: nowrap; }
.nav-quit-btn:hover { opacity: .75; }
body { overflow-x: hidden; }
.de-layout { display: flex; padding-top: 64px; min-height: 100vh; }
.de-sidebar { width: 240px; min-height: calc(100vh - 64px); background: var(--primary); color: #fff; position: fixed; top: 64px; left: 0; overflow-y: auto; transition: transform .25s; z-index: 100; }
.de-sidebar.collapsed { transform: translateX(-240px); }
.sidebar-section-title { font-size: 10px; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; padding: 14px 20px 4px; color: rgba(255,255,255,.35); }
.sidebar-nav a { display: flex; align-items: center; gap: 10px; padding: 11px 20px; font-size: 13px; font-weight: 500; color: rgba(255,255,255,.7); transition: all .2s; text-decoration: none; }
.sidebar-nav a svg { width: 16px; height: 16px; flex-shrink: 0; }
.sidebar-nav a:hover, .sidebar-nav a.active { background: rgba(255,255,255,.1); color: #fff; border-right: 3px solid var(--tertiary-fixed); }
.sidebar-badge { margin-left: auto; border-radius: 10px; padding: 1px 7px; font-size: 10px; font-weight: 700; }
.sidebar-badge.red   { background: #ef4444; color: #fff; }
.sidebar-badge.amber { background: #f59e0b; color: #fff; }
.de-main { margin-left: 240px; flex: 1; padding: 28px; transition: margin-left .25s; min-width: 0; }
.de-page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; gap: 16px; flex-wrap: wrap; }
.de-page-title { font-size: 23px; font-weight: 800; color: var(--primary); }
.de-page-sub   { font-size: 13px; color: var(--secondary); margin-top: 3px; }
.de-header-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.year-select { padding: 8px 14px; border-radius: 9px; border: 1.5px solid var(--outline-variant); background: #fff; font-family: inherit; font-size: 13px; font-weight: 600; color: var(--on-surface); cursor: pointer; outline: none; }
.kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 22px; }
.kpi-card { background: #fff; border-radius: 14px; border: 1px solid var(--outline-variant); padding: 18px 20px; box-shadow: 0 1px 4px rgba(0,0,0,.04); }
.kpi-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
.kpi-icon { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; }
.kpi-icon svg { width: 19px; height: 19px; }
.kpi-icon.blue  { background: #dbeafe; color: #2563eb; }
.kpi-icon.green { background: var(--success-container); color: var(--success); }
.kpi-icon.amber { background: var(--warning-container); color: var(--warning); }
.kpi-icon.slate { background: var(--secondary-container); color: var(--secondary); }
.kpi-delta { font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 8px; }
.kpi-delta.up   { background: #dcfce7; color: #16a34a; }
.kpi-delta.warn { background: var(--warning-container); color: var(--warning); }
.kpi-number { font-size: 30px; font-weight: 800; color: var(--primary); line-height: 1; }
.kpi-label  { font-size: 11px; font-weight: 600; color: var(--secondary); text-transform: uppercase; letter-spacing: .05em; margin-top: 4px; }
.dash-grid  { display: grid; grid-template-columns: 1fr 300px; gap: 18px; }
.dash-right { display: flex; flex-direction: column; gap: 18px; }
.de-card { background: #fff; border-radius: 14px; border: 1px solid var(--outline-variant); padding: 20px 22px; box-shadow: 0 1px 4px rgba(0,0,0,.04); }
.de-card-head  { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.de-card-title { font-size: 12px; font-weight: 700; color: var(--on-surface); text-transform: uppercase; letter-spacing: .06em; }
.de-card-count { font-size: 12px; font-weight: 600; color: var(--secondary); }
.de-table-wrap { overflow-x: auto; border-radius: 10px; border: 1px solid var(--outline-variant); }
.de-table-wrap table { width: 100%; border-collapse: collapse; }
.de-table-wrap thead { background: var(--surface-container-low); }
.de-table-wrap th { padding: 10px 14px; text-align: left; font-size: 11px; font-weight: 700; color: var(--secondary); text-transform: uppercase; letter-spacing: .05em; white-space: nowrap; }
.de-table-wrap td { padding: 12px 14px; font-size: 13px; border-top: 1px solid var(--outline-variant); }
.de-table-wrap tr:hover td { background: #fafafa; }
.pending-avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--secondary-container); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800; color: var(--secondary); flex-shrink: 0; }
.icon-action-btn { width: 29px; height: 29px; border-radius: 7px; border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 13px; font-weight: 700; transition: filter .15s; font-family: inherit; }
.icon-action-btn.reject { background: #fee2e2; color: var(--error); }
.icon-action-btn.accept { background: #dcfce7; color: #16a34a; }
.icon-action-btn:hover  { filter: brightness(.88); }
.activity-item { display: flex; gap: 11px; padding: 11px 0; border-bottom: 1px solid var(--outline-variant); }
.activity-item:last-child { border-bottom: none; }
.activity-dot  { width: 10px; height: 10px; border-radius: 50%; background: #2563eb; flex-shrink: 0; margin-top: 4px; }
.activity-text { font-size: 13px; color: var(--on-surface); line-height: 1.5; }
.activity-time { font-size: 11px; color: var(--outline); margin-top: 1px; }
.assign-arrow  { text-align: center; font-size: 18px; color: var(--outline); padding: 4px 0; }
.de-alert { padding: 12px 16px; border-radius: 10px; font-size: 13px; font-weight: 500; margin-bottom: 16px; }
.de-alert.success { background: var(--success-container); color: var(--success); border-left: 4px solid var(--success); }
.de-alert.error   { background: var(--error-container);   color: var(--error);   border-left: 4px solid var(--error); }
.de-alert.warn    { background: var(--warning-container); color: var(--warning); border-left: 4px solid var(--warning); }
.de-alert.info    { background: #dbeafe; color: #1d4ed8; border-left: 4px solid #2563eb; }
.de-tab { display: none; }
.de-tab.active { display: block; }
.section-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; gap: 16px; flex-wrap: wrap; }
.section-title  { font-size: 17px; font-weight: 700; color: var(--primary); }
.section-sub    { font-size: 13px; color: var(--secondary); margin-top: 2px; }
@media (max-width: 1100px) { .kpi-grid { grid-template-columns: repeat(2,1fr); } .dash-grid { grid-template-columns: 1fr; } }
@media (max-width: 768px)  { .de-sidebar { transform: translateX(-240px); } .de-sidebar.mobile-open { transform: translateX(0); } .de-main { margin-left: 0 !important; padding: 16px; } .navbar-search { display: none; } .nav-user-info { display: none; } }
@media (max-width: 580px)  { .kpi-grid { grid-template-columns: 1fr; } }
</style>

<nav class="navbar">
  <div class="navbar-left">
    <button class="hamburger-btn" onclick="toggleSidebar()" title="Menu">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>
    <a href="<?= $base ?>accueil.php" class="navbar-brand">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 14l9-5-9-5-9 5 9 5z"/>
        <path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/>
      </svg>
      GesMemoires
    </a>
  </div>
  <div class="navbar-search">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
    <input type="text" placeholder="Rechercher un étudiant, un mémoire ou un tuteur..."/>
  </div>
  <div class="navbar-right">
    <button class="nav-salon-btn">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
      </svg>
      Salon &amp; Chatbot
    </button>
    <div class="nav-notif-btn" title="Notifications">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
        <path d="M13.73 21a2 2 0 01-3.46 0"/>
      </svg>
      <?php if (count($comptes_attente) > 0): ?>
        <div class="nav-notif-dot"></div>
      <?php endif; ?>
    </div>
    <div class="nav-user">
      <div class="nav-user-info">
        <div class="nav-user-name"><?= htmlspecialchars($nom_complet) ?></div>
        <div class="nav-user-role">Dir. des Études</div>
      </div>
      <div class="nav-avatar"><?= htmlspecialchars($initiales) ?></div>
      <a href="logout.php"><button class="nav-quit-btn">Quitter</button></a>
    </div>
  </div>
</nav>

<div class="de-layout">
  <aside class="de-sidebar" id="deSidebar">
    <div class="sidebar-section-title">Navigation</div>
    <nav class="sidebar-nav">
      <a href="#" onclick="showTab('tab-stats',this);return false;" class="active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Tableau de bord
      </a>
      <a href="#" onclick="showTab('tab-comptes',this);return false;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        Comptes en attente
        <?php if (count($comptes_attente) > 0): ?>
          <span class="sidebar-badge red"><?= count($comptes_attente) ?></span>
        <?php endif; ?>
      </a>
      <a href="#" onclick="showTab('tab-assignation',this);return false;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
        Assignation
        <?php if (count($etudiants_sans_prof) > 0): ?>
          <span class="sidebar-badge amber"><?= count($etudiants_sans_prof) ?></span>
        <?php endif; ?>
      </a>
      <a href="#" onclick="showTab('tab-memoires',this);return false;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        Mémoires
      </a>
      <a href="#" onclick="showTab('tab-upload',this);return false;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        Uploader une archive
      </a>
    </nav>
    <div class="sidebar-section-title" style="margin-top:20px">Compte</div>
    <nav class="sidebar-nav">
      <a href="logout.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Déconnexion
      </a>
    </nav>
  </aside>

  <main class="de-main" id="deMain">

    <?php if ($message): ?>
      <div class="de-alert <?= $msg_type ?>" data-auto-hide><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- TAB STATS -->
    <div id="tab-stats" class="de-tab active">
      <div class="de-page-header">
        <div>
          <div class="de-page-title">Tableau de bord</div>
          <div class="de-page-sub">Bienvenue, voici l'état actuel des thèses et des comptes.</div>
        </div>
        <div class="de-header-actions">
          <select class="year-select">
            <option>Toutes les années</option>
            <option><?= date('Y')-1 ?>-<?= date('Y') ?></option>
            <option><?= date('Y')-2 ?>-<?= date('Y')-1 ?></option>
          </select>
          <button class="btn btn-secondary btn-sm">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Exporter
          </button>
          <button class="btn btn-sm" style="background:#0d9488;color:#fff">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
            Générer rapport
          </button>
          <button class="btn btn-primary btn-sm">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Nouvel Étudiant
          </button>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-top">
            <div class="kpi-icon blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></div>
            <span class="kpi-delta up">+12%</span>
          </div>
          <div class="kpi-number"><?= number_format(($stats['total'] ?? 0) + count($comptes_attente) + count($professeurs)) ?></div>
          <div class="kpi-label">Total utilisateurs</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-top">
            <div class="kpi-icon green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg></div>
            <span class="kpi-delta up">+5%</span>
          </div>
          <div class="kpi-number"><?= $stats['valide'] ?? 0 ?></div>
          <div class="kpi-label">Mémoires validés</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-top">
            <div class="kpi-icon amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
            <?php if (($stats['en_attente'] ?? 0) > 0): ?>
              <span class="kpi-delta warn"><?= $stats['en_attente'] ?> En attente</span>
            <?php endif; ?>
          </div>
          <div class="kpi-number"><?= ($stats['en_attente'] ?? 0) + ($stats['en_correction'] ?? 0) ?></div>
          <div class="kpi-label">En cours d'examen</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-top">
            <div class="kpi-icon slate"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
          </div>
          <div class="kpi-number"><?= count($comptes_attente) ?></div>
          <div class="kpi-label">Comptes à valider</div>
        </div>
      </div>

      <?php if (count($comptes_attente) > 0): ?>
        <div class="de-alert warn" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <span><?= count($comptes_attente) ?> compte(s) en attente de validation</span>
          <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="valider_tous"/>
            <button class="btn btn-success btn-sm" onclick="return confirm('Valider tous les comptes en attente ?')">Tout valider</button>
          </form>
        </div>
      <?php endif; ?>
      <?php if (count($etudiants_sans_prof) > 0): ?>
        <div class="de-alert info" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <span><?= count($etudiants_sans_prof) ?> étudiant(s) sans maître assigné</span>
          <a href="#" onclick="showTab('tab-assignation',null);return false;" class="btn btn-primary btn-sm">Assigner →</a>
        </div>
      <?php endif; ?>

      <div class="dash-grid">
        <div class="de-card">
          <div class="de-card-head">
            <span class="de-card-title">Inscriptions en attente</span>
            <span class="de-card-count"><?= count($comptes_attente) ?> demande(s)</span>
          </div>
          <?php if (empty($comptes_attente)): ?>
            <div style="text-align:center;padding:32px 0;color:var(--secondary);font-size:13px">Aucune inscription en attente.</div>
          <?php else: ?>
            <div class="de-table-wrap">
              <table>
                <thead><tr><th>Utilisateur</th><th>Type</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($comptes_attente as $c):
                  $prenom = $c['prenom'] ?? ''; $nom = $c['nom'] ?? '';
                  $init = strtoupper(substr($prenom,0,1).substr($nom,0,1));
                  $mat  = $c['Etu_matricule'] ?? $c['Prof_matricule'] ?? '';
                ?>
                  <tr>
                    <td>
                      <div style="display:flex;align-items:center;gap:10px">
                        <div class="pending-avatar"><?= htmlspecialchars($init) ?></div>
                        <div>
                          <div style="font-weight:600;font-size:13px"><?= htmlspecialchars($prenom.' '.$nom) ?></div>
                          <div style="font-size:11px;color:var(--secondary)"><?= htmlspecialchars($c['email'] ?? '') ?></div>
                        </div>
                      </div>
                    </td>
                    <td><?= $c['type_compte'] === 'etudiant' ? '<span class="badge badge-valide">ÉTUDIANT</span>' : '<span class="badge badge-correction">MAÎTRE</span>' ?></td>
                    <td>
                      <div style="display:flex;gap:6px">
                        <form method="POST" style="display:inline">
                          <input type="hidden" name="action" value="rejeter_<?= $c['type_compte'] ?>"/>
                          <input type="hidden" name="matricule" value="<?= htmlspecialchars($mat) ?>"/>
                          <button type="submit" class="icon-action-btn reject" onclick="return confirm('Rejeter ce compte ?')" title="Rejeter">✕</button>
                        </form>
                        <form method="POST" style="display:inline">
                          <input type="hidden" name="action" value="valider_<?= $c['type_compte'] ?>"/>
                          <input type="hidden" name="matricule" value="<?= htmlspecialchars($mat) ?>"/>
                          <button type="submit" class="icon-action-btn accept" title="Valider">✓</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

        <div class="dash-right">
          <div class="de-card">
            <div class="de-card-head"><span class="de-card-title">Flux d'activité</span></div>
            <div class="activity-item">
              <div class="activity-dot"></div>
              <div><div class="activity-text">Le <strong>Directeur</strong> des Études a validé le dernier mémoire soumis.</div><div class="activity-time">Récemment</div></div>
            </div>
            <?php if (count($comptes_attente) > 0): ?>
            <div class="activity-item">
              <div class="activity-dot" style="background:#f59e0b"></div>
              <div><div class="activity-text">Nouvelle inscription : <strong><?= htmlspecialchars(($comptes_attente[0]['prenom']??'').' '.($comptes_attente[0]['nom']??'')) ?></strong>.</div><div class="activity-time">Récemment</div></div>
            </div>
            <?php endif; ?>
            <div class="activity-item">
              <div class="activity-dot" style="background:#16a34a"></div>
              <div><div class="activity-text"><?= $stats['valide'] ?? 0 ?> mémoire(s) validé(s) au total.</div><div class="activity-time">Statistique globale</div></div>
            </div>
          </div>

          <div class="de-card">
            <div class="de-card-head"><span class="de-card-title">Assignation rapide</span></div>
            <form method="POST">
              <input type="hidden" name="action" value="assigner"/>
              <div class="form-group">
                <label class="form-label">Étudiant non-assigné</label>
                <select class="form-control" name="etu_matricule" required>
                  <option value="">Sélectionner un étudiant...</option>
                  <?php foreach ($etudiants_sans_prof as $e): ?>
                    <option value="<?= htmlspecialchars($e['Etu_matricule']) ?>"><?= htmlspecialchars($e['etudiant_nom'] ?? ($e['prenom'].' '.$e['nom'])) ?> (<?= $e['Etu_matricule'] ?>)</option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="assign-arrow">↓</div>
              <div class="form-group">
                <label class="form-label">Maître de mémoire</label>
                <select class="form-control" name="prof_matricule" required>
                  <option value="">Sélectionner un tuteur...</option>
                  <?php foreach ($professeurs as $p): ?>
                    <option value="<?= htmlspecialchars($p['Prof_matricule']) ?>"><?= htmlspecialchars($p['prenom'].' '.$p['nom']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <button type="submit" class="btn btn-primary btn-full">Confirmer l'assignation</button>
            </form>
          </div>
        </div>
      </div>
    </div><!-- /tab-stats -->

    <!-- TAB COMPTES -->
    <div id="tab-comptes" class="de-tab">
      <div class="section-header">
        <div><div class="section-title">Comptes en attente (<?= count($comptes_attente) ?>)</div><div class="section-sub">Validez ou rejetez les nouvelles inscriptions.</div></div>
        <?php if (count($comptes_attente) > 0): ?>
          <form method="POST"><input type="hidden" name="action" value="valider_tous"/>
            <button class="btn btn-success btn-sm" onclick="return confirm('Valider tous ?')">✓ Tout valider (<?= count($comptes_attente) ?>)</button>
          </form>
        <?php endif; ?>
      </div>
      <?php if (empty($comptes_attente)): ?>
        <div class="de-card" style="text-align:center;padding:48px"><div style="font-size:2rem;margin-bottom:8px">✓</div><p style="color:var(--secondary);font-size:13px">Aucun compte en attente.</p></div>
      <?php else: ?>
        <div class="de-card" style="padding:0;overflow:hidden">
          <div class="de-table-wrap" style="border:none;border-radius:14px">
            <table>
              <thead><tr><th>Nom</th><th>Email</th><th>Type</th><th>Matricule</th><th>Actions</th></tr></thead>
              <tbody>
              <?php foreach ($comptes_attente as $c): $mat = $c['Etu_matricule'] ?? $c['Prof_matricule'] ?? ''; ?>
                <tr>
                  <td><strong><?= htmlspecialchars($c['prenom'].' '.$c['nom']) ?></strong></td>
                  <td style="color:var(--secondary)"><?= htmlspecialchars($c['email'] ?? '') ?></td>
                  <td><span class="badge <?= $c['type_compte']==='etudiant'?'badge-valide':'badge-correction' ?>"><?= $c['type_compte']==='etudiant' ? 'Étudiant ('.htmlspecialchars($c['type']??'').')' : 'Professeur' ?></span></td>
                  <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($mat) ?></td>
                  <td>
                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                      <form method="POST" style="display:inline"><input type="hidden" name="action" value="valider_<?= $c['type_compte'] ?>"/><input type="hidden" name="matricule" value="<?= htmlspecialchars($mat) ?>"/><button class="btn btn-success btn-sm">✓ Valider</button></form>
                      <form method="POST" style="display:inline"><input type="hidden" name="action" value="rejeter_<?= $c['type_compte'] ?>"/><input type="hidden" name="matricule" value="<?= htmlspecialchars($mat) ?>"/><button class="btn btn-danger btn-sm" onclick="return confirm('Rejeter ?')">✗ Rejeter</button></form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div><!-- /tab-comptes -->

    <!-- TAB ASSIGNATION -->
    <div id="tab-assignation" class="de-tab">
      <div class="section-header">
        <div><div class="section-title">Assignation étudiant → Maître de mémoire</div><div class="section-sub"><?= count($etudiants_sans_prof) ?> étudiant(s) sans maître assigné.</div></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div class="de-card">
          <h4 style="margin-bottom:18px;color:var(--primary);font-size:14px;font-weight:700">Assignation rapide</h4>
          <form method="POST">
            <input type="hidden" name="action" value="assigner"/>
            <div class="form-group">
              <label class="form-label">Mémoire sans maître *</label>
              <select class="form-control" name="etu_matricule" required>
                <option value="">-- Sélectionner un étudiant --</option>
                <?php foreach ($etudiants_sans_prof as $e): ?>
                  <option value="<?= htmlspecialchars($e['Etu_matricule']) ?>"><?= htmlspecialchars($e['etudiant_nom'] ?? ($e['prenom'].' '.$e['nom'])) ?> (<?= $e['Etu_matricule'] ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="assign-arrow">↓</div>
            <div class="form-group">
              <label class="form-label">Maître de mémoire *</label>
              <select class="form-control" name="prof_matricule" required>
                <option value="">-- Sélectionner un maître --</option>
                <?php foreach ($professeurs as $p): ?>
                  <option value="<?= htmlspecialchars($p['Prof_matricule']) ?>"><?= htmlspecialchars($p['prenom'].' '.$p['nom']) ?> (<?= $p['Prof_matricule'] ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Confirmer l'assignation</button>
          </form>
        </div>
        <div class="de-card">
          <h4 style="margin-bottom:14px;color:var(--primary);font-size:14px;font-weight:700">Étudiants sans maître (<?= count($etudiants_sans_prof) ?>)</h4>
          <?php if (empty($etudiants_sans_prof)): ?>
            <div style="text-align:center;padding:32px 0"><div style="font-size:2rem;margin-bottom:8px">✓</div><p style="color:var(--secondary);font-size:13px">Tous les étudiants diplômés ont un maître assigné.</p></div>
          <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:10px;max-height:420px;overflow-y:auto">
              <?php foreach ($etudiants_sans_prof as $e): ?>
                <div style="padding:12px;background:var(--surface-container-low);border-radius:8px;border:1px solid var(--outline-variant)">
                  <div style="font-weight:600;font-size:13px;margin-bottom:4px"><?= htmlspecialchars($e['etudiant_nom'] ?? ($e['prenom'].' '.$e['nom'])) ?></div>
                  <div style="font-size:11px;color:var(--secondary)"><?= htmlspecialchars($e['Etu_matricule']) ?> · <?= htmlspecialchars($e['filiere_nom'] ?? '—') ?></div>
                  <span class="badge badge-pending" style="margin-top:6px">Sans maître</span>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div><!-- /tab-assignation -->

    <!-- TAB MEMOIRES -->
    <div id="tab-memoires" class="de-tab">
      <div class="section-header">
        <div><div class="section-title">Suivi des mémoires</div><div class="section-sub">Toutes les années académiques | <?= count($tous_memoires) ?> mémoire(s) trouvé(s)</div></div>
      </div>
      <div class="de-card" style="padding:0;overflow:hidden">
        <div class="de-table-wrap" style="border:none;border-radius:14px">
          <table>
            <thead><tr><th>Étudiant</th><th>Mémoire / Thématique</th><th>Maître / Encadrant</th><th>Statut</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if (empty($tous_memoires)): ?>
              <tr><td colspan="5" style="text-align:center;color:var(--secondary);padding:32px">Aucun mémoire enregistré.</td></tr>
            <?php else: ?>
            <?php foreach ($tous_memoires as $m): ?>
              <tr>
                <td>
                  <div style="font-weight:600"><?= htmlspecialchars($m['etudiant_nom']??'—') ?></div>
                  <div style="font-size:11px;color:var(--secondary)"><?= htmlspecialchars($m['Etu_matricule']??'') ?></div>
                </td>
                <td style="max-width:280px">
                  <div style="font-weight:500;font-size:13px"><?= htmlspecialchars($m['titre']) ?></div>
                  <div style="font-size:11px;color:var(--outline);margin-top:3px">Année <?= $m['annee'] ?></div>
                </td>
                <td><?= htmlspecialchars($m['prof_nom']??'—') ?></td>
                <td><span class="badge <?= $badge[$m['statut']]??'badge-pending' ?>"><?= $label[$m['statut']]??htmlspecialchars($m['statut']) ?></span></td>
                <td>
                  <div style="display:flex;gap:6px;flex-wrap:wrap">
                    <?php if ($m["statut"]==="valide" && $m["Etu_matricule"] && empty($m["date_publication"])): ?>
                      <form method="POST" style="display:inline"><input type="hidden" name="action" value="publier"/><input type="hidden" name="id_memoire" value="<?= $m['id_memoire'] ?>"/><button class="btn btn-primary btn-sm">Publier</button></form>
                    <?php endif; ?>
                    <?php if ($m['fichier']): ?>
                      <a href="download.php?id=<?= $m['id_memoire'] ?>" target="_blank" class="btn btn-secondary btn-sm">PDF</a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div><!-- /tab-memoires -->

    <!-- TAB UPLOAD -->
    <div id="tab-upload" class="de-tab">
      <div class="section-header">
        <div><div class="section-title">Uploader un mémoire archivé</div><div class="section-sub">Ajoutez un mémoire archivé directement dans le système.</div></div>
      </div>
      <div class="de-card" style="max-width:580px">
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="action" value="upload_archive"/>
          <div class="form-group"><label class="form-label">Titre *</label><input class="form-control" type="text" name="titre" placeholder="Titre du mémoire" required/></div>
          <div class="form-group"><label class="form-label">Année *</label><input class="form-control" type="number" name="annee" min="2000" max="2030" value="<?= date('Y') ?>" required/></div>
          <div class="form-group"><label class="form-label">Fichier PDF *</label><input class="form-control" type="file" name="fichier" accept=".pdf" required/></div>
          <button type="submit" class="btn btn-primary btn-full">Uploader l'archive</button>
        </form>
      </div>
    </div><!-- /tab-upload -->

  </main>
</div>

<button onclick="showTab('tab-memoires',null)" style="position:fixed;bottom:28px;right:28px;width:50px;height:50px;border-radius:50%;background:var(--primary);color:#fff;border:none;font-size:22px;cursor:pointer;box-shadow:0 4px 16px rgba(3,22,53,.35);display:flex;align-items:center;justify-content:center;z-index:150;" title="Voir les mémoires">+</button>

<?php
$extraJs = <<<JS
<script>
function showTab(id, el) {
  document.querySelectorAll('.de-tab').forEach(t => t.classList.remove('active'));
  const panel = document.getElementById(id);
  if (panel) panel.classList.add('active');
  document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
  if (el) { const link = el.closest ? el.closest('a') : el; if (link) link.classList.add('active'); }
}
let sidebarOpen = true;
function toggleSidebar() {
  const sb = document.getElementById('deSidebar');
  const main = document.getElementById('deMain');
  sidebarOpen = !sidebarOpen;
  if (window.innerWidth > 768) { sb.classList.toggle('collapsed', !sidebarOpen); main.style.marginLeft = sidebarOpen ? '240px' : '0'; }
  else { sb.classList.toggle('mobile-open', sidebarOpen); }
}
(function() {
  const hash = window.location.hash;
  if (hash === '#comptes')     showTab('tab-comptes',     document.querySelector('[onclick*="tab-comptes"]'));
  else if (hash === '#assign') showTab('tab-assignation', document.querySelector('[onclick*="tab-assignation"]'));
  else if (hash === '#upload') showTab('tab-upload',      document.querySelector('[onclick*="tab-upload"]'));
})();
// Recherche dynamique
document.querySelector('.navbar-search input')?.addEventListener('input', function() {
  const q = this.value.toLowerCase().trim();
  document.querySelectorAll('.de-table-wrap tbody tr').forEach(row => {
    row.style.display = (!q || row.textContent.toLowerCase().includes(q)) ? '' : 'none';
  });
});
</script>
JS;
include __DIR__ . '/partials/foot.php';
?>
