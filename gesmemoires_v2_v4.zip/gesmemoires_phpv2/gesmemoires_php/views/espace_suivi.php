<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/MemoireService.php';
require_once __DIR__ . '/../config/database.php';

AuthService::requireRole('etudiant');
$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();
$id        = (int)($_GET['id'] ?? 0);

if (!$id) { header('Location: dashboard_etudiant.php'); exit; }

$memoire = MemoireService::getDetail($id);
if (!$memoire || $memoire['Etu_matricule'] !== $role_data['Etu_matricule']) {
    header('Location: dashboard_etudiant.php'); exit;
}

$erreur = ''; $succes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['fichier']['name'])) {
    $notes   = trim($_POST['notes'] ?? '');
    $fichier = $_FILES['fichier'];

    $ext  = strtolower(pathinfo($fichier['name'], PATHINFO_EXTENSION));
    $type = $fichier['type'] ?? '';
    $pdf_types = ['application/pdf','application/x-pdf','application/octet-stream','binary/octet-stream'];

    if ($fichier['error'] !== UPLOAD_ERR_OK) {
        $erreur = 'Erreur upload (code ' . $fichier['error'] . ').';
    } elseif (!in_array($type, $pdf_types) && $ext !== 'pdf') {
        $erreur = 'Le fichier doit être un PDF.';
    } elseif ($fichier['size'] > 50 * 1024 * 1024) {
        $erreur = 'Fichier trop volumineux (max 50 Mo).';
    } else {
        $dir = __DIR__ . '/../uploads/memoires';
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $nom_fichier = uniqid('memoire_') . '.pdf';
        if (!move_uploaded_file($fichier['tmp_name'], $dir . '/' . $nom_fichier)) {
            $erreur = 'Impossible de sauvegarder le fichier. Créez le dossier uploads/memoires/ sur le serveur.';
        } else {
            // UPDATE du mémoire existant — pas d'INSERT
            $db = getDB();
            $stmt = $db->prepare(
                "UPDATE memoire SET fichier = ?, statut = 'en_attente', commentaire_maitre = ?, date_envoi = NOW()
                 WHERE id_memoire = ?"
            );
            $ok = $stmt->execute([$nom_fichier, $notes ?: $memoire['commentaire_maitre'], $id]);
            if ($ok && $stmt->rowCount() > 0) {
                $succes  = 'Votre version corrigée a été soumise avec succès.';
                $memoire = MemoireService::getDetail($id);
            } else {
                $erreur = 'Erreur lors de la mise à jour.';
            }
        }
    }
}

$steps = [
    ['key' => 'en_attente',    'label' => 'Soumis'],
    ['key' => 'en_correction', 'label' => 'En correction'],
    ['key' => 'valide',        'label' => 'Validé'],
];
$step_index = match($memoire['statut']) {
    'en_attente'    => 0,
    'en_correction' => 1,
    'valide'        => 2,
    'rejete'        => 1,
    default         => 0
};

$title = 'Suivi du mémoire'; $base = '../';
include __DIR__ . '/partials/head.php';
include __DIR__ . '/partials/navbar.php';
?>

<div class="dashboard">
  <aside class="sidebar">
    <div class="sidebar-section-title">Navigation</div>
    <nav class="sidebar-nav">
      <a href="dashboard_etudiant.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
        Retour
      </a>
      <a href="catalogue.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        Catalogue
      </a>
    </nav>
  </aside>

  <main class="main-content">
    <?php if ($erreur): ?>
      <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>
    <?php if ($succes): ?>
      <div class="alert alert-success"><?= htmlspecialchars($succes) ?></div>
    <?php endif; ?>

    <div class="suivi-header">
      <div style="font-size:12px;opacity:.6;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px">Espace de suivi</div>
      <h1 style="font-size:20px;font-weight:800;margin-bottom:4px"><?= htmlspecialchars($memoire['titre']) ?></h1>
      <div style="font-size:13px;opacity:.75">
        Année : <?= $memoire['annee'] ?>
        · Soumis le : <?= $memoire['date_envoi'] ? date('d/m/Y', strtotime($memoire['date_envoi'])) : '—' ?>
        · Professeur : <?= htmlspecialchars($memoire['prof_nom'] ?? '—') ?>
      </div>

      <div class="suivi-status-bar" style="margin-top:20px">
        <?php foreach ($steps as $i => $step): ?>
          <div class="suivi-step <?= $i < $step_index ? 'done' : ($i === $step_index ? 'active' : '') ?>">
            <div class="suivi-dot"><?= $i < $step_index ? '✓' : ($i + 1) ?></div>
            <div class="suivi-step-label"><?= $step['label'] ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <?php if ($memoire['statut'] === 'rejete'): ?>
        <div style="margin-top:12px;background:rgba(186,26,26,.2);border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600">
          ❌ Mémoire rejeté — soumettez une version corrigée ci-dessous
        </div>
      <?php elseif ($memoire['statut'] === 'valide'): ?>
        <div style="margin-top:12px;background:rgba(26,107,58,.2);border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600">
          ✅ Mémoire validé — Félicitations !
        </div>
      <?php elseif ($memoire['statut'] === 'en_correction'): ?>
        <div style="margin-top:12px;background:rgba(29,78,216,.15);border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600">
          🔵 Corrections demandées — consultez l'annotation et ressoumettez
        </div>
      <?php endif; ?>
    </div>

    <div class="grid-2" style="align-items:start">
      <!-- PDF -->
      <div class="card">
        <div class="card-header">Fichier du mémoire</div>
        <?php if ($memoire['fichier']): ?>
          <div style="background:var(--surface-container-low);border-radius:10px;padding:20px;text-align:center;margin-bottom:16px">
            <div style="font-size:40px;margin-bottom:8px">📄</div>
            <div style="font-weight:600;font-size:13px;color:var(--primary);word-break:break-all"><?= htmlspecialchars($memoire['fichier']) ?></div>
          </div>
          <a href="download.php?id=<?= $id ?>" target="_blank" class="btn btn-primary btn-full">Ouvrir le PDF</a>
        <?php else: ?>
          <p class="text-muted text-sm">Aucun fichier disponible.</p>
        <?php endif; ?>
      </div>

      <!-- Annotations + Resoumettre -->
      <div>
        <div class="card mb-4">
          <div class="card-header">Annotation du professeur</div>
          <?php if (!empty($memoire['commentaire_maitre'])): ?>
            <div class="annotation-box <?= $memoire['statut'] ?>">
              <div class="text-sm text-muted mb-1">Retour de <?= htmlspecialchars($memoire['prof_nom'] ?? 'votre professeur') ?> :</div>
              <div style="font-size:14px;line-height:1.6"><?= nl2br(htmlspecialchars($memoire['commentaire_maitre'])) ?></div>
            </div>
          <?php else: ?>
            <p class="text-muted text-sm">Aucune annotation pour le moment.</p>
          <?php endif; ?>
        </div>

        <?php if (in_array($memoire['statut'], ['rejete', 'en_correction'])): ?>
          <div class="card">
            <div class="card-header">Resoumettre une version corrigée</div>
            <form method="POST" enctype="multipart/form-data">
              <div class="form-group">
                <label class="form-label">Note de révision (optionnelle)</label>
                <textarea class="form-control" name="notes" rows="3" placeholder="Décrivez les corrections apportées..."></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">Nouveau fichier PDF * (max 50 Mo)</label>
                <input class="form-control" type="file" name="fichier" accept=".pdf" required/>
              </div>
              <button type="submit" class="btn btn-primary btn-full">Soumettre la version corrigée</button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </main>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
