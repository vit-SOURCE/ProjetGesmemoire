<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/MemoireService.php';

AuthService::requireRole('etudiant');
$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();
$matricule = $role_data['Etu_matricule'];
$type      = $role_data['type'];
$memoires  = MemoireService::getMemoiresEtudiant($matricule);

$statuts = [
    'en_attente'    => ['label' => 'En attente',    'class' => 'badge-pending'],
    'en_correction' => ['label' => 'En correction', 'class' => 'badge-correction'],
    'valide'        => ['label' => 'Validé',         'class' => 'badge-valide'],
    'rejete'        => ['label' => 'Rejeté',         'class' => 'badge-rejete'],
    'archive'       => ['label' => 'Archivé',        'class' => 'badge-archive'],
];

$initiales = strtoupper(substr($user['prenom'],0,1) . substr($user['nom'],0,1));
$title = 'Mon espace'; $base = '../';
include __DIR__ . '/partials/head.php';
?>
<style>
.topbar{position:fixed;top:0;left:0;width:100%;z-index:100;height:60px;background:#fff;border-bottom:1px solid var(--outline-variant);display:flex;align-items:center;justify-content:space-between;padding:0 28px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.topbar-brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:17px;color:var(--primary);text-decoration:none}
.topbar-brand:hover{text-decoration:none}
.topbar-right{display:flex;align-items:center;gap:16px}
.notif-btn{position:relative;background:none;border:none;cursor:pointer;padding:6px}
.notif-btn svg{width:20px;height:20px;color:var(--secondary)}
.notif-dot{position:absolute;top:4px;right:4px;width:8px;height:8px;background:#ef4444;border-radius:50%}
.user-chip{display:flex;align-items:center;gap:10px}
.user-info{text-align:right}
.user-name{font-weight:700;font-size:13px;color:var(--primary)}
.user-role{font-size:10px;color:var(--secondary);text-transform:uppercase;letter-spacing:.06em}
.user-avatar{width:40px;height:40px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
.page-wrap{padding-top:60px;min-height:100vh;background:var(--surface);padding-bottom:40px}
.page-inner{max-width:1100px;margin:0 auto;padding:36px 28px}
.hero-row{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:28px;gap:16px;flex-wrap:wrap}
.hero-title{font-size:28px;font-weight:800;color:var(--primary);line-height:1.2}
.hero-sub{font-size:13px;color:var(--secondary);margin-top:8px;max-width:520px;line-height:1.6}
.nav-pills{display:flex;gap:8px;margin-bottom:28px;flex-wrap:wrap}
.nav-pill{display:inline-flex;align-items:center;gap:7px;padding:9px 18px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid var(--outline-variant);background:#fff;color:var(--secondary);cursor:pointer;text-decoration:none;transition:.2s}
.nav-pill:hover{border-color:var(--primary);color:var(--primary);text-decoration:none}
.nav-pill.active{background:var(--primary);color:#fff;border-color:var(--primary)}
.nav-pill svg{width:15px;height:15px}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px}
.info-card{background:#fff;border-radius:14px;border:1px solid var(--outline-variant);padding:22px}
.card-icon-title{display:flex;align-items:center;gap:8px;margin-bottom:16px}
.card-icon-title svg{width:16px;height:16px;color:var(--secondary)}
.card-icon-title span{font-weight:700;font-size:14px;color:var(--primary)}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--outline-variant);font-size:13px}
.info-row:last-child{border-bottom:none}
.info-label{color:var(--secondary)}
.info-value{font-weight:600;color:var(--on-surface)}
.histo-row{display:flex;justify-content:space-between;align-items:center;padding:11px 0;border-bottom:1px solid var(--outline-variant)}
.histo-row:last-child{border-bottom:none}
.histo-right{display:flex;align-items:center;gap:10px}
.notif-item{display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-bottom:1px solid var(--outline-variant)}
.notif-item:last-child{border-bottom:none}
.notif-icon-box{width:32px;height:32px;border-radius:8px;background:var(--surface-container-low);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.explore-box{background:var(--primary);border-radius:14px;padding:24px;color:#fff;display:flex;flex-direction:column;justify-content:space-between}
.explore-box h3{font-size:17px;font-weight:700;margin-bottom:10px}
.explore-box p{font-size:12px;opacity:.75;line-height:1.7}
.explore-btn{display:inline-flex;align-items:center;gap:6px;margin-top:20px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);color:#fff;padding:10px 18px;border-radius:9px;font-size:13px;font-weight:600;text-decoration:none;width:fit-content;transition:.2s}
.explore-btn:hover{background:rgba(255,255,255,.25);text-decoration:none;color:#fff}
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px}
.stat-mini{background:#fff;border-radius:12px;border:1px solid var(--outline-variant);padding:18px 20px;text-align:center}
.stat-mini-num{font-size:26px;font-weight:800;color:var(--primary)}
.stat-mini-lbl{font-size:11px;color:var(--secondary);text-transform:uppercase;letter-spacing:.06em;margin-top:2px}
@media(max-width:700px){
  .grid-2,.stats-row{grid-template-columns:1fr}
  .hero-row{flex-direction:column}
}
</style>

<div class="page-wrap">

  <!-- Topbar -->
  <div class="topbar">
    <a href="dashboard_etudiant.php" class="topbar-brand">
      <svg xmlns="http://www.w3.org/2000/svg" style="width:22px;height:22px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 14l9-5-9-5-9 5 9 5z"/>
        <path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/>
      </svg>
      GesMemoires
    </a>
    <div class="topbar-right">
      <button class="notif-btn">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <?php if (!empty($memoires)): ?><span class="notif-dot"></span><?php endif; ?>
      </button>
      <div class="user-chip">
        <div class="user-info">
          <div class="user-name"><?= htmlspecialchars($user['prenom'].' '.$user['nom']) ?></div>
          <div class="user-role">ÉTUDIANT</div>
        </div>
        <div class="user-avatar"><?= $initiales ?></div>
      </div>
      <a href="logout.php" style="font-weight:600;font-size:13px;color:var(--error);text-decoration:none">Déconnexion</a>
    </div>
  </div>

  <div class="page-inner">

    <!-- Nav pills -->
    <div class="nav-pills">
      <a href="dashboard_etudiant.php" class="nav-pill active">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Tableau de bord
      </a>
      <?php if ($type === 'diplome'): ?>
      <a href="soumettre_memoire.php" class="nav-pill">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        Soumettre un mémoire
      </a>
      <?php endif; ?>
      <a href="catalogue.php" class="nav-pill">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        Catalogue
      </a>
      <a href="logout.php" class="nav-pill" style="margin-left:auto;color:var(--error);border-color:var(--error-container)">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Déconnexion
      </a>
    </div>

    <!-- Hero -->
    <div class="hero-row">
      <div>
        <div class="hero-title">Bonjour, <?= htmlspecialchars($user['prenom']) ?>.</div>
        <div class="hero-sub">Prêt à soumettre votre nouveau travail de recherche ? Gérez vos documents et suivez vos validations en temps réel.</div>
      </div>
      <?php if ($type === 'diplome'): ?>
      <a href="soumettre_memoire.php" class="btn btn-primary" style="padding:13px 22px;font-size:14px;white-space:nowrap;flex-shrink:0">
        <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Soumettre un mémoire
      </a>
      <?php endif; ?>
    </div>

    <!-- Stats (diplômé seulement) -->
    <?php if ($type === 'diplome'): ?>
    <div class="stats-row">
      <div class="stat-mini">
        <div class="stat-mini-num"><?= count($memoires) ?></div>
        <div class="stat-mini-lbl">Mémoires soumis</div>
      </div>
      <div class="stat-mini">
        <div class="stat-mini-num"><?= count(array_filter($memoires, fn($m) => $m['statut'] === 'valide')) ?></div>
        <div class="stat-mini-lbl">Validés</div>
      </div>
      <div class="stat-mini">
        <div class="stat-mini-num"><?= count(array_filter($memoires, fn($m) => $m['statut'] === 'en_correction')) ?></div>
        <div class="stat-mini-lbl">En correction</div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Infos + Historique -->
    <div class="grid-2">

      <!-- Infos personnelles -->
      <div class="info-card">
        <div class="card-icon-title">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 10-16 0"/></svg>
          <span>Informations personnelles</span>
        </div>
        <div class="info-row"><span class="info-label">Numéro Étudiant</span><span class="info-value" style="font-family:monospace"><?= htmlspecialchars($matricule) ?></span></div>
        <div class="info-row"><span class="info-label">Filière</span><span class="info-value"><?= htmlspecialchars($role_data['filiere_nom'] ?? '—') ?></span></div>
        <div class="info-row"><span class="info-label">Type</span><span class="info-value"><?= $type === 'diplome' ? 'Diplômé' : 'Non diplômé' ?></span></div>
        <div class="info-row">
          <span class="info-label">Statut Global</span>
          <span class="badge badge-valide" style="font-size:11px"><?= strtoupper($role_data['statut'] ?? '') ?></span>
        </div>
      </div>

      <!-- Historique soumissions -->
      <div class="info-card">
        <div class="card-icon-title" style="justify-content:space-between">
          <div style="display:flex;align-items:center;gap:8px">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <span>Historique des soumissions</span>
          </div>
          <span style="font-size:12px;color:var(--secondary)">(<?= count($memoires) ?> document<?= count($memoires) > 1 ? 's' : '' ?>)</span>
        </div>

        <?php if (empty($memoires)): ?>
          <div style="text-align:center;padding:28px 0">
            <p style="color:var(--secondary);font-size:13px;margin-bottom:10px">Vous n'avez soumis aucun mémoire pour le moment.</p>
            <?php if ($type === 'diplome'): ?>
              <a href="soumettre_memoire.php" style="font-weight:600;font-size:13px;color:var(--primary)">Faire mon premier dépôt</a>
            <?php else: ?>
              <a href="catalogue.php" style="font-weight:600;font-size:13px;color:var(--primary)">Explorer le catalogue</a>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <?php foreach (array_slice($memoires, 0, 4) as $m): ?>
            <div class="histo-row">
              <div>
                <div style="font-weight:600;font-size:13px"><?= htmlspecialchars(strlen($m['titre']) > 45 ? substr($m['titre'],0,45).'...' : $m['titre']) ?></div>
                <div style="font-size:11px;color:var(--secondary)"><?= $m['annee'] ?></div>
              </div>
              <div class="histo-right">
                <span class="badge <?= $statuts[$m['statut']]['class'] ?? '' ?>" style="font-size:10px"><?= $statuts[$m['statut']]['label'] ?? $m['statut'] ?></span>
                <a href="espace_suivi.php?id=<?= $m['id_memoire'] ?>" style="font-size:12px;font-weight:600;color:var(--primary);white-space:nowrap">Suivi →</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Notifications + Explorer -->
    <div class="grid-2">

      <!-- Notifications -->
      <div class="info-card">
        <div class="card-icon-title">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
          <span>Dernières Notifications</span>
        </div>
        <?php if (empty($memoires)): ?>
          <div class="notif-item">
            <div class="notif-icon-box">
              <svg xmlns="http://www.w3.org/2000/svg" style="width:14px;height:14px;color:var(--primary)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </div>
            <div>
              <div style="font-size:13px">Bienvenue sur GesMemoires !</div>
              <div style="font-size:11px;color:var(--secondary)">À l'instant</div>
            </div>
          </div>
        <?php else: ?>
          <?php foreach (array_slice($memoires, 0, 3) as $m): ?>
            <div class="notif-item">
              <div class="notif-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" style="width:14px;height:14px;color:var(--primary)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <div>
                <div style="font-size:13px">
                  Mémoire <strong>"<?= htmlspecialchars(substr($m['titre'],0,35)).(strlen($m['titre'])>35?'...':'') ?>"</strong>
                  — <?= $statuts[$m['statut']]['label'] ?? $m['statut'] ?>
                </div>
                <div style="font-size:11px;color:var(--secondary)"><?= $m['date_envoi'] ? date('d/m/Y', strtotime($m['date_envoi'])) : 'Récemment' ?></div>
              </div>
            </div>
          <?php endforeach; ?>
          <?php if (!empty($memoires[0]['commentaire_maitre'])): ?>
            <div class="notif-item">
              <div class="notif-icon-box">
                <svg xmlns="http://www.w3.org/2000/svg" style="width:14px;height:14px;color:var(--warning)" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </div>
              <div>
                <div style="font-size:13px">Annotation reçue de votre maître de mémoire.</div>
                <div style="font-size:11px;color:var(--secondary)">Récemment</div>
              </div>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </div>

      <!-- Explorer la bibliothèque -->
      <div class="explore-box">
        <div>
          <h3>Explorer la Bibliothèque</h3>
          <p>Consultez les mémoires publics et travaux de recherche validés par nos jurys pour vous inspirer et faire avancer votre projet académique.</p>
        </div>
        <a href="catalogue.php" class="explore-btn">
          <svg xmlns="http://www.w3.org/2000/svg" style="width:15px;height:15px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
          Explorer le catalogue
        </a>
      </div>
    </div>

  </div>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
