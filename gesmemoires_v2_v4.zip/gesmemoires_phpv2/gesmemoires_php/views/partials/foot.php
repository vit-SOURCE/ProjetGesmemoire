  <script src="<?= $base ?? '../' ?>assets/js/app.js"></script>
  <?php if (!empty($extraJs)) echo $extraJs; ?>
</body>
</html>
