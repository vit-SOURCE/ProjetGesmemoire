<?php
require_once __DIR__ . '/../../services/AuthService.php';
$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();
$role      = $user['role'] ?? '';
$nom_complet = ($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? '');

$matricule = match($role) {
    'etudiant'   => $role_data['matricule'] ?? '',
    'professeur' => $role_data['matricule'] ?? '',
    'de'         => $role_data['DE_matricule'] ?? '',
    default      => ''
};
?>
<nav class="navbar">
  <div class="navbar-brand">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M12 14l9-5-9-5-9 5 9 5z"/><path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/>
    </svg>
    GesMemoires
  </div>
  <div class="flex items-center gap-3">
    <span style="font-size:12px;color:var(--secondary)">
      <?= htmlspecialchars($nom_complet) ?>
      <?php if ($matricule): ?>
        <span style="background:var(--surface-container-low);padding:2px 8px;border-radius:6px;margin-left:6px;font-weight:600;color:var(--primary)"><?= htmlspecialchars($matricule) ?></span>
      <?php endif; ?>
    </span>
    <a href="<?= $base ?? '../' ?>views/logout.php" class="btn btn-secondary btn-sm">Déconnexion</a>
  </div>
</nav>
