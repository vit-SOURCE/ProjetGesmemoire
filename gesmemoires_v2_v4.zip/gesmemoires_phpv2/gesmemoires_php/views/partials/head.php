<?php
$title = $title ?? 'GesMemoires';
$base  = $base  ?? '../';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?= htmlspecialchars($title) ?> — GesMemoires</title>
  <link rel="stylesheet" href="<?= $base ?>assets/css/style.css"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
</head>
<body>
