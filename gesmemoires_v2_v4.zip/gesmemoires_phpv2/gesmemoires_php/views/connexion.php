<?php
require_once __DIR__ . '/../services/AuthService.php';

// Rediriger si déjà connecté
if (AuthService::isLoggedIn()) {
    $u = AuthService::getCurrentUser();
    $dest = match($u['role']) {
        'etudiant'   => 'dashboard_etudiant.php',
        'professeur' => 'dashboard_professeur.php',
        'de'         => 'dashboard_de.php',
        default      => 'connexion.php'
    };
    header("Location: $dest"); exit;
}

$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$email || !$password) {
        $erreur = 'Veuillez remplir tous les champs.';
    } else {
        $result = AuthService::login($email, $password);
        if ($result['ok']) {
            $role = $result['user']['role'];
            $dest = match($role) {
                'etudiant'   => 'dashboard_etudiant.php',
                'professeur' => 'dashboard_professeur.php',
                'de'         => 'dashboard_de.php',
                default      => 'connexion.php'
            };
            header("Location: $dest"); exit;
        } else {
            $erreur = $result['message'];
        }
    }
}

$title = 'Connexion'; $base = '../';
include __DIR__ . '/partials/head.php';
?>

<div class="auth-page">
  <div class="auth-box">

    <div class="auth-logo">
      <div class="auth-logo-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 14l9-5-9-5-9 5 9 5z"/>
          <path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/>
        </svg>
      </div>
      <h1>GesMemoires</h1>
      <p>Portail académique de gestion des mémoires</p>
    </div>

    <?php if ($erreur): ?>
      <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="form-group">
        <label class="form-label" for="email">Adresse e-mail</label>
        <input class="form-control" type="email" id="email" name="email"
               placeholder="nom@uac.bj" required
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"/>
      </div>

      <div class="form-group">
        <div class="flex justify-between items-center mb-2">
          <label class="form-label" for="password">Mot de passe</label>
          <a href="#" style="font-size:12px" onclick="showAlert('Option bientôt disponible.','info');return false;">Mot de passe oublié ?</a>
        </div>
        <input class="form-control" type="password" id="password" name="password"
               placeholder="••••••••" required/>
      </div>

      <button type="submit" class="btn btn-primary btn-full mt-4">Se connecter</button>
    </form>

    <hr class="divider"/>

    <p class="text-center text-sm text-muted">
      Nouvel étudiant ?
      <a href="inscription.php" style="font-weight:600">Créer un compte</a>
    </p>
    <p class="text-center mt-2" style="font-size:11px;color:var(--outline)">
      © 2026 GesMemoires — UATM GASA
    </p>

  </div>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
