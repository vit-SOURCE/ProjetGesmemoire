<?php
/**
 * download.php — Téléchargement sécurisé des PDFs
 * Accès via ?id=id_memoire
 */
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../models/Memoire.php';

AuthService::requireLogin();

$id_memoire = (int)($_GET['id'] ?? 0);
if (!$id_memoire) { http_response_code(400); die('Identifiant invalide.'); }

$memoire = (new Memoire())->findById($id_memoire);
if (!$memoire || empty($memoire['fichier'])) {
    http_response_code(404); die('Mémoire introuvable.');
}

$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();
$role      = $user['role'];
$autorise  = false;

// Mémoire publié ou archivé → tout le monde connecté peut lire
if (!empty($memoire['date_publication']) || $memoire['statut'] === 'archive') {
    $autorise = true;
}
// Non publié → accès restreint
elseif ($role === 'de') {
    $autorise = true;
} elseif ($role === 'etudiant') {
    $autorise = ($memoire['Etu_matricule'] === ($role_data['Etu_matricule'] ?? ''));
} elseif ($role === 'professeur') {
    $autorise = ($memoire['Prof_matricule'] === ($role_data['Prof_matricule'] ?? ''));
}

if (!$autorise) {
    http_response_code(403);
    die('Accès refusé. Ce mémoire n\'est pas encore publié.');
}

$fichier = basename($memoire['fichier']);
$chemin  = __DIR__ . '/../uploads/memoires/' . $fichier;

if (!file_exists($chemin)) {
    http_response_code(404);
    die('Fichier introuvable sur le serveur. (Chemin : ' . htmlspecialchars($chemin) . ')');
}

$nom = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $memoire['titre']) . '.pdf';

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . $nom . '"');
header('Content-Length: ' . filesize($chemin));
header('Cache-Control: private, no-cache');
readfile($chemin);
exit;
