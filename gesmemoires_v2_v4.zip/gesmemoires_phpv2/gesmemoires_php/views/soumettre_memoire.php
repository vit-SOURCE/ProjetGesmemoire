<?php
require_once __DIR__ . '/../services/AuthService.php';
require_once __DIR__ . '/../services/MemoireService.php';
require_once __DIR__ . '/../models/DE.php';

AuthService::requireRole('etudiant');
$user      = AuthService::getCurrentUser();
$role_data = AuthService::getCurrentRoleData();

if ($role_data['type'] !== 'diplome') {
    header('Location: dashboard_etudiant.php'); exit;
}

// Récupérer le Prof_matricule depuis la table etudiant (pas la session — peut être assigné après connexion)
$db = getDB();
$etu_row = $db->prepare(
    "SELECT e.Prof_matricule, CONCAT(u.prenom, ' ', u.nom) AS prof_nom
     FROM etudiant e
     LEFT JOIN professeur p ON e.Prof_matricule = p.Prof_matricule
     LEFT JOIN utilisateur u ON p.id_utilisateur = u.id_utilisateur
     WHERE e.Etu_matricule = ?"
);
$etu_row->execute([$role_data['Etu_matricule']]);
$etu_info = $etu_row->fetch();
$prof_matricule = $etu_info['Prof_matricule'] ?? null;
$prof_nom       = $etu_info['prof_nom']       ?? null;

// Récupérer le DE actif
$de = $db->query("SELECT DE_matricule FROM de LIMIT 1")->fetch() ?: [];

$erreur = ''; $succes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'titre'          => trim($_POST['titre'] ?? ''),
        'annee'          => (int)($_POST['annee'] ?? date('Y')),
        'etu_matricule'  => $role_data['Etu_matricule'],
        'prof_matricule' => $prof_matricule,
        'de_matricule'   => $de['DE_matricule'] ?? '',
    ];

    if (!$data['titre'] || !$data['annee']) {
        $erreur = 'Veuillez remplir tous les champs obligatoires.';
    } elseif (empty($_FILES['fichier']['name'])) {
        $erreur = 'Veuillez sélectionner un fichier PDF.';
    } elseif (!$data['de_matricule']) {
        $erreur = 'Aucun Directeur des Études trouvé. Contactez l\'administration.';
    } else {
        $result = MemoireService::soumettre($data, $_FILES['fichier']);
        if ($result['ok']) {
            $succes = 'Votre mémoire a été soumis avec succès. Il sera examiné par votre maître de mémoire.';
        } else {
            $erreur = $result['message'];
        }
    }
}

$title = 'Soumettre un mémoire'; $base = '../';
include __DIR__ . '/partials/head.php';
include __DIR__ . '/partials/navbar.php';
?>

<div class="dashboard">
  <aside class="sidebar">
    <div class="sidebar-section-title">Navigation</div>
    <nav class="sidebar-nav">
      <a href="dashboard_etudiant.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
        Retour au tableau de bord
      </a>
    </nav>
  </aside>

  <main class="main-content">
    <div class="page-title">Soumettre un mémoire</div>
    <div class="page-subtitle">Remplissez les informations de votre mémoire et uploadez le fichier PDF.</div>

    <?php if ($erreur): ?>
      <div class="alert alert-error"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>
    <?php if ($succes): ?>
      <div class="alert alert-success"><?= htmlspecialchars($succes) ?></div>
      <a href="dashboard_etudiant.php" class="btn btn-primary">Retour au tableau de bord</a>
    <?php else: ?>

    <?php if ($prof_matricule): ?>
      <div class="alert alert-info" style="margin-bottom:20px">
        Votre maître de mémoire assigné :
        <strong><?= htmlspecialchars($prof_nom ?? $prof_matricule) ?></strong>
      </div>
    <?php else: ?>
      <div class="alert alert-warning" style="margin-bottom:20px">
        Aucun maître de mémoire ne vous a encore été assigné. Votre mémoire sera soumis sans encadreur pour le moment.
      </div>
    <?php endif; ?>

    <div class="card" style="max-width:680px">
      <form method="POST" enctype="multipart/form-data">

        <div class="form-group">
          <label class="form-label">Titre du mémoire *</label>
          <input class="form-control" type="text" name="titre" required
                 placeholder="Ex: Mise en place d'un système de gestion hospitalière"
                 value="<?= htmlspecialchars($_POST['titre'] ?? '') ?>"/>
        </div>

        <div class="form-group">
          <label class="form-label">Année *</label>
          <input class="form-control" type="number" name="annee" min="2000" max="2030"
                 value="<?= (int)($_POST['annee'] ?? date('Y')) ?>" required/>
        </div>

        <div class="form-group">
          <label class="form-label">Fichier PDF * (max 50 Mo)</label>
          <div style="border:2px dashed var(--outline-variant);border-radius:12px;padding:28px;text-align:center;cursor:pointer;transition:.2s"
               onclick="document.getElementById('fichier-input').click()"
               id="drop-zone">
            <div style="font-size:28px;margin-bottom:8px">📄</div>
            <div style="font-weight:600;color:var(--primary)" id="file-label">Cliquez pour sélectionner un PDF</div>
            <div class="text-sm text-muted mt-1">ou glissez-déposez votre fichier ici</div>
          </div>
          <input type="file" id="fichier-input" name="fichier" accept=".pdf" style="display:none"
                 onchange="document.getElementById('file-label').textContent = this.files[0]?.name || 'Sélectionner un PDF'"/>
        </div>

        <div class="flex gap-3 mt-4">
          <a href="dashboard_etudiant.php" class="btn btn-secondary">Annuler</a>
          <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">Soumettre le mémoire</button>
        </div>
      </form>
    </div>
    <?php endif; ?>
  </main>
</div>

<?php include __DIR__ . '/partials/foot.php'; ?>
