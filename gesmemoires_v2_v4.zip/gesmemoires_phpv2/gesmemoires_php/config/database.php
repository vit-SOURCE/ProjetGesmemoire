<?php
define('DB_HOST', 'sql104.infinityfree.com');
define('DB_USER', 'if0_42061389');
define('DB_PASS', '3fXQv5Ja9wnbc');
define('DB_NAME', 'if0_42061389_gesmemoires');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Connexion BDD échouée : '.$e->getMessage()]));
        }
    }
    return $pdo;
}
