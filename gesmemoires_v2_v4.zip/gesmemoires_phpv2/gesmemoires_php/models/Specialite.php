<?php
require_once __DIR__ . '/../config/database.php';

class Specialite {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function findAll(): array {
        $stmt = $this->db->query("SELECT * FROM specialite ORDER BY libelle");
        return $stmt->fetchAll();
    }

    public function findById(int $id): array|false {
        $stmt = $this->db->prepare("SELECT * FROM specialite WHERE id_specialite = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function assignerAuProfesseur(int $id_utilisateur, int $id_specialite): bool {
        // Récupérer Prof_matricule depuis id_utilisateur
        $stmt = $this->db->prepare("SELECT Prof_matricule FROM professeur WHERE id_utilisateur = ?");
        $stmt->execute([$id_utilisateur]);
        $prof = $stmt->fetch();
        if (!$prof) return false;

        $stmt = $this->db->prepare(
            "INSERT IGNORE INTO expertise_maitre (Prof_matricule, id_specialite) VALUES (?, ?)"
        );
        return $stmt->execute([$prof['Prof_matricule'], $id_specialite]);
    }

    public function findByProfesseur(string $prof_matricule): array {
        $stmt = $this->db->prepare(
            "SELECT s.* FROM specialite s
             JOIN expertise_maitre em ON s.id_specialite = em.id_specialite
             WHERE em.Prof_matricule = ?"
        );
        $stmt->execute([$prof_matricule]);
        return $stmt->fetchAll();
    }
}
