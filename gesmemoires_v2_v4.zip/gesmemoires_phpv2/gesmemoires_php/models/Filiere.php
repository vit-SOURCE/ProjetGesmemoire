<?php
require_once __DIR__ . '/../config/database.php';

class Filiere {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function findAll(): array {
        $stmt = $this->db->query("SELECT * FROM filiere ORDER BY nom");
        return $stmt->fetchAll();
    }

    public function findById(int $id): array|false {
        $stmt = $this->db->prepare("SELECT * FROM filiere WHERE id_filiere = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create(string $nom, string $description = ''): int {
        $stmt = $this->db->prepare("INSERT INTO filiere (nom, description) VALUES (?, ?)");
        $stmt->execute([$nom, $description]);
        return (int) $this->db->lastInsertId();
    }
}