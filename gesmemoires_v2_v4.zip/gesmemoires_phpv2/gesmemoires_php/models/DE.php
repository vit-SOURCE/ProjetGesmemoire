<?php
require_once __DIR__ . '/../config/database.php';

class DE {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function create(int $id_utilisateur, string $bureau, string $telephone): string {
        $matricule = $this->genererMatricule();
        $stmt = $this->db->prepare(
            "INSERT INTO de (DE_matricule, id_utilisateur, bureau, telephone) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$matricule, $id_utilisateur, $bureau, $telephone]);
        return $matricule;
    }

    public function findByUserId(int $id_utilisateur): array|false {
        $stmt = $this->db->prepare(
            "SELECT d.*, u.nom, u.prenom, u.email
             FROM de d
             JOIN utilisateur u ON d.id_utilisateur = u.id_utilisateur
             WHERE d.id_utilisateur = ?"
        );
        $stmt->execute([$id_utilisateur]);
        return $stmt->fetch();
    }

    public function findByMatricule(string $matricule): array|false {
        $stmt = $this->db->prepare(
            "SELECT d.*, u.nom, u.prenom, u.email
             FROM de d
             JOIN utilisateur u ON d.id_utilisateur = u.id_utilisateur
             WHERE d.DE_matricule = ?"
        );
        $stmt->execute([$matricule]);
        return $stmt->fetch();
    }

    private function genererMatricule(): string {
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM de");
        $total = (int) $stmt->fetch()['total'];
        return 'de' . str_pad($total + 1, 3, '0', STR_PAD_LEFT);
    }
}