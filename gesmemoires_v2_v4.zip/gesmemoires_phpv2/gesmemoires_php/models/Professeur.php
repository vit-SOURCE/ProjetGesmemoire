<?php
require_once __DIR__ . '/../config/database.php';

class Professeur {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function create(int $id_utilisateur, bool $est_maitre_memoire, string $statut): string {
        $matricule = $this->genererMatricule();
        $stmt = $this->db->prepare(
            "INSERT INTO professeur (Prof_matricule, id_utilisateur, est_maitre_memoire, statut)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$matricule, $id_utilisateur, (int)$est_maitre_memoire, $statut]);
        return $matricule;
    }

    public function findByMatricule(string $matricule): array|false {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.nom, u.prenom, u.email
             FROM professeur p
             JOIN utilisateur u ON p.id_utilisateur = u.id_utilisateur
             WHERE p.Prof_matricule = ?"
        );
        $stmt->execute([$matricule]);
        return $stmt->fetch();
    }

    public function findByUserId(int $id_utilisateur): array|false {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.nom, u.prenom, u.email
             FROM professeur p
             JOIN utilisateur u ON p.id_utilisateur = u.id_utilisateur
             WHERE p.id_utilisateur = ?"
        );
        $stmt->execute([$id_utilisateur]);
        return $stmt->fetch();
    }

    public function findMaitresActifs(): array {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.nom, u.prenom, u.email
             FROM professeur p
             JOIN utilisateur u ON p.id_utilisateur = u.id_utilisateur
             WHERE p.est_maitre_memoire = 1 AND p.statut = 'actif'"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findEnAttente(): array {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.nom, u.prenom, u.email
             FROM professeur p
             JOIN utilisateur u ON p.id_utilisateur = u.id_utilisateur
             WHERE p.statut = 'en_attente'
             ORDER BY p.Prof_matricule DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function updateStatut(string $matricule, string $statut): bool {
        $stmt = $this->db->prepare(
            "UPDATE professeur SET statut = ? WHERE Prof_matricule = ?"
        );
        return $stmt->execute([$statut, $matricule]);
    }

    public function getSpecialites(string $matricule): array {
        $stmt = $this->db->prepare(
            "SELECT s.libelle FROM specialite s
             JOIN expertise_maitre em ON s.id_specialite = em.id_specialite
             WHERE em.Prof_matricule = ?"
        );
        $stmt->execute([$matricule]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    private function genererMatricule(): string {
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM professeur");
        $total = (int) $stmt->fetch()['total'];
        return 'pro' . str_pad($total + 1, 3, '0', STR_PAD_LEFT);
    }
}