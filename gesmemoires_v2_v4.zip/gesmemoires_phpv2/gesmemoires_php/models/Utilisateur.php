<?php
require_once __DIR__ . '/../config/database.php';

class Utilisateur {
    private PDO $db;

    public int    $id_utilisateur;
    public string $nom;
    public string $prenom;
    public string $email;
    public string $password;
    public string $role;

    public function __construct() {
        $this->db = getDB();
    }

    public function findByEmail(string $email): array|false {
        $stmt = $this->db->prepare("SELECT * FROM utilisateur WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }

    public function findById(int $id): array|false {
        $stmt = $this->db->prepare("SELECT * FROM utilisateur WHERE id_utilisateur = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create(string $nom, string $prenom, string $email, string $password, string $role): int {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare(
            "INSERT INTO utilisateur (nom, prenom, email, password, role) VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([$nom, $prenom, $email, $hash, $role]);
        return (int) $this->db->lastInsertId();
    }

    public function verifyPassword(string $plainPassword, string $hash): bool {
        return password_verify($plainPassword, $hash);
    }

    public function findByRole(string $role): array {
        $stmt = $this->db->prepare("SELECT * FROM utilisateur WHERE role = ?");
        $stmt->execute([$role]);
        return $stmt->fetchAll();
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM utilisateur WHERE id_utilisateur = ?");
        return $stmt->execute([$id]);
    }
}