<?php
require_once __DIR__ . '/../config/database.php';

class Etudiant {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function create(int $id_utilisateur, string $type, string $statut, ?int $id_filiere): string {
        $matricule = $this->genererMatricule();
        $stmt = $this->db->prepare(
            "INSERT INTO etudiant (Etu_matricule, id_utilisateur, type, statut, id_filiere)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([$matricule, $id_utilisateur, $type, $statut, $id_filiere]);
        return $matricule;
    }

    public function findByMatricule(string $matricule): array|false {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email, u.role, f.nom AS filiere_nom
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             LEFT JOIN filiere f ON e.id_filiere = f.id_filiere
             WHERE e.Etu_matricule = ?"
        );
        $stmt->execute([$matricule]);
        return $stmt->fetch();
    }

    public function findByUserId(int $id_utilisateur): array|false {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email, f.nom AS filiere_nom
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             LEFT JOIN filiere f ON e.id_filiere = f.id_filiere
             WHERE e.id_utilisateur = ?"
        );
        $stmt->execute([$id_utilisateur]);
        return $stmt->fetch();
    }

    public function findByStatut(string $statut): array {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email, f.nom AS filiere_nom
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             LEFT JOIN filiere f ON e.id_filiere = f.id_filiere
             WHERE e.statut = ?"
        );
        $stmt->execute([$statut]);
        return $stmt->fetchAll();
    }

    public function findDiplomesActifs(): array {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email, f.nom AS filiere_nom
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             LEFT JOIN filiere f ON e.id_filiere = f.id_filiere
             WHERE e.type = 'diplome' AND e.statut = 'actif'"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function updateStatut(string $matricule, string $statut): bool {
		$stmt = $this->db->prepare("UPDATE etudiant SET statut = ? WHERE Etu_matricule = ?");
        return $stmt->execute([$statut, $matricule]);
    }

    public function findEnAttente(): array {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email, u.id_utilisateur
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             WHERE e.statut = 'en_attente'
             ORDER BY e.Etu_matricule DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Étudiants diplômés actifs sans prof assigné
    public function findDiplomesActifsSansProf(): array {
        $stmt = $this->db->prepare(
            "SELECT e.*, u.nom, u.prenom, u.email,
                    CONCAT(u.prenom, ' ', u.nom) AS etudiant_nom,
                    f.nom AS filiere_nom
             FROM etudiant e
             JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur
             LEFT JOIN filiere f ON e.id_filiere = f.id_filiere
             WHERE e.type = 'diplome'
               AND e.statut = 'actif'
               AND (e.Prof_matricule IS NULL OR e.Prof_matricule = '')"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Assigner un prof directement à l'étudiant
    public function updateProf(string $etu_matricule, string $prof_matricule): bool {
        $stmt = $this->db->prepare("UPDATE etudiant SET Prof_matricule = ? WHERE Etu_matricule = ?");
        return $stmt->execute([$prof_matricule, $etu_matricule]);
    }

        private function genererMatricule(): string {
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM etudiant");
        $total = (int) $stmt->fetch()['total'];
        return 'etu' . str_pad($total + 1, 3, '0', STR_PAD_LEFT);
    }
}