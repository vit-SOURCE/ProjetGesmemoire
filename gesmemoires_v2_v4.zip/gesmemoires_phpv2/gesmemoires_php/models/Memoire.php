<?php
require_once __DIR__ . '/../config/database.php';

class Memoire {
    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function create(
        string $titre,
        int    $annee,
        string $fichier,
        string $etu_matricule,
        ?string $prof_matricule,
        ?string $de_matricule
    ): int {
        $stmt = $this->db->prepare(
            "INSERT INTO memoire
             (titre, annee, fichier, statut, date_envoi, Etu_matricule, Prof_matricule, DE_matricule)
             VALUES (?, ?, ?, 'en_attente', NOW(), ?, ?, ?)"
        );
        $stmt->execute([$titre, $annee, $fichier, $etu_matricule, $prof_matricule, $de_matricule]);
        return (int) $this->db->lastInsertId();
    }

    public function createArchive(
        string $titre,
        int    $annee,
        string $fichier,
        string $de_matricule
    ): int {
        $stmt = $this->db->prepare(
            "INSERT INTO memoire
             (titre, annee, fichier, statut, date_publication, DE_matricule)
             VALUES (?, ?, ?, 'archive', NOW(), ?)"
        );
        $stmt->execute([$titre, $annee, $fichier, $de_matricule]);
        return (int) $this->db->lastInsertId();
    }

    public function findById(int $id): array|false {
        $stmt = $this->db->prepare(
            "SELECT m.*,
                    CONCAT(ue.prenom, ' ', ue.nom) AS etudiant_nom,
                    CONCAT(up.prenom, ' ', up.nom) AS prof_nom
             FROM memoire m
             LEFT JOIN etudiant e     ON m.Etu_matricule  = e.Etu_matricule
             LEFT JOIN utilisateur ue ON e.id_utilisateur = ue.id_utilisateur
             LEFT JOIN professeur p   ON m.Prof_matricule = p.Prof_matricule
             LEFT JOIN utilisateur up ON p.id_utilisateur = up.id_utilisateur
             WHERE m.id_memoire = ?"
        );
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function findByEtudiant(string $etu_matricule): array {
        $stmt = $this->db->prepare(
            "SELECT * FROM memoire WHERE Etu_matricule = ? ORDER BY date_envoi DESC"
        );
        $stmt->execute([$etu_matricule]);
        return $stmt->fetchAll();
    }

    public function findByProfesseur(string $prof_matricule): array {
        $stmt = $this->db->prepare(
            "SELECT m.*, CONCAT(ue.prenom, ' ', ue.nom) AS etudiant_nom
             FROM memoire m
             LEFT JOIN etudiant e     ON m.Etu_matricule  = e.Etu_matricule
             LEFT JOIN utilisateur ue ON e.id_utilisateur = ue.id_utilisateur
             WHERE m.Prof_matricule = ?
             ORDER BY m.date_envoi DESC"
        );
        $stmt->execute([$prof_matricule]);
        return $stmt->fetchAll();
    }

    // Catalogue public — mémoires publiés (date_publication définie) ou archivés
    public function findValides(): array {
        $stmt = $this->db->prepare(
            "SELECT m.*, CONCAT(ue.prenom, ' ', ue.nom) AS etudiant_nom
             FROM memoire m
             LEFT JOIN etudiant e     ON m.Etu_matricule  = e.Etu_matricule
             LEFT JOIN utilisateur ue ON e.id_utilisateur = ue.id_utilisateur
             WHERE (
                 (m.statut = 'valide' AND m.date_publication IS NOT NULL)
                 OR m.statut = 'archive'
             )
             ORDER BY m.date_publication DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Pour le DE : une seule ligne par étudiant (la version la plus récente)
    // On exclut les archives qui ont leur propre section
    public function findAll(): array {
        $stmt = $this->db->prepare(
            "SELECT m.*, CONCAT(ue.prenom, ' ', ue.nom) AS etudiant_nom,
                    CONCAT(up.prenom, ' ', up.nom) AS prof_nom
             FROM memoire m
             INNER JOIN (
                 SELECT Etu_matricule, MAX(id_memoire) AS last_id
                 FROM memoire
                 WHERE Etu_matricule IS NOT NULL
                 GROUP BY Etu_matricule
             ) latest ON m.id_memoire = latest.last_id
             LEFT JOIN etudiant e     ON m.Etu_matricule  = e.Etu_matricule
             LEFT JOIN utilisateur ue ON e.id_utilisateur = ue.id_utilisateur
             LEFT JOIN professeur p   ON m.Prof_matricule = p.Prof_matricule
             LEFT JOIN utilisateur up ON p.id_utilisateur = up.id_utilisateur
             ORDER BY m.date_envoi DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findArchives(): array {
        $stmt = $this->db->prepare(
            "SELECT m.*, CONCAT(ud.prenom, ' ', ud.nom) AS de_nom
             FROM memoire m
             LEFT JOIN de d           ON m.DE_matricule  = d.DE_matricule
             LEFT JOIN utilisateur ud ON d.id_utilisateur = ud.id_utilisateur
             WHERE m.statut = 'archive'
             ORDER BY m.date_publication DESC"
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function search(string $q): array {
        $like = "%$q%";
        $stmt = $this->db->prepare(
            "SELECT m.*, CONCAT(ue.prenom, ' ', ue.nom) AS etudiant_nom
             FROM memoire m
             LEFT JOIN etudiant e     ON m.Etu_matricule  = e.Etu_matricule
             LEFT JOIN utilisateur ue ON e.id_utilisateur = ue.id_utilisateur
             WHERE m.titre LIKE ?
             AND (
                 (m.statut = 'valide' AND m.date_publication IS NOT NULL)
                 OR m.statut = 'archive'
             )
             ORDER BY m.date_publication DESC"
        );
        $stmt->execute([$like]);
        return $stmt->fetchAll();
    }

    public function updateStatut(int $id, string $statut, ?string $commentaire = null): bool {
        if ($commentaire !== null) {
            $stmt = $this->db->prepare(
                "UPDATE memoire SET statut = ?, commentaire_maitre = ? WHERE id_memoire = ?"
            );
            return $stmt->execute([$statut, $commentaire, $id]);
        }
        $stmt = $this->db->prepare("UPDATE memoire SET statut = ? WHERE id_memoire = ?");
        return $stmt->execute([$statut, $id]);
    }

    // Publier : passe statut à 'valide' ET définit date_publication
    public function publier(int $id): bool {
        $stmt = $this->db->prepare(
            "UPDATE memoire SET statut = 'valide', date_publication = NOW()
             WHERE id_memoire = ?"
        );
        return $stmt->execute([$id]) && $stmt->rowCount() > 0;
    }

    public function getStats(): array {
        $stmt = $this->db->query(
            "SELECT
                COUNT(*) AS total,
                SUM(statut = 'en_attente')    AS en_attente,
                SUM(statut = 'en_correction') AS en_correction,
                SUM(statut = 'valide')        AS valide,
                SUM(statut = 'rejete')        AS rejete,
                SUM(statut = 'archive')       AS archive
             FROM memoire"
        );
        return $stmt->fetch();
    }
}
