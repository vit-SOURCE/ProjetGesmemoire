<?php
require_once __DIR__ . '/../models/Utilisateur.php';
require_once __DIR__ . '/../models/Etudiant.php';
require_once __DIR__ . '/../models/Professeur.php';
require_once __DIR__ . '/../models/DE.php';
require_once __DIR__ . '/../models/Specialite.php';

class AuthService {

    public static function login(string $email, string $password): array {
        $utilisateurModel = new Utilisateur();
        $user = $utilisateurModel->findByEmail($email);
        if (!$user) return ['ok' => false, 'message' => 'Email ou mot de passe incorrect.'];
        if (!$utilisateurModel->verifyPassword($password, $user['password']))
            return ['ok' => false, 'message' => 'Email ou mot de passe incorrect.'];

        $role_data = self::getRoleData($user);
        if (!$role_data) return ['ok' => false, 'message' => 'Compte incomplet. Contactez le DE.'];

        if (in_array($user['role'], ['etudiant', 'professeur'])) {
            if ($role_data['statut'] === 'en_attente')
                return ['ok' => false, 'message' => 'Compte en attente de validation par le DE.'];
            if ($role_data['statut'] === 'inactif')
                return ['ok' => false, 'message' => 'Compte désactivé. Contactez le DE.'];
        }

        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['user']      = $user;
        $_SESSION['role_data'] = $role_data;
        return ['ok' => true, 'user' => $user, 'role_data' => $role_data];
    }

    public static function inscrire(array $data): array {
        $utilisateurModel = new Utilisateur();
        if ($utilisateurModel->findByEmail($data['email']))
            return ['ok' => false, 'message' => 'Cet email est déjà utilisé.'];

        $role = $data['role'];
        try {
            $id_utilisateur = $utilisateurModel->create(
                $data['nom'], $data['prenom'], $data['email'], $data['password'], $role
            );

            if ($role === 'etudiant') {
                $m = new Etudiant();
               $matricule = $m->create($id_utilisateur, $data['type'], 'en_attente', !empty($data['id_filiere']) ? (int)$data['id_filiere'] : null);
				return ['ok' => true, 'matricule' => $matricule, 'statut' => 'en_attente', 'role' => $role];
            } elseif ($role === 'professeur') {
                $m = new Professeur();
                $matricule = $m->create($id_utilisateur, true, 'en_attente');
                if (!empty($data['specialites'])) {
                    $sm = new Specialite();
                    foreach ($data['specialites'] as $id_spec)
                        $sm->assignerAuProfesseur($id_utilisateur, (int)$id_spec);
                }
                return ['ok' => true, 'matricule' => $matricule, 'statut' => 'en_attente', 'role' => $role];
            }
            return ['ok' => false, 'message' => 'Rôle invalide.'];
        } catch (Exception $e) {
            return ['ok' => false, 'message' => 'Erreur : ' . $e->getMessage()];
        }
    }

    public static function logout(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_destroy();
    }

    public static function isLoggedIn(): bool {
        if (session_status() === PHP_SESSION_NONE) session_start();
        return isset($_SESSION['user']);
    }

    public static function getCurrentUser(): array|null {
        if (session_status() === PHP_SESSION_NONE) session_start();
        return $_SESSION['user'] ?? null;
    }

    public static function getCurrentRoleData(): array|null {
        if (session_status() === PHP_SESSION_NONE) session_start();
        return $_SESSION['role_data'] ?? null;
    }

    public static function requireLogin(): void {
        if (!self::isLoggedIn()) { header("Location: ../views/connexion.php"); exit; }
    }

    public static function requireRole(string $role): void {
        self::requireLogin();
        $user = self::getCurrentUser();
        if ($user['role'] !== $role) { header("Location: ../views/connexion.php"); exit; }
    }

    private static function getRoleData(array $user): array|false {
        return match($user['role']) {
            'etudiant'   => (new Etudiant())->findByUserId($user['id_utilisateur']),
            'professeur' => (new Professeur())->findByUserId($user['id_utilisateur']),
            'de'         => (new DE())->findByUserId($user['id_utilisateur']),
            default      => false
        };
    }
}
