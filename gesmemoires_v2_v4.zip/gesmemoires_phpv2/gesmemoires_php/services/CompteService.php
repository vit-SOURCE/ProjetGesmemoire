<?php
require_once __DIR__ . '/../models/Etudiant.php';
require_once __DIR__ . '/../models/Professeur.php';
require_once __DIR__ . '/../models/Memoire.php';

class CompteService {

    // Tous les comptes en attente (étudiants + professeurs)
    public static function getComptesEnAttente(): array {
        $etudiants  = (new Etudiant())->findEnAttente();
        $professeurs = (new Professeur())->findEnAttente();

        foreach ($etudiants  as &$e) $e['type_compte'] = 'etudiant';
        foreach ($professeurs as &$p) $p['type_compte'] = 'professeur';

        return array_merge($etudiants, $professeurs);
    }

    // Valider un compte étudiant
    public static function validerEtudiant(string $matricule): array {
        $ok = (new Etudiant())->updateStatut($matricule, 'actif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte étudiant validé.']
            : ['ok' => false, 'message' => 'Erreur lors de la validation.'];
    }

    // Valider un compte professeur
    public static function validerProfesseur(string $matricule): array {
        $ok = (new Professeur())->updateStatut($matricule, 'actif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte professeur validé.']
            : ['ok' => false, 'message' => 'Erreur lors de la validation.'];
    }

    // Rejeter un compte étudiant
    public static function rejeterEtudiant(string $matricule): array {
        $ok = (new Etudiant())->updateStatut($matricule, 'inactif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte étudiant rejeté.']
            : ['ok' => false, 'message' => 'Erreur lors du rejet.'];
    }

    // Rejeter un compte professeur
    public static function rejeterProfesseur(string $matricule): array {
        $ok = (new Professeur())->updateStatut($matricule, 'inactif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte professeur rejeté.']
            : ['ok' => false, 'message' => 'Erreur lors du rejet.'];
    }

    // Valider tous les comptes en attente d'un coup
    public static function validerTous(): array {
        $comptes = self::getComptesEnAttente();
        $count = 0;
        foreach ($comptes as $compte) {
            if ($compte['type_compte'] === 'etudiant') {
                $mat = $compte['Etu_matricule'] ?? ''; if ($mat) (new Etudiant())->updateStatut($mat, 'actif');
            } else {
                (new Professeur())->updateStatut($compte['Prof_matricule'] ?? '', 'actif');
            }
            $count++;
        }
        return ['ok' => true, 'message' => "$count compte(s) validé(s).", 'count' => $count];
    }

    // Assigner un prof directement à un étudiant (avant soumission)
    public static function assignerProfesseur(string $etu_matricule, string $prof_matricule): array {
        $ok = (new Etudiant())->updateProf($etu_matricule, $prof_matricule);
        return $ok
            ? ['ok' => true,  'message' => 'Professeur assigné avec succès.']
            : ['ok' => false, 'message' => 'Erreur lors de l\'assignation.'];
    }

    // Désactiver un compte étudiant
    public static function desactiverEtudiant(string $matricule): array {
        $ok = (new Etudiant())->updateStatut($matricule, 'inactif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte désactivé.']
            : ['ok' => false, 'message' => 'Erreur.'];
    }

    // Réactiver un compte étudiant
    public static function activerEtudiant(string $matricule): array {
        $ok = (new Etudiant())->updateStatut($matricule, 'actif');
        return $ok
            ? ['ok' => true,  'message' => 'Compte activé.']
            : ['ok' => false, 'message' => 'Erreur.'];
    }
}
