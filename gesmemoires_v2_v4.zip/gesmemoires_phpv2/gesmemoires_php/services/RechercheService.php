<?php
require_once __DIR__ . '/../models/Memoire.php';

class RechercheService {

    public static function rechercher(string $q): array {
        $q = trim($q);
        if (strlen($q) < 2) return [];
        return (new Memoire())->search($q);
    }

    // Catalogue complet (validé + archive)
    public static function getCatalogue(?string $q = null): array {
        if ($q && strlen(trim($q)) >= 2) return self::rechercher($q);
        return (new Memoire())->findValides();
    }
}
