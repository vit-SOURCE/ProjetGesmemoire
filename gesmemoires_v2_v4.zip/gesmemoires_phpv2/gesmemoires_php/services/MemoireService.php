<?php
require_once __DIR__ . '/../models/Memoire.php';
require_once __DIR__ . '/../models/Professeur.php';

class MemoireService {

    private static function getUploadDir(): string {
        $dir = __DIR__ . '/../uploads/memoires';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        return $dir;
    }

    private static function validerFichier(array $fichier): ?string {
        if ($fichier['error'] !== UPLOAD_ERR_OK)
            return 'Erreur lors de l\'upload (code ' . $fichier['error'] . ').';
        $ext  = strtolower(pathinfo($fichier['name'], PATHINFO_EXTENSION));
        $type = $fichier['type'] ?? '';
        $pdf_types = ['application/pdf','application/x-pdf','application/octet-stream','binary/octet-stream'];
        if (!in_array($type, $pdf_types) && $ext !== 'pdf')
            return 'Le fichier doit être un PDF.';
        if ($fichier['size'] > 50 * 1024 * 1024)
            return 'Fichier trop volumineux (max 50 Mo).';
        return null;
    }

    public static function soumettre(array $data, array $fichier): array {
        $erreur = self::validerFichier($fichier);
        if ($erreur) return ['ok' => false, 'message' => $erreur];

        $dir         = self::getUploadDir();
        $nom_fichier = uniqid('memoire_') . '.pdf';
        $chemin      = $dir . '/' . $nom_fichier;

        if (!move_uploaded_file($fichier['tmp_name'], $chemin))
            return ['ok' => false, 'message' => 'Impossible de sauvegarder le fichier. Verifiez les permissions du dossier uploads/memoires/.'];

        $db   = getDB();
        $stmt = $db->prepare(
            "INSERT INTO memoire (titre, annee, fichier, statut, date_envoi, Etu_matricule, Prof_matricule, DE_matricule)
             VALUES (?, ?, ?, 'en_attente', NOW(), ?, ?, ?)"
        );
        $stmt->execute([
            $data['titre'],
            (int)$data['annee'],
            $nom_fichier,
            $data['etu_matricule'],
            $data['prof_matricule'] ?? null,
            $data['de_matricule']   ?? null,
        ]);
        return ['ok' => true, 'id_memoire' => (int)$db->lastInsertId(), 'fichier' => $nom_fichier];
    }

    public static function uploadArchive(array $data, array $fichier): array {
        $erreur = self::validerFichier($fichier);
        if ($erreur) return ['ok' => false, 'message' => $erreur];

        $dir         = self::getUploadDir();
        $nom_fichier = uniqid('archive_') . '.pdf';
        $chemin      = $dir . '/' . $nom_fichier;

        if (!move_uploaded_file($fichier['tmp_name'], $chemin))
            return ['ok' => false, 'message' => 'Impossible de sauvegarder le fichier.'];

        $db   = getDB();
        $stmt = $db->prepare(
            "INSERT INTO memoire (titre, annee, fichier, statut, date_publication, DE_matricule)
             VALUES (?, ?, ?, 'archive', NOW(), ?)"
        );
        $stmt->execute([$data['titre'], (int)$data['annee'], $nom_fichier, $data['de_matricule']]);
        return ['ok' => true, 'id_memoire' => (int)$db->lastInsertId()];
    }

    public static function annoter(int $id, string $statut, string $commentaire): array {
        $ok = (new Memoire())->updateStatut($id, $statut, $commentaire);
        return $ok
            ? ['ok' => true,  'message' => 'Memoire mis a jour.']
            : ['ok' => false, 'message' => 'Erreur lors de la mise a jour.'];
    }

    public static function valider(int $id, string $commentaire = ''): array {
        return self::annoter($id, 'valide', $commentaire);
    }

    public static function rejeter(int $id, string $commentaire): array {
        if (empty(trim($commentaire)))
            return ['ok' => false, 'message' => 'Un commentaire est requis pour rejeter un memoire.'];
        return self::annoter($id, 'rejete', $commentaire);
    }

    public static function mettreEnCorrection(int $id, string $commentaire): array {
        if (empty(trim($commentaire)))
            return ['ok' => false, 'message' => 'Un commentaire est requis.'];
        return self::annoter($id, 'en_correction', $commentaire);
    }

    // Publier (DE) - verifie le statut avant de publier
    public static function publier(int $id): array {
        $memoire = (new Memoire())->findById($id);
        if (!$memoire)
            return ['ok' => false, 'message' => 'Memoire introuvable.'];
        if ($memoire['statut'] !== 'valide')
            return ['ok' => false, 'message' => 'Ce memoire n\'est pas encore valide par le professeur (statut : ' . $memoire['statut'] . ').'];
        $ok = (new Memoire())->publier($id);
        return $ok
            ? ['ok' => true,  'message' => 'Memoire publie avec succes.']
            : ['ok' => false, 'message' => 'Erreur lors de la publication.'];
    }

    public static function getMemoiresEtudiant(string $etu_matricule): array {
        return (new Memoire())->findByEtudiant($etu_matricule);
    }

    public static function getMemoiresProfesseur(string $prof_matricule): array {
        return (new Memoire())->findByProfesseur($prof_matricule);
    }

    public static function getCatalogue(): array {
        return (new Memoire())->findValides();
    }

    public static function getTous(): array {
        return (new Memoire())->findAll();
    }

    public static function getArchives(): array {
        return (new Memoire())->findArchives();
    }

    public static function getDetail(int $id): array|false {
        return (new Memoire())->findById($id);
    }

    public static function getStats(): array {
        return (new Memoire())->getStats();
    }
}
