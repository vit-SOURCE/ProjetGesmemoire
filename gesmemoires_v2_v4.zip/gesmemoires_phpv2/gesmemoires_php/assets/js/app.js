// ── Tabs ──
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.tabs-wrapper') || btn.parentElement.parentElement;
      group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      group.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      const target = document.getElementById(btn.dataset.tab);
      if (target) target.classList.add('active');
    });
  });
}

// ── Modals ──
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('open');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('open');
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
});

// ── Alert custom ──
function showAlert(message, type = 'info') {
  const types = { success: '#1a6b3a', error: '#ba1a1a', warning: '#b45309', info: '#1d4ed8' };
  const icons = {
    success: '<path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>',
    error:   '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    warning: '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
    info:    '<path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>',
  };
  const titles = { success: 'Succès', error: 'Erreur', warning: 'Attention', info: 'Information' };
  const color = types[type] || types.info;

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay open';
  overlay.innerHTML = `
    <div class="modal-box" style="max-width:400px">
      <div style="background:${color};padding:16px 20px;display:flex;align-items:center;gap:10px;color:#fff">
        <svg xmlns="http://www.w3.org/2000/svg" style="width:20px;height:20px;flex-shrink:0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">${icons[type]}</svg>
        <span style="font-weight:700;font-size:13px;text-transform:uppercase;letter-spacing:.05em">${titles[type]}</span>
      </div>
      <div style="padding:20px;font-size:14px;color:#1a1c1c;text-align:center;font-weight:500">${message}</div>
      <div style="padding:12px 20px;background:#f3f3f4;border-top:1px solid #c5c6cf;display:flex;justify-content:center">
        <button onclick="this.closest('.modal-overlay').remove()" class="btn btn-primary btn-sm" style="min-width:120px">Compris</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

// ── Confirm dialog ──
function showConfirm(message, onConfirm) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay open';
  overlay.innerHTML = `
    <div class="modal-box" style="max-width:400px">
      <div class="modal-header">Confirmation</div>
      <div class="modal-body" style="font-size:14px">${message}</div>
      <div class="modal-footer">
        <button onclick="this.closest('.modal-overlay').remove()" class="btn btn-secondary btn-sm">Annuler</button>
        <button id="confirm-yes" class="btn btn-danger btn-sm">Confirmer</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector('#confirm-yes').addEventListener('click', () => {
    overlay.remove();
    onConfirm();
  });
}

// ── Flash message auto-hide ──
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  document.querySelectorAll('.alert[data-auto-hide]').forEach(el => {
    setTimeout(() => el.style.display = 'none', 4000);
  });
});

// ── File upload preview ──
function initFileUpload(inputId, labelId) {
  const input = document.getElementById(inputId);
  const label = document.getElementById(labelId);
  if (!input || !label) return;
  input.addEventListener('change', () => {
    const file = input.files[0];
    if (file) label.textContent = file.name;
  });
}
