<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>GesMemoires — Plateforme de gestion des mémoires académiques</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/css/style.css"/>
  <style>
    .landing-nav{position:fixed;top:0;left:0;width:100%;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:0 40px;height:64px;background:rgba(3,22,53,.95);backdrop-filter:blur(8px)}
    .landing-nav-brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px;color:#fff}
    .hero-landing{min-height:100vh;background:var(--primary);display:flex;align-items:center;padding-top:64px;position:relative;overflow:hidden}
    .hero-landing::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 50%,rgba(216,227,250,.07) 0%,transparent 60%)}
    .hero-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(216,227,250,.12);border:1px solid rgba(216,227,250,.2);color:var(--tertiary-fixed);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:6px 14px;border-radius:20px;margin-bottom:24px}
    .hero-title{font-size:clamp(32px,5vw,60px);font-weight:800;color:#fff;line-height:1.1;margin-bottom:20px}
    .hero-title span{color:var(--tertiary-fixed)}
    .stats-bar{display:flex;gap:40px;margin-top:48px;padding-top:32px;border-top:1px solid rgba(255,255,255,.1)}
    .stat-item-num{font-size:28px;font-weight:800;color:#fff}
    .stat-item-label{font-size:11px;color:rgba(255,255,255,.5);font-weight:600;text-transform:uppercase;letter-spacing:.08em;margin-top:2px}
    .features{padding:80px 0;background:#fff}
    .features-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-top:48px}
    .feature-card{background:var(--surface);border-radius:16px;padding:28px;border:1px solid var(--outline-variant);transition:.2s}
    .feature-card:hover{border-color:var(--primary);box-shadow:0 4px 20px rgba(3,22,53,.08)}
    .feature-icon{width:48px;height:48px;background:var(--primary);border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:16px}
    .feature-icon svg{width:24px;height:24px;color:#fff}
    .actors-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;margin-top:48px}
    .actor-card{background:#fff;border-radius:14px;padding:24px;border:1px solid var(--outline-variant);text-align:center}
    .actor-avatar{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:22px}
    .section-label{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--primary);margin-bottom:12px}
    .section-title{font-size:clamp(24px,3vw,36px);font-weight:800;color:var(--primary);margin-bottom:12px}
    .cta-section{background:var(--primary);padding:80px 0;text-align:center}
    .landing-footer{background:#0a0e1a;color:rgba(255,255,255,.5);padding:32px 40px;display:flex;justify-content:space-between;align-items:center;font-size:12px}
  </style>
</head>
<body>

<nav class="landing-nav">
  <div class="landing-nav-brand">
    <svg xmlns="http://www.w3.org/2000/svg" style="width:26px;height:26px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 14l9-5-9-5-9 5 9 5z"/><path d="M12 14l6.16-3.422A12 12 0 0112 21.364 12 12 0 015.84 10.578L12 14z"/></svg>
    GesMemoires
  </div>
  <div style="display:flex;align-items:center;gap:12px">
    <a href="views/connexion.php" class="btn btn-secondary btn-sm" style="border-color:rgba(255,255,255,.3);color:#fff">Se connecter</a>
    <a href="views/inscription.php" class="btn btn-primary btn-sm" style="background:var(--tertiary-fixed);color:var(--primary)">S'inscrire</a>
  </div>
</nav>

<section class="hero-landing">
  <div class="container" style="position:relative;z-index:2">
    <div class="hero-badge">UATM GASA — Plateforme académique</div>
    <h1 class="hero-title">La plateforme de gestion<br/>des <span>mémoires académiques</span></h1>
    <p style="font-size:16px;color:rgba(255,255,255,.7);max-width:520px;margin-bottom:32px;line-height:1.7">Soumettez, suivez et validez vos mémoires en toute simplicité. Une solution complète pour étudiants, professeurs et le Directeur des Études.</p>
    <div class="flex gap-3">
      <a href="views/inscription.php" class="btn" style="background:var(--tertiary-fixed);color:var(--primary);padding:14px 28px;font-size:14px">Créer un compte →</a>
      <a href="views/connexion.php" class="btn btn-secondary" style="border-color:rgba(255,255,255,.3);color:#fff;padding:14px 28px;font-size:14px">Se connecter</a>
    </div>
    <div class="stats-bar">
      <div><div class="stat-item-num">200+</div><div class="stat-item-label">Mémoires</div></div>
      <div><div class="stat-item-num">150+</div><div class="stat-item-label">Étudiants</div></div>
      <div><div class="stat-item-num">20+</div><div class="stat-item-label">Professeurs</div></div>
      <div><div class="stat-item-num">10+</div><div class="stat-item-label">Domaines</div></div>
    </div>
  </div>
</section>

<section class="features" style="padding:80px 0">
  <div class="container" style="text-align:center">
    <div class="section-label">Fonctionnalités</div>
    <h2 class="section-title">Tout ce dont vous avez besoin</h2>
    <div class="features-grid">
      <div class="feature-card">
        <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></div>
        <div style="font-size:15px;font-weight:700;color:var(--primary);margin-bottom:8px">Soumission en ligne</div>
        <div class="text-sm text-muted">Les étudiants diplômés soumettent leur mémoire PDF directement depuis leur espace personnel.</div>
      </div>
      <div class="feature-card">
        <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></div>
        <div style="font-size:15px;font-weight:700;color:var(--primary);margin-bottom:8px">Annotation & Validation</div>
        <div class="text-sm text-muted">Les professeurs annotent, renvoient en correction ou valident les mémoires sur la plateforme.</div>
      </div>
      <div class="feature-card">
        <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
        <div style="font-size:15px;font-weight:700;color:var(--primary);margin-bottom:8px">Catalogue & Recherche</div>
        <div class="text-sm text-muted">Consultez et recherchez parmi tous les mémoires validés, filtrables par domaine.</div>
      </div>
      <div class="feature-card">
        <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
        <div style="font-size:15px;font-weight:700;color:var(--primary);margin-bottom:8px">Gestion des comptes</div>
        <div class="text-sm text-muted">Le Directeur des Études valide les inscriptions et gère les accès de tous les utilisateurs.</div>
      </div>
    </div>
  </div>
</section>

<section style="padding:80px 0;background:var(--surface)">
  <div class="container" style="text-align:center">
    <div class="section-label">Acteurs</div>
    <h2 class="section-title">Une plateforme pour chacun</h2>
    <div class="actors-grid">
      <div class="actor-card"><div class="actor-avatar" style="background:#e0e7ff">🎓</div><div style="font-weight:700;color:var(--primary);margin-bottom:6px">Étudiant Diplômé</div><div class="text-sm text-muted">Soumet, suit et resoumet son mémoire après corrections.</div></div>
      <div class="actor-card"><div class="actor-avatar" style="background:#f0fdf4">📚</div><div style="font-weight:700;color:var(--primary);margin-bottom:6px">Étudiant Non Diplômé</div><div class="text-sm text-muted">Consulte les mémoires validés dans le catalogue.</div></div>
      <div class="actor-card"><div class="actor-avatar" style="background:#fef3c7">👨‍🏫</div><div style="font-weight:700;color:var(--primary);margin-bottom:6px">Professeur</div><div class="text-sm text-muted">Annote, valide ou rejette les mémoires de ses étudiants.</div></div>
      <div class="actor-card"><div class="actor-avatar" style="background:#fce7f3">🏛️</div><div style="font-weight:700;color:var(--primary);margin-bottom:6px">Directeur des Études</div><div class="text-sm text-muted">Valide les inscriptions, assigne les professeurs, publie les mémoires.</div></div>
    </div>
  </div>
</section>

<section class="cta-section">
  <div class="container">
    <h2 style="font-size:clamp(24px,3vw,40px);font-weight:800;color:#fff;margin-bottom:12px">Prêt à commencer ?</h2>
    <p style="color:rgba(255,255,255,.7);font-size:15px;margin-bottom:32px">Créez votre compte en quelques minutes.</p>
    <div class="flex gap-3" style="justify-content:center">
      <a href="views/inscription.php" class="btn" style="background:var(--tertiary-fixed);color:var(--primary);padding:14px 32px;font-size:14px;font-weight:700">S'inscrire maintenant</a>
      <a href="views/connexion.php" class="btn btn-secondary" style="border-color:rgba(255,255,255,.3);color:#fff;padding:14px 32px;font-size:14px">Se connecter</a>
    </div>
  </div>
</section>

<footer class="landing-footer">
  <div>© 2026 GesMemoires — UATM GASA. Tous droits réservés.</div>
  <div>Plateforme de gestion des mémoires académiques</div>
</footer>

<script src="assets/js/app.js"></script>
</body>
</html>
