import { User, Thesis, PendingRegistration, ActivityLog, UserRole, HistoryEntry } from '../types';
import { INITIAL_USERS, INITIAL_THESES, INITIAL_PENDING_REGISTRATIONS, INITIAL_LOGS } from '../data';

/**
 * SERVICE D'API FRONTEND (Prêt pour connexion avec votre Base de Données)
 * 
 * Ce fichier centralise tous les appels de données de l'application.
 * Pour connecter votre propre base de données (PostgreSQL, MySQL, MongoDB, Firebase, etc.) :
 * 1. Remplacez le code de ces fonctions par des requêtes réelles (ex: fetch('/api/theses') ou axios.get('/api/theses')).
 * 2. Toutes les fonctions retournent déjà des Promesses (Promise), ce qui signifie que votre code
 *    React (App.tsx) n'aura pas besoin d'être modifié ! Il gère déjà l'asynchronisme.
 */

// Utilitaire pour simuler un délai réseau (ex: 300ms) - à retirer lors de la connexion au vrai backend
const delay = (ms: number = 200) => new Promise(resolve => setTimeout(resolve, ms));

// Helper local storage pour conserver la simulation d'état
const getStoredState = () => {
  const usersStr = localStorage.getItem('gm_users');
  const thesesStr = localStorage.getItem('gm_theses');
  const registrationsStr = localStorage.getItem('gm_registrations');
  const logsStr = localStorage.getItem('gm_logs');

  let users = usersStr ? JSON.parse(usersStr) : INITIAL_USERS;
  let theses = thesesStr ? JSON.parse(thesesStr) : INITIAL_THESES;
  let registrations = registrationsStr ? JSON.parse(registrationsStr) : INITIAL_PENDING_REGISTRATIONS;
  let logs = logsStr ? JSON.parse(logsStr) : INITIAL_LOGS;

  let changed = false;

  // Assurer la conversion des noms français "Pierre Dupont" et "Lucie Laurent"
  // en noms africains pour les inscriptions en attente actuelles et futures
  if (Array.isArray(registrations)) {
    registrations = registrations.map(reg => {
      let fName = reg.firstName || '';
      let lName = reg.lastName || '';
      let emailStr = reg.email || '';

      if (
        (fName.toLowerCase() === 'pierre' && lName.toLowerCase() === 'dupont') ||
        emailStr.toLowerCase().includes('dupont') ||
        emailStr.toLowerCase().includes('p.dupont')
      ) {
        fName = 'Rodrigue';
        lName = 'Dansou';
        emailStr = 'rodrigue.dansou@uac.bj';
        changed = true;
      }
      if (
        (fName.toLowerCase() === 'lucie' && lName.toLowerCase() === 'laurent') ||
        emailStr.toLowerCase().includes('laurent') ||
        emailStr.toLowerCase().includes('l.laurent')
      ) {
        fName = 'Fatoumata';
        lName = 'Alabi';
        emailStr = 'fatoumata.alabi@uac.bj';
        changed = true;
      }
      return { ...reg, firstName: fName, lastName: lName, email: emailStr };
    });
  }

  // Assurer la conversion dans l'historique d'activités
  if (Array.isArray(logs)) {
    logs = logs.map(l => {
      let text = l.text || '';
      const originalText = text;
      
      text = text.replace(/Pierre\s+Dupont/gi, 'Rodrigue Dansou');
      text = text.replace(/Lucie\s+Laurent/gi, 'Fatoumata Alabi');
      text = text.replace(/p\.dupont@univ\.fr/gi, 'rodrigue.dansou@uac.bj');
      text = text.replace(/l\.laurent@univ\.fr/gi, 'fatoumata.alabi@uac.bj');

      if (text !== originalText) {
        changed = true;
      }
      return { ...l, text };
    });
  }

  if (changed) {
    localStorage.setItem('gm_registrations', JSON.stringify(registrations));
    localStorage.setItem('gm_logs', JSON.stringify(logs));
  }

  return {
    users,
    theses,
    registrations,
    logs,
  };
};

const saveStoredState = (state: {
  users: User[];
  theses: Thesis[];
  registrations: PendingRegistration[];
  logs: ActivityLog[];
}) => {
  localStorage.setItem('gm_users', JSON.stringify(state.users));
  localStorage.setItem('gm_theses', JSON.stringify(state.theses));
  localStorage.setItem('gm_registrations', JSON.stringify(state.registrations));
  localStorage.setItem('gm_logs', JSON.stringify(state.logs));
};

export const AppApiService = {
  /**
   * Charger l'ensemble des données d'initialisation
   */
  async getInitialState(): Promise<{
    users: User[];
    theses: Thesis[];
    registrations: PendingRegistration[];
    logs: ActivityLog[];
  }> {
    await delay(300); // Simulation latence réseau
    return getStoredState();
  },

  /**
   * Gère la connexion utilisateur
   * À remplacer par : return axios.post('/api/auth/login', { email, password })
   */
  async login(email: string): Promise<User> {
    await delay(250);
    const state = getStoredState();
    const user = state.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      throw new Error("Identifiants incorrects ou utilisateur non trouvé.");
    }
    return user;
  },

  /**
   * Créer ou s'inscrire pour un nouveau compte
   * À remplacer par : return axios.post('/api/auth/register', { firstName, lastName, email, role })
   */
  async registerUser(params: {
    firstName: string;
    lastName: string;
    email: string;
    role: UserRole;
  }): Promise<{ user: User; pendingRegistration?: PendingRegistration; log?: ActivityLog }> {
    await delay(400);
    const state = getStoredState();
    
    const newUser: User = {
      id: `user-${Date.now()}`,
      firstName: params.firstName,
      lastName: params.lastName,
      email: params.email,
      role: params.role,
      details: {
        studentId: params.role.startsWith('student') ? '2026-BJ' + Math.floor(Math.random() * 900 + 100) : undefined,
        faculty: params.role.startsWith('student') ? 'Sciences Appliquées' : undefined,
        cycle: params.role.startsWith('student') ? 'Master II - Recherche' : undefined,
        status: 'Actif',
        avatarUrl: ''
      }
    };

    const updatedUsers = [...state.users, newUser];
    let pendingRegistration: PendingRegistration | undefined = undefined;
    let log: ActivityLog | undefined = undefined;

    if (params.role === 'teacher' || params.role === 'dean') {
      pendingRegistration = {
        id: `reg-${Date.now()}`,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        email: newUser.email,
        role: params.role,
        date: "À l'instant"
      };

      log = {
        id: `log-${Date.now()}`,
        text: `Nouvelle demande d'inscription reçue de ${newUser.firstName} ${newUser.lastName}.`,
        date: "Il y a une minute",
        type: 'info'
      };

      saveStoredState({
        ...state,
        users: updatedUsers,
        registrations: [pendingRegistration, ...state.registrations],
        logs: [log, ...state.logs]
      });
    } else {
      saveStoredState({
        ...state,
        users: updatedUsers
      });
    }

    return { user: newUser, pendingRegistration, log };
  },

  /**
   * Soumettre un nouveau mémoire (Étudiant)
   * À remplacer par : return axios.post('/api/theses', { title, domain, year, file })
   */
  async submitThesis(params: {
    title: string;
    domain: string;
    year: number;
    fileName: string;
    student: User;
  }): Promise<{ thesis: Thesis; log: ActivityLog }> {
    await delay(400);
    const state = getStoredState();

    const newThesis: Thesis = {
      id: `thesis-${Date.now()}`,
      title: params.title,
      domain: params.domain,
      year: params.year,
      studentId: params.student.details?.studentId || '2024-KH882',
      studentName: `${params.student.firstName} ${params.student.lastName}`,
      studentEmail: params.student.email,
      studentAvatar: params.student.details?.avatarUrl || '',
      status: 'pending',
      submissionNotes: "Version initiale soumise.",
      comments: [],
      history: [
        {
          id: `h-${Date.now()}`,
          version: 'Version 1.0',
          date: "Aujourd'hui",
          status: 'pending',
          title: params.title,
          submittedBy: `${params.student.firstName} ${params.student.lastName}`,
          notes: "Soumission initiale"
        }
      ]
    };

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      text: `${params.student.firstName} ${params.student.lastName} a soumis son mémoire de fin d'étude.`,
      date: "À l'instant",
      type: 'success'
    };

    const updatedTheses = [newThesis, ...state.theses];
    const updatedLogs = [newLog, ...state.logs];

    saveStoredState({
      ...state,
      theses: updatedTheses,
      logs: updatedLogs
    });

    return { thesis: newThesis, log: newLog };
  },

  /**
   * Resoumettre une version corrigée d'un mémoire (Étudiant)
   * À remplacer par : return axios.post(`/api/theses/${thesisId}/resubmit`, { notes, file })
   */
  async resubmitThesis(params: {
    thesisId: string;
    notes: string;
    fileName: string;
    student: User;
  }): Promise<{ updatedThesis: Thesis; log: ActivityLog }> {
    await delay(350);
    const state = getStoredState();
    const thesis = state.theses.find(t => t.id === params.thesisId);

    if (!thesis) {
      throw new Error("Mémoire non trouvé");
    }

    const nextVersionCount = (thesis.history.length + 1).toFixed(1);
    const updatedHistory: HistoryEntry = {
      id: `h-new-${Date.now()}`,
      version: `Version ${nextVersionCount}`,
      date: "Aujourd'hui",
      status: 'pending',
      title: thesis.title,
      submittedBy: `${params.student.firstName} ${params.student.lastName}`,
      notes: params.notes || "Corrections apportées"
    };

    const updatedThesis: Thesis = {
      ...thesis,
      status: 'pending',
      submissionNotes: params.notes,
      history: [updatedHistory, ...thesis.history]
    };

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      text: `${params.student.firstName} ${params.student.lastName} a resoumis son mémoire "${thesis.title}".`,
      date: "À l'instant",
      type: 'info'
    };

    const updatedTheses = state.theses.map(t => t.id === params.thesisId ? updatedThesis : t);
    const updatedLogs = [newLog, ...state.logs];

    saveStoredState({
      ...state,
      theses: updatedTheses,
      logs: updatedLogs
    });

    return { updatedThesis, log: newLog };
  },

  /**
   * Valider une demande d'inscription d'un enseignant (Directeur)
   * À remplacer par : return axios.post(`/api/admin/registrations/${regId}/approve`)
   */
  async approveRegistration(regId: string, regInfo: { firstName: string, lastName: string }): Promise<ActivityLog> {
    await delay(200);
    const state = getStoredState();

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      text: `Directeur a validé l'inscription de l'utilisateur ${regInfo.firstName} ${regInfo.lastName}.`,
      date: "À l'instant",
      type: 'success'
    };

    saveStoredState({
      ...state,
      registrations: state.registrations.filter(r => r.id !== regId),
      logs: [newLog, ...state.logs]
    });

    return newLog;
  },

  /**
   * Refuser une demande d'inscription d'un enseignant (Directeur)
   * À remplacer par : return axios.post(`/api/admin/registrations/${regId}/reject`)
   */
  async rejectRegistration(regId: string, regInfo: { firstName: string, lastName: string }): Promise<ActivityLog> {
    await delay(200);
    const state = getStoredState();

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      text: `Directeur a refusé l'inscription de l'utilisateur ${regInfo.firstName} ${regInfo.lastName}.`,
      date: "À l'instant",
      type: 'warning'
    };

    saveStoredState({
      ...state,
      registrations: state.registrations.filter(r => r.id !== regId),
      logs: [newLog, ...state.logs]
    });

    return newLog;
  },

  /**
   * Assigner un enseignant encadrant à un étudiant (Directeur)
   * À remplacer par : return axios.post(`/api/admin/assign`, { studentName, teacherName })
   */
  async assignSupervisor(studentName: string, teacherName: string): Promise<ActivityLog> {
    await delay(200);
    const state = getStoredState();

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      text: `Admin a assigné l'étudiant <strong>${studentName}</strong> au tuteur <strong>${teacherName}</strong>.`,
      date: "À l'instant",
      type: 'success'
    };

    saveStoredState({
      ...state,
      logs: [newLog, ...state.logs]
    });

    return newLog;
  },

  /**
   * Enregistrer une évaluation, note ou avis sur un mémoire (Enseignant/Directeur)
   * À remplacer par : return axios.patch(`/api/theses/${id}`, updatedParams)
   */
  async updateThesis(id: string, updatedParams: Partial<Thesis>): Promise<Thesis> {
    await delay(300);
    const state = getStoredState();
    let updatedThesis: Thesis | null = null;

    const updatedTheses = state.theses.map(t => {
      if (t.id === id) {
        updatedThesis = { ...t, ...updatedParams } as Thesis;
        return updatedThesis;
      }
      return t;
    });

    if (!updatedThesis) {
      throw new Error("Mémoire introuvable");
    }

    saveStoredState({
      ...state,
      theses: updatedTheses
    });

    return updatedThesis;
  }
};
