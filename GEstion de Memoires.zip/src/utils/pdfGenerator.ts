import { jsPDF } from 'jspdf';
import { Thesis } from '../types';

export const generateDeanReportPDF = (
  theses: Thesis[],
  stats: {
    totalUsers: number;
    validatedCount: number;
    inEvaluationCount: number;
    pendingAccountsCount: number;
  }
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // Colors
  const primaryColor = [15, 23, 42]; // Slate 900
  const secondaryColor = [71, 85, 105]; // Slate 600
  const borderLight = [226, 232, 240]; // Slate 200

  // Title / Header Banner
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, 210, 40, 'F');
  
  // Custom styled header text
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('UNIVERSITE D\'ABOMEY-CALAVI', 15, 20);
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(200, 200, 200);
  doc.text('TABLEAU DE BORD DIRECTION DES ETUDES - GESMEMOIRES', 15, 28);
  doc.text(`Edite le: ${new Date().toLocaleDateString('fr-BJ', { day: '2-digit', month: 'long', year: 'numeric' })}`, 150, 28);

  // Statistics Section Title
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('I. STATISTIQUES GLOBALES', 15, 55);

  // Stats Grid boxes
  const boxWidth = 42;
  const boxHeight = 22;
  const startX = 15;
  const startY = 62;
  const gap = 6;

  const statBoxes = [
    { label: 'Utilisateurs', val: stats.totalUsers },
    { label: 'Memoires Valides', val: stats.validatedCount },
    { label: 'En evaluation', val: stats.inEvaluationCount },
    { label: 'Comptes a valider', val: stats.pendingAccountsCount }
  ];

  statBoxes.forEach((box, i) => {
    const x = startX + i * (boxWidth + gap);
    // Draw Box Bg
    doc.setFillColor(241, 245, 249); // light bg gray
    doc.roundedRect(x, startY, boxWidth, boxHeight, 2, 2, 'F');
    // Draw Border
    doc.setDrawColor(borderLight[0], borderLight[1], borderLight[2]);
    doc.roundedRect(x, startY, boxWidth, boxHeight, 2, 2, 'S');
    
    // Label
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text(box.label, x + 3, startY + 7);
    
    // Value
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(String(box.val), x + 3, startY + 17);
  });

  // Theses List Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('II. LISTE DES MEMOIRES ET DOSSIERS', 15, 96);

  // Table Headers
  const tableY = 104;
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(15, tableY, 180, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text('ETUDIANT', 18, tableY + 5.5);
  doc.text('THEMATIQUE / MEMOIRE', 55, tableY + 5.5);
  doc.text('MAITRE / ENCADRANT', 135, tableY + 5.5);
  doc.text('STATUT', 178, tableY + 5.5);

  let currentY = tableY + 8;
  const itemHeight = 15;

  theses.forEach((thesis, index) => {
    // Page overflow safety
    if (currentY + itemHeight > 280) {
      doc.addPage();
      currentY = 20;

      // Table Header on new page
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(15, currentY, 180, 8, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(255, 255, 255);
      doc.text('ETUDIANT', 18, currentY + 5.5);
      doc.text('THEMATIQUE / MEMOIRE', 55, currentY + 5.5);
      doc.text('MAITRE / ENCADRANT', 135, currentY + 5.5);
      doc.text('STATUT', 178, currentY + 5.5);
      
      currentY += 8;
    }

    // Row Background (Zebra striping)
    if (index % 2 === 1) {
      doc.setFillColor(250, 250, 250);
      doc.rect(15, currentY, 180, itemHeight, 'F');
    }

    // Row borders
    doc.setDrawColor(borderLight[0], borderLight[1], borderLight[2]);
    doc.line(15, currentY + itemHeight, 195, currentY + itemHeight);

    // Student Column
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    // Truncate student name if too long
    const shortStudentName = thesis.studentName.length > 20 ? thesis.studentName.substring(0, 18) + '...' : thesis.studentName;
    doc.text(shortStudentName, 18, currentY + 6);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text(thesis.studentId, 18, currentY + 11);

    // Title / Domain Column
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    
    // Text wrapping for thesis title
    const shortTitle = thesis.title.length > 55 ? thesis.title.substring(0, 52) + '...' : thesis.title;
    doc.text(shortTitle, 55, currentY + 6);
    
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text(`Domaine: ${thesis.domain} (${thesis.year})`, 55, currentY + 11);

    // Supervisor Column
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    const supervisor = thesis.assignedTeacherName || "Non assigne";
    doc.text(supervisor, 135, currentY + 8);

    // Status Column
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    let statusText = 'En attente';
    if (thesis.status === 'accepted') {
      doc.setTextColor(16, 124, 65); // Green
      statusText = 'VALIDE';
    } else if (thesis.status === 'rejected') {
      doc.setTextColor(180, 83, 9); // Amber/Red
      statusText = 'REJETE';
    } else {
      doc.setTextColor(37, 99, 235); // Blue
      statusText = 'EXAMEN';
    }
    doc.text(statusText, 178, currentY + 8);

    currentY += itemHeight;
  });

  // Footer Signatures
  if (currentY + 30 > 280) {
    doc.addPage();
    currentY = 20;
  }

  currentY += 15;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Le Directeur des Etudes (Signature)', 130, currentY);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text('Valide et certifie conforme aux registres.', 130, currentY + 5);

  // Footer page number at the end
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(110, 110, 110);
    doc.text(`Page ${i} sur ${pageCount}`, 180, 287);
    doc.text('GesMemoires - Plateforme Universitaire de Gestion des Memoires', 15, 287);
  }

  // Save the PDF
  doc.save(`Rapport_GesMemoires_${new Date().toISOString().split('T')[0]}.pdf`);
};
