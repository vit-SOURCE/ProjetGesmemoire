import { Thesis, PendingRegistration, ActivityLog, User } from './types';

// Initial users we can login with
export const INITIAL_USERS: User[] = [
  {
    id: 'user-dean',
    firstName: 'Romuald',
    lastName: 'Agbodjan',
    email: 'admin@uac.bj',
    role: 'dean',
    details: {
      titleOffice: 'Dir. des Études',
      avatarUrl: ''
    }
  },
  {
    id: 'user-teacher',
    firstName: 'Arnaud',
    lastName: 'Houessou',
    email: 'arnaud.houessou@uac.bj',
    role: 'teacher',
    details: {
      titleOffice: 'Maître de Conférences',
      avatarUrl: ''
    }
  },
  {
    id: 'user-student',
    firstName: 'Koffi',
    lastName: 'Zannou',
    email: 'koffi.zannou@uac.bj',
    role: 'student-grad', // Graduate student
    details: {
      studentId: '2024-KH882',
      faculty: 'Sciences Appliquées',
      cycle: 'Master II - Recherche',
      status: 'Actif',
      avatarUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC8DwdnL0ci7gXTIt9vf2FPmJRwh_urJmxkkIKomPruVsR-VE7hlsUFIOACuoqK2-CTSawEvXm47tvMfedBvSkaXeUrQR_G4s7fxkygA138pe3Sm3umE1ADe_xuUJS4hJ2pAYJA7NdEnDY1hGpIFRoJW5ZyPZpwRD9UDEAoNOktptyT3JoVKe8hqDayiz3HQ3mhSvXs_i9mzMICDMIj6RHqKhsYpeEK9NrdPgGas57ule1nZpdwdYjYvTQZf45IV_FVcuKeShmHGR0'
    }
  }
];

// Initial Theses
export const INITIAL_THESES: Thesis[] = [
  {
    id: 'thesis-ia-edu',
    title: "Analyse des systèmes d'intelligence artificielle dans l'enseignement universitaire au Bénin",
    domain: 'Informatique',
    year: 2023,
    studentId: '2024-KH882',
    studentName: 'Koffi Zannou',
    studentEmail: 'koffi.zannou@uac.bj',
    studentAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC8DwdnL0ci7gXTIt9vf2FPmJRwh_urJmxkkIKomPruVsR-VE7hlsUFIOACuoqK2-CTSawEvXm47tvMfedBvSkaXeUrQR_G4s7fxkygA138pe3Sm3umE1ADe_xuUJS4hJ2pAYJA7NdEnDY1hGpIFRoJW5ZyPZpwRD9UDEAoNOktptyT3JoVKe8hqDayiz3HQ3mhSvXs_i9mzMICDMIj6RHqKhsYpeEK9NrdPgGas57ule1nZpdwdYjYvTQZf45IV_FVcuKeShmHGR0',
    status: 'accepted',
    submissionNotes: "Version finale validée par le jury.",
    fileUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCwuwn73BSrIQpGYOJaad-sc6meidnKQzx1sPpdjuPraSHs8lmoI7peBN-wzViNI5WeavVJtk1iiEEyvjzK3g_11DSTkHqlrnDEvTI-naP-K9DxStGE6FDAJzDoFAGrBmp8UvVLmf-uUOse1ujrIdeUmhvr4w3EqQEhmV0lng8SAD65AvIvph0A8pxXJmV_iHGEYF7sA_p4caMCb9TIgFscq4wBLNoT5RQUUwYMXHfnSzevzzvySvtekqK8QOIOgssVVZPXYLmb338',
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [
      {
        id: 'c1',
        authorName: 'Dr. Brice Soglo',
        authorRole: 'Rapporteur du jury',
        date: "Il y a 3 jours",
        text: "Excellentes corrections apportées à la section méthodologique. L'échantillonnage de l'étude est désormais très clair.",
        position: 'Page 14, Ligne 12'
      }
    ],
    history: [
      {
        id: 'h1',
        version: 'Version 2.1',
        date: '12 Oct. 2023',
        status: 'accepted',
        title: "Analyse des systèmes d'intelligence artificielle dans l'enseignement universitaire au Bénin",
        submittedBy: 'Koffi Zannou',
        notes: "Dernières corrections"
      }
    ]
  },
  {
    id: 'thesis-numerique-ens',
    title: "Analyse de l'impact du numérique sur l'enseignement supérieur au Bénin",
    domain: 'Sciences Économiques',
    year: 2023,
    studentId: 'student-amoussou-c',
    studentName: 'Clarisse Amoussou',
    studentEmail: 'clarisse.amoussou@uac.bj',
    studentAvatar: '',
    status: 'accepted',
    submissionNotes: "Rapport de soutenance validé avec mention Très Bien.",
    fileUrl: '',
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Hervé Tokpanou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-grh-pme',
    title: "Contribution à l'étude de la gestion des ressources humaines dans les PME béninoises",
    domain: 'Gestion',
    year: 2022,
    studentId: 'student-dossou',
    studentName: 'Rodrigue Dossou',
    studentEmail: 'rodrigue.dossou@uac.bj',
    studentAvatar: '',
    status: 'accepted',
    submissionNotes: "Travail de recherche finalisé et certifié conforme.",
    fileUrl: '',
    assignedTeacherId: '',
    assignedTeacherName: 'Pr. Fatoumata Alabi',
    comments: [],
    history: []
  },
  {
    id: 'thesis-ged-univ',
    title: "Mise en place d'un système de gestion électronique des documents dans les universités publiques",
    domain: 'Informatique',
    year: 2024,
    studentId: 'student-agbodjan',
    studentName: 'Koffi Agbodjan',
    studentEmail: 'koffi.agbodjan@uac.bj',
    studentAvatar: '',
    status: 'accepted',
    submissionNotes: "Mémoire accepté par le comité de lecture et validé pour soutenance.",
    fileUrl: '',
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Wilfried Lokossou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-ppp-admin',
    title: "Les opportunités et défis du contrat de partenariat public-privé en droit administratif béninois",
    domain: 'Droit',
    year: 2021,
    studentId: 'student-videgla',
    studentName: 'Chancelle Vidégla',
    studentEmail: 'chancelle.videgla@uac.bj',
    studentAvatar: '',
    status: 'accepted',
    submissionNotes: "Document final accepté après levée des réserves du jury.",
    fileUrl: '',
    assignedTeacherId: '',
    assignedTeacherName: 'Dr. Hervé Tokpanou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-chaussees',
    title: "Étude géotechnique et dimensionnement des chaussées face aux inondations récurrentes à Cotonou",
    domain: 'Génie Civil',
    year: 2023,
    studentId: 'student-brice-d',
    studentName: 'Brice Dossou',
    studentEmail: 'brice.dossou@uac.bj',
    studentAvatar: '',
    status: 'rejected',
    submissionNotes: "Rejeté pour insuffisance méthodologique et manque de données d'essais en laboratoire.",
    fileUrl: '',
    assignedTeacherId: '',
    assignedTeacherName: 'Pr. Fatoumata Alabi',
    comments: [
      {
        id: 'c_geo_1',
        authorName: 'Pr. Fatoumata Alabi',
        authorRole: 'Maître de mémoire',
        date: 'Il y a 4 jours',
        text: "Les essais de pénétration et l'analyse granulométrique des sols de Cotonou ne sont pas présentés de manière rigoureuse dans le chapitre 3."
      }
    ],
    history: []
  },
  {
    id: 'thesis-ia-agile',
    title: "Impact de l'IA Générative sur le développement logiciel agile au sein des tech hubs béninois",
    domain: 'IA & Big Data',
    year: 2023,
    studentId: 'student-gbaguidi',
    studentName: 'Rodrigue Gbaguidi',
    studentEmail: 'rodrigue.gbaguidi@uac.bj',
    studentAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAQKHl0idpb4dCnON9cd7K5fcu-GsGoYZaqDgxmpsIqrcxdzWiUYPXDEWGNjQrzenDfq7-FbF2JO2xBG8G6HlCnePJnpZ-w8_A_K36mT4333spea1XiBCeYOwFp36S4kBVrjjjijS-v099UbPrTNtzfOoOqsuymrSZSEZVdjfdyf-txUsPOHLBRAelRthj7DpBbpXqkSDC7YDW__YoQQxtT35qgvKGiRWYY4g3-FhLsvMZFUwoA2I5_XkkESd4JjKWgU4nNRClsUx4',
    status: 'pending', // Pending evaluation today
    submissionNotes: "Version 2.0 reçue hier.",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [],
    history: [
      {
        id: 'h201',
        version: 'Version 2.0',
        date: 'Hier',
        status: 'pending',
        title: "Impact de l'IA Générative sur le développement logiciel agile au sein des tech hubs béninois",
        submittedBy: 'Rodrigue Gbaguidi'
      }
    ]
  },
  {
    id: 'thesis-thermal',
    title: "Optimisation de la climatisation passive et thermique des habitats en zone côtière : Cas de Cotonou",
    domain: 'Architecture Durable',
    year: 2022,
    studentId: 'student-amoussou',
    studentName: 'Wilfried Amoussou',
    studentEmail: 'wilfried.amoussou@uac.bj',
    studentAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAmAVsJxK402m99zm6IZudh_7ef0VivmIH-ii_s_o3_bCLmruWPyyFLGXiW-CK_uNvE4wfK_WpzPmZB4sd1t7Te6s4AALIzS2wl8Gf0K3NU2IImO3LGSDm-Rjo6eITfauGFXADDb_d6XKU_gSShXQ8YiakEUSUg0kp0TqceQ_8l4g6geato8SM2ziAy-9Dbhm7sV5C7rZ3bNIWfMtAdNLE2is2gNvce8OEUMpgp-3cAUtZ6OCDoWZbFm9BWDXH2h0P3GjkgZszHgp8',
    status: 'rejected',
    submissionNotes: "Rejeté il y a 2 jours - En attente de correction",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [
      {
        id: 'c_obama',
        authorName: 'Dr. Arnaud Houessou',
        authorRole: 'Maître de mémoire',
        date: 'Il y a 2 jours',
        text: "L'analyse comparative des matériaux locaux (terre de barre rouge du Bénin) doit include des relevés thermiques plus complets en saison sèche."
      }
    ],
    history: [
      {
        id: 'h301',
        version: 'Version 1.2',
        date: 'Il y a 2 jours',
        status: 'rejected',
        title: "Optimisation de la climatisation passive et thermique des habitats en zone côtière : Cas de Cotonou",
        submittedBy: 'Wilfried Amoussou'
      }
    ]
  },
  {
    id: 'thesis-biopolymers',
    title: "Valorisation des déchets de coques de coton au Bénin pour la synthèse de biopolymères",
    domain: 'Biotechnologie',
    year: 2024,
    studentId: 'student-adjovi',
    studentName: 'Adjoua Dansou',
    studentEmail: 'adjoua.dansou@uac.bj',
    studentAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAkZDgX9Kle_2AnBGKk2ZfCAIRcSr0IK9kw67eqrQVgyZcYQ6VMWTX5CgTJTzbQnAJ_lEknQx6wc0_5OgixYtfye1GpnqG4M5n2cNWlOwyd3mfDnZSqZWM-gXMap-14Vi_NYVhfmwdOK2ZpEZwTdD-caLJO_Due4k9VE39XkKhqbVmzh3mNrWTcdFii0bE8wqbpRmej5vlm6CFY2N1A9lqlNHI4dgLRyJLrhBY906ATn5qdCjegG2P9MtbnkznGWhwV8cDCklTSIHQ',
    status: 'pending', // En cours de rédaction
    submissionNotes: "En cours de rédaction",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-blockchain',
    title: "Blockchain et traçabilité de la filière cajou au Bénin : Transparence des marchés",
    domain: 'Finance',
    year: 2023,
    studentId: 'student-kponou',
    studentName: 'Clarisse Kpènou',
    studentEmail: 'clarisse.kpenou@uac.bj',
    studentAvatar: '',
    status: 'accepted',
    submissionNotes: "Rapport final validé par le président de jury.",
    comments: [],
    history: []
  }
];

// Inscriptions en attente
export const INITIAL_PENDING_REGISTRATIONS: PendingRegistration[] = [
  {
    id: 'p-1',
    firstName: 'Rodrigue',
    lastName: 'Dansou',
    email: 'rodrigue.dansou@uac.bj',
    role: 'student',
    date: 'Il y a 2h'
  },
  {
    id: 'p-2',
    firstName: 'Fatoumata',
    lastName: 'Alabi',
    email: 'fatoumata.alabi@uac.bj',
    role: 'teacher',
    date: 'Il y a 5h'
  },
  {
    id: 'p-3',
    firstName: 'Gildas',
    lastName: 'Tokpanou',
    email: 'gildas.tokpanou@uac.bj',
    role: 'student',
    date: 'Hier'
  }
];

// Activity log flux
export const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'l-1',
    text: "Le Directeur des Études a validé le mémoire de Koffi Zannou.",
    date: "Il y a 10 minutes",
    type: 'success'
  },
  {
    id: 'l-2',
    text: "Nouvelle inscription d'étudiant Rodrigue Dansou.",
    date: "Il y a 2 heures",
    type: 'info'
  },
  {
    id: 'l-3',
    text: "Dr. Houessou a déposé un commentaire sur 'IA et Éthique'.",
    date: "Ce matin à 08:30",
    type: 'info'
  }
];

// Get initial State from Local Storage or default
export function getStoredState() {
  const usersStr = localStorage.getItem('gm_users');
  const thesesStr = localStorage.getItem('gm_theses');
  const registrationsStr = localStorage.getItem('gm_registrations');
  const logsStr = localStorage.getItem('gm_logs');

  let users = usersStr ? JSON.parse(usersStr) : INITIAL_USERS;
  let theses = thesesStr ? JSON.parse(thesesStr) : INITIAL_THESES;
  let registrations = registrationsStr ? JSON.parse(registrationsStr) : INITIAL_PENDING_REGISTRATIONS;
  let logs = logsStr ? JSON.parse(logsStr) : INITIAL_LOGS;

  let changed = false;

  // Assurer la conversion des noms français "Pierre Dupont" et "Lucie Laurent"
  // en noms africains pour les inscriptions en attente
  if (Array.isArray(registrations)) {
    registrations = registrations.map(reg => {
      let fName = reg.firstName || '';
      let lName = reg.lastName || '';
      let emailStr = reg.email || '';

      if (
        (fName.toLowerCase() === 'pierre' && lName.toLowerCase() === 'dupont') ||
        emailStr.toLowerCase().includes('dupont') ||
        emailStr.toLowerCase().includes('p.dupont')
      ) {
        fName = 'Rodrigue';
        lName = 'Dansou';
        emailStr = 'rodrigue.dansou@uac.bj';
        changed = true;
      }
      if (
        (fName.toLowerCase() === 'lucie' && lName.toLowerCase() === 'laurent') ||
        emailStr.toLowerCase().includes('laurent') ||
        emailStr.toLowerCase().includes('l.laurent')
      ) {
        fName = 'Fatoumata';
        lName = 'Alabi';
        emailStr = 'fatoumata.alabi@uac.bj';
        changed = true;
      }
      return { ...reg, firstName: fName, lastName: lName, email: emailStr };
    });
  }

  // Assurer la conversion dans l'historique d'activités
  if (Array.isArray(logs)) {
    logs = logs.map(l => {
      let text = l.text || '';
      const originalText = text;
      
      text = text.replace(/Pierre\s+Dupont/gi, 'Rodrigue Dansou');
      text = text.replace(/Lucie\s+Laurent/gi, 'Fatoumata Alabi');
      text = text.replace(/p\.dupont@univ\.fr/gi, 'rodrigue.dansou@uac.bj');
      text = text.replace(/l\.laurent@univ\.fr/gi, 'fatoumata.alabi@uac.bj');

      if (text !== originalText) {
        changed = true;
      }
      return { ...l, text };
    });
  }

  if (changed) {
    localStorage.setItem('gm_registrations', JSON.stringify(registrations));
    localStorage.setItem('gm_logs', JSON.stringify(logs));
  }

  return {
    users,
    theses,
    registrations,
    logs,
  };
}

// Save state to Local Storage
export function saveStoredState(state: {
  users: User[];
  theses: Thesis[];
  registrations: PendingRegistration[];
  logs: ActivityLog[];
}) {
  localStorage.setItem('gm_users', JSON.stringify(state.users));
  localStorage.setItem('gm_theses', JSON.stringify(state.theses));
  localStorage.setItem('gm_registrations', JSON.stringify(state.registrations));
  localStorage.setItem('gm_logs', JSON.stringify(state.logs));
}
