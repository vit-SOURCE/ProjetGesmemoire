import React, { useState, useMemo } from 'react';
import { 
  X, BookOpen, AlertCircle, ChevronRight, ZoomIn, ZoomOut, 
  BookOpenText, Search, Printer, Share2, Info, ArrowLeft, ArrowRight,
  Sparkles, FileText, CheckCircle
} from 'lucide-react';
import { Thesis } from '../types';
import { MEMOIRS_CONTENT } from '../data/memoirsContent';

interface MemoirReaderProps {
  thesis: Thesis;
  onClose: () => void;
}

export default function MemoirReader({ thesis, onClose }: MemoirReaderProps) {
  // Try to find full content, or fall back to dynamically generated based on the basic object
  const fullText = useMemo(() => {
    const existing = MEMOIRS_CONTENT[thesis.id];
    if (existing) return existing;

    // Generate readable fallback content if someone adds a custom thesis!
    return {
      id: thesis.id,
      title: thesis.title,
      author: thesis.studentName,
      supervisor: thesis.assignedTeacherName || "Dr. Arnaud Houessou",
      institution: "Université d'Abomey-Calavi (UAC)",
      faculty: "Faculté des Sciences de l'Ingénieur",
      year: thesis.year || 2026,
      sections: [
        {
          title: "Dédicaces et Remerciements",
          content: [
            `À ma famille, mes proches, et mes professeurs qui m'ont soutenu tout au long de cette formidable année académique.`,
            `Un remerciement tout particulier à mon maître de mémoire, ${thesis.assignedTeacherName || "Dr. Arnaud Houessou"}, pour son accompagnement, ses éclairages précieux et sa patience bienveillante.`
          ]
        },
        {
          title: "Résumé / Abstract",
          content: [
            `Résumé : Ce travail de recherche intitulé "${thesis.title}" étudie en profondeur le domaine "${thesis.domain}". À travers des méthodes comparatives et des évaluations empiriques, nous analysons les opportunités, les contraintes opérationnelles, et les recommandations stratégiques adaptées à l'écosystème académique et professionnel béninois.`,
            `Abstract: This master thesis, entitled "${thesis.title}" investigates key aspects of "${thesis.domain}". Using robust methodologies and field surveys in Cotonou, we explore practical implementations and regulatory guidelines to support scientific innovation and professional excellence in West Africa.`
          ]
        },
        {
          title: "Introduction Générale",
          content: [
            `Dans le contexte contemporain du développement scientifique et technologique mondial, le sujet "${thesis.title}" s'impose comme une préoccupation majeure à la fois académique, économique et sociétale au Bénin.`,
            `Les hypothèses de notre étude portent sur la réorganisation fonctionnelle des opérations et l'implémentation de solutions de souveraineté locale.`
          ]
        },
        {
          title: "Revue de la Littérature",
          content: [
            `L'analyse des contributions antérieures d'experts francophones et internationaux d'Afrique de l'Ouest indique un consensus concernant la modernisation des infrastructures.`,
            `Cependant, les études spécifiques au Bénin sont encore embryonnaires, ce qui justifie l'intérêt direct et pragmatique de nos travaux de recherche.`
          ]
        },
        {
          title: "Approche Méthodologique",
          content: [
            `Nous avons mis en place une démarche méthodologique structurée : conception de questionnaires d'évaluation, entretiens qualitatifs représentatifs, et analyses statistiques quantitatives avancées.`,
            `Cette approche garantit un niveau d'analyse rigoureux pour le traitement des données brutes récoltées.`
          ]
        },
        {
          title: "Résultats, Analyse et Discussion",
          content: [
            "Les résultats obtenus révèlent une adéquation remarquable avec nos hypothèses de recherche de départ. Des recommandations substantielles ont été élaborées pour le décanat universitaire.",
            "De plus, nous mettons en lumière les limites de notre analyse actuelle, notamment l'homogénéité de l'échantillon récolté à Abomey-Calavi."
          ]
        },
        {
          title: "Conclusion et Recommandations",
          content: [
            "Au terme de cette recherche menée avec rigueur, il ressort que ce sujet mérite une pérennisation durable à travers la création de laboratoires régionaux de recherche appliquée.",
            "Nous espérons ardemment que ce rapport ouvrira la voie à d'autres chercheurs passionnés par le développement durable et technologique."
          ]
        }
      ]
    };
  }, [thesis]);

  const [selectedSectionIdx, setSelectedSectionIdx] = useState<number>(0);
  const [zoomLevel, setZoomLevel] = useState<number>(100); // 90, 100, 110, 120
  const [paperTheme, setPaperTheme] = useState<'white' | 'cream' | 'dark'>('cream');
  const [searchQuery, setSearchQuery] = useState('');

  // Search filter for table of contents / highlights
  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) {
      return fullText.sections.map((sec, idx) => ({ ...sec, idx, matched: false }));
    }
    const query = searchQuery.toLowerCase();
    return fullText.sections.map((sec, idx) => {
      const titleMatches = sec.title.toLowerCase().includes(query);
      const contentMatches = sec.content.some(paragraph => paragraph.toLowerCase().includes(query));
      return {
        ...sec,
        idx,
        matched: titleMatches || contentMatches
      };
    });
  }, [fullText, searchQuery]);

  const activeSection = fullText.sections[selectedSectionIdx] || fullText.sections[0];

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 10, 130));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 10, 80));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-[120] bg-slate-900/90 backdrop-blur-md flex flex-col md:flex-row animate-fade-in text-slate-800">
      
      {/* Sidebar Tool and index panel */}
      <aside className="w-full md:w-80 bg-slate-50 border-r border-slate-200 flex flex-col justify-between shrink-0 h-1/4 md:h-full">
        
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 bg-white">
          <div className="flex justify-between items-center mb-3">
            <span className="flex items-center gap-1.5 text-xs font-bold text-primary uppercase tracking-wider">
              <BookOpen className="w-4 h-4 text-primary" />
              Lecteur de Thèse
            </span>
            <button 
              onClick={onClose}
              className="md:hidden text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <h3 className="font-bold text-sm text-slate-900 line-clamp-2 leading-snug">
            {thesis.title}
          </h3>
          <p className="text-[11px] text-slate-500 font-medium mt-1">
            Par {thesis.studentName}
          </p>
        </div>

        {/* Section Index List with search */}
        <div className="flex-grow overflow-y-auto p-4 space-y-3">
          {/* Search box */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
            <input 
              type="text"
              placeholder="Rechercher dans le texte..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs w-full focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
            />
          </div>

          <div className="space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Table des matières
            </p>
            
            {/* Front Page Cover navigation link */}
            <button
              onClick={() => {
                setSelectedSectionIdx(-1);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left text-xs font-bold transition-all cursor-pointer ${
                selectedSectionIdx === -1 
                  ? 'bg-primary text-white shadow-sm' 
                  : 'text-slate-700 hover:bg-slate-200/60'
              }`}
            >
              <span className="truncate">Page de Garde (Couverture)</span>
              <ChevronRight className="w-3.5 h-3.5 opacity-60" />
            </button>

            {/* Chapters navigation */}
            {filteredSections.map((sec) => (
              <button
                key={sec.idx}
                onClick={() => {
                  setSelectedSectionIdx(sec.idx);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left text-xs transition-all cursor-pointer ${
                  selectedSectionIdx === sec.idx 
                    ? 'bg-primary text-white font-bold shadow-sm' 
                    : sec.matched
                      ? 'bg-amber-100 border border-amber-200 hover:bg-amber-200/80 text-amber-900'
                      : 'text-slate-700 hover:bg-slate-200/60'
                }`}
              >
                <span className="truncate flex items-center gap-1.5">
                  <span className="text-[10px] opacity-50 font-mono">{(sec.idx + 1).toString().padStart(2, '0')}</span>
                  <span className="truncate">{sec.title}</span>
                </span>
                <ChevronRight className={`w-3.5 h-3.5 opacity-60 ${sec.matched ? 'text-amber-800' : ''}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Configurations bottom panel */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 space-y-3 shrink-0">
          
          {/* Zoom controls & paper color theme */}
          <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-200/70 shadow-2xs">
            <div className="flex items-center gap-1">
              <button 
                onClick={handleZoomOut} 
                disabled={zoomLevel <= 80}
                className="p-1 hover:bg-slate-100 disabled:opacity-30 rounded text-slate-600"
                title="Zoom arrière"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-bold text-slate-500 min-w-[32px] text-center">
                {zoomLevel}%
              </span>
              <button 
                onClick={handleZoomIn} 
                disabled={zoomLevel >= 130}
                className="p-1 hover:bg-slate-100 disabled:opacity-30 rounded text-slate-600"
                title="Zoom avant"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-1 border-l pl-2 border-slate-200">
              <button 
                onClick={() => setPaperTheme('white')}
                className={`w-5 h-5 rounded-full border bg-white ${paperTheme === 'white' ? 'ring-2 ring-primary ring-offset-1 border-primary/50' : 'border-slate-300'}`}
                title="Blanc"
              />
              <button 
                onClick={() => setPaperTheme('cream')}
                className={`w-5 h-5 rounded-full border bg-amber-50/70 ${paperTheme === 'cream' ? 'ring-2 ring-primary ring-offset-1 border-amber-400' : 'border-slate-300'}`}
                title="Sépia / Crème"
              />
              <button 
                onClick={() => setPaperTheme('dark')}
                className={`w-5 h-5 rounded-full border bg-slate-800 ${paperTheme === 'dark' ? 'ring-2 ring-primary ring-offset-1 border-slate-700' : 'border-slate-300'}`}
                title="Sombre"
              />
            </div>
          </div>

          {/* Action triggers */}
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={handlePrint}
              className="flex items-center justify-center gap-1.5 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg py-2 text-xs font-semibold text-slate-700 transition-colors pointer-events-auto"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              Imprimer
            </button>
            <button 
              onClick={() => alert(`Lien de partage du mémoire copié dans le presse-papier !`)}
              className="flex items-center justify-center gap-1.5 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg py-2 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-500" />
              Partager
            </button>
          </div>
        </div>
      </aside>

      {/* Main Reading Canvas */}
      <section className="flex-grow flex flex-col h-3/4 md:h-full justify-between overflow-hidden">
        
        {/* Header Toolbar */}
        <header className="bg-slate-800 text-white px-6 py-4 flex justify-between items-center shrink-0 border-b border-slate-700 shadow-sm">
          <div className="flex items-center gap-2">
            <BookOpenText className="w-5 h-5 text-emerald-400" />
            <div>
              <p className="text-xs font-bold leading-none text-slate-200">GesMemoires Academic Reader</p>
              <p className="text-[10px] text-slate-400 font-medium mt-0.5">Université d'Abomey-Calavi • Archive Ouverte</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {thesis.status === 'accepted' ? (
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase flex items-center gap-1">
                <CheckCircle className="w-3 h-3 text-emerald-400 animate-pulse" />
                Document Certifié
              </span>
            ) : (
              <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2.5 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase">
                {thesis.status === 'pending' ? 'En Examen' : 'En Correction'}
              </span>
            )}

            <button 
              onClick={onClose}
              className="hidden md:flex bg-slate-700 text-slate-300 hover:text-white p-2 rounded-lg transition-colors cursor-pointer"
              title="Fermer le lecteur"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Paper Container Canvas */}
        <div className="flex-grow overflow-y-auto p-4 md:p-8 flex justify-center items-start bg-slate-900/40">
          
          <div 
            style={{ fontSize: `${zoomLevel / 100}rem` }}
            className={`w-full max-w-3xl rounded-xl shadow-2xl p-8 md:p-14 min-h-[85vh] transition-all duration-300 ${
              paperTheme === 'cream' 
                ? 'bg-amber-50/95 text-yellow-980 border border-amber-200/40' 
                : paperTheme === 'dark' 
                  ? 'bg-slate-800 text-slate-100 border border-slate-700' 
                  : 'bg-white text-slate-900 border border-slate-200'
            }`}
          >
            {/* 1. Page de Garde Mode (Cover page) */}
            {selectedSectionIdx === -1 ? (
              <div className="flex flex-col justify-between min-h-[70vh] text-center border-4 border-double border-slate-300 p-6 md:p-10 font-sans">
                
                {/* University Title Head */}
                <div className="space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    République du Bénin
                  </h4>
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mx-auto my-1"></div>
                  <h5 className="text-[11px] font-bold uppercase text-slate-400">
                    Ministère de l'Enseignement Supérieur et de la Recherche Scientifique
                  </h5>
                  <h3 className="text-sm md:text-base font-extrabold uppercase text-primary tracking-wide pt-1">
                    {fullText.institution}
                  </h3>
                  <p className="text-[10px] font-bold text-slate-500 border-t border-slate-200 pt-1.5 max-w-xs mx-auto">
                    {fullText.faculty}
                  </p>
                </div>

                {/* Main Memoir Title box */}
                <div className="my-10 space-y-4">
                  <span className="bg-primary/5 border border-primary/20 text-primary px-3 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase">
                    Mémoire de Fin d'Études de Master II
                  </span>
                  <h1 className="text-xl md:text-2xl font-extrabold tracking-tight leading-tight pt-2 max-w-2xl mx-auto uppercase">
                    "{fullText.title}"
                  </h1>
                  <div className="w-16 h-1 bg-primary mx-auto my-4 rounded-full"></div>
                  <p className="text-[11px] text-slate-500 italic max-w-md mx-auto">
                    Présenté et soutenu publiquement en vue de l'obtention du grade de Master en {thesis.domain}
                  </p>
                </div>

                {/* Dynamic Author and Advisor */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left border-t border-slate-200 pt-6 max-w-xl mx-auto">
                  <div className="text-center md:text-left">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Présenté par :</p>
                    <p className="text-sm font-black text-slate-900 uppercase mt-0.5">{fullText.author}</p>
                    <p className="text-[10px] text-slate-500">Étudiant de l'Université</p>
                  </div>
                  <div className="text-center md:text-right">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Sous la direction de :</p>
                    <p className="text-sm font-black text-slate-900 mt-0.5">{fullText.supervisor}</p>
                    <p className="text-[10px] text-slate-500">Maître de mémoire certifié</p>
                  </div>
                </div>

                {/* Footer Center Grade Year */}
                <div className="mt-10 border-t border-dashed border-slate-200 pt-4">
                  <p className="text-xs font-bold text-slate-500">
                    Année académique : {fullText.year - 1} - {fullText.year}
                  </p>
                  <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                    Cotonou, République du Bénin
                  </p>
                </div>

              </div>
            ) : (
              // 2. Main content Chapter view
              <div className="space-y-6">
                
                {/* Chapter Head Header bar */}
                <div className="border-b pb-4 flex justify-between items-center text-slate-400 text-[11px] font-mono">
                  <span>Chapitre {(selectedSectionIdx + 1).toString().padStart(2, '0')}</span>
                  <span className="max-w-xs truncate text-right font-sans font-semibold">{thesis.title}</span>
                </div>

                {/* Main Chapter Title */}
                <h2 className={`text-xl md:text-2xl font-black tracking-tight ${paperTheme === 'dark' ? 'text-slate-100' : 'text-primary'}`}>
                  {activeSection.title}
                </h2>
                
                {/* Content Paragraphs */}
                <div className="space-y-5 text-justify leading-relaxed font-sans text-sm md:text-base">
                  {activeSection.content.map((p, pIdx) => {
                    const isFigure = p.startsWith("Figure") || p.startsWith("Tableau");
                    
                    // Highlight logic if searching
                    const hasHighlight = searchQuery.trim() && p.toLowerCase().includes(searchQuery.toLowerCase());
                    
                    if (isFigure) {
                      return (
                        <div key={pIdx} className="my-8 py-6 px-4 bg-slate-100/50 border border-slate-200 rounded-xl text-center space-y-2">
                          <FileText className="w-8 h-8 text-primary/40 mx-auto" />
                          <p className="text-xs font-bold text-slate-600 italic">
                            {p}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            Graphique statistique ou illustration simulée pour l'analyse académique.
                          </p>
                        </div>
                      );
                    }

                    if (hasHighlight) {
                      // Simple text highlighting replacement
                      const parts = p.split(new RegExp(`(${searchQuery})`, 'gi'));
                      return (
                        <p key={pIdx} className="indent-6">
                          {parts.map((part, i) => 
                            part.toLowerCase() === searchQuery.toLowerCase()
                              ? <mark key={i} className="bg-amber-300 text-slate-900 rounded px-0.5 font-semibold">{part}</mark>
                              : part
                          )}
                        </p>
                      );
                    }

                    return (
                      <p key={pIdx} className="indent-6 leading-relaxed">
                        {p}
                      </p>
                    );
                  })}
                </div>

                {/* Chapter metadata info badge at the bottom */}
                <div className="pt-8 border-t border-dashed border-slate-300 mt-10 rounded-lg p-4 bg-primary/5 flex items-start gap-3">
                  <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-[11px] text-slate-500 leading-normal font-sans">
                    Vous lisez un extrait authentifié extrait du rapport officiel de fin d'études de <strong className="text-primary">{fullText.author}</strong>. Ce document est protégé par le droit d'auteur universitaire béninois et la politique de propriété intellectuelle de l'UAC.
                  </p>
                </div>

              </div>
            )}

          </div>

        </div>

        {/* Floating next/back bottom triggers */}
        <footer className="bg-slate-800 border-t border-slate-700 px-6 py-4 flex justify-between items-center text-slate-300 text-xs shrink-0">
          <button
            disabled={selectedSectionIdx <= -1}
            onClick={() => setSelectedSectionIdx(prev => prev - 1)}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg disabled:opacity-30 hover:bg-slate-600 duration-155 text-slate-200 font-bold ml-1 pointer-events-auto cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Précédent
          </button>

          <span className="font-mono text-[11px] text-slate-400">
            {selectedSectionIdx === -1 
              ? 'Couverture de garde' 
              : `Page ${selectedSectionIdx + 1} / ${fullText.sections.length}`
            }
          </span>

          <button
            disabled={selectedSectionIdx >= fullText.sections.length - 1}
            onClick={() => setSelectedSectionIdx(prev => prev + 1)}
            className="flex items-center gap-1.5 px-4 py-2 bg-primary hover:bg-primary-container disabled:opacity-30 border border-primary/20 rounded-lg duration-155 text-white font-bold cursor-pointer"
          >
            Suivant
            <ArrowRight className="w-4 h-4" />
          </button>
        </footer>

      </section>

    </div>
  );
}
