import React, { useState } from 'react';
import { School, ArrowRight, Eye, EyeOff, Upload, CheckCircle2, FileText, Info, AlertCircle, Sparkles, Loader2 } from 'lucide-react';

interface RegisterStep1Props {
  onNext: (formData: any) => void;
  onNavigate: (view: string) => void;
}

export default function RegisterStep1({ onNext, onNavigate }: RegisterStep1Props) {
  const [activeTab, setActiveTab] = useState<'non-diplome' | 'diplome' | 'enseignant'>('non-diplome');
  
  // Informelles Communes
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Champs Formulaires 1 & 2
  const [filiere, setFiliere] = useState('');
  
  // Champs Formulaire 2
  const [thesisTitle, setThesisTitle] = useState('');
  const [thesisYear, setThesisYear] = useState('');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfFileName, setPdfFileName] = useState('');
  const [pdfError, setPdfError] = useState('');

  // Champs Formulaire 3
  const [specialties, setSpecialties] = useState<string[]>([]);

  // États Écran
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Nouveaux champs de vérification
  const [studentMatricule, setStudentMatricule] = useState('');
  const [studentMatriculeError, setStudentMatriculeError] = useState('');

  const [gradMatricule, setGradMatricule] = useState('');
  const [gradMatriculeError, setGradMatriculeError] = useState('');
  const [gradYear, setGradYear] = useState('');
  const [gradYearError, setGradYearError] = useState('');
  const [gradThesisTitleError, setGradThesisTitleError] = useState('');

  const [teacherMatricule, setTeacherMatricule] = useState('');
  const [teacherMatriculeError, setTeacherMatriculeError] = useState('');
  const [teacherGrade, setTeacherGrade] = useState('');
  const [teacherGradeError, setTeacherGradeError] = useState('');

  const listGradYears = Array.from({ length: 2026 - 2015 + 1 }, (_, i) => (2015 + i).toString());
  const listGrades = ["Assistant", "Attaché de Recherche", "Maître Assistant", "Maître de Conférences", "Professeur Titulaire"];

  const listFilieres = ["Informatique", "Gestion", "Droit", "Sciences Économiques", "Génie Civil", "Autre"];
  const listSpecialties = [
    "Informatique",
    "Réseaux & Télécommunications",
    "Gestion des Entreprises",
    "Droit des Affaires",
    "Sciences Économiques",
    "Génie Civil",
    "Intelligence Artificielle",
    "Cybersécurité",
    "Autre"
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== 'application/pdf') {
      setPdfError('Le fichier doit être au format PDF.');
      setPdfFile(null);
      setPdfFileName('');
      return;
    }
    
    if (file.size > 50 * 1024 * 1024) {
      setPdfError('Le fichier est trop volumineux (max 50 Mo).');
      setPdfFile(null);
      setPdfFileName('');
      return;
    }
    
    setPdfError('');
    setPdfFile(file);
    setPdfFileName(file.name);
  };

  const handleSpecialtyChange = (spec: string) => {
    if (specialties.includes(spec)) {
      setSpecialties(specialties.filter(s => s !== spec));
    } else {
      setSpecialties([...specialties, spec]);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setStudentMatriculeError('');
    setGradMatriculeError('');
    setGradYearError('');
    setGradThesisTitleError('');
    setTeacherMatriculeError('');
    setTeacherGradeError('');

    // 1. Validation basique commune
    if (!firstName.trim() || !lastName.trim() || !email.trim() || !password.trim()) {
      setErrorMsg("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    if (!email.includes('@')) {
      setErrorMsg("Le format de l'adresse email institutionnelle n'est pas correct.");
      return;
    }

    if (password.length < 8) {
      setErrorMsg("Le mot de passe doit contenir au moins 8 caractères.");
      return;
    }

    let hasError = false;

    // 2. Validation spécifique
    if (activeTab === 'non-diplome') {
      if (!filiere) {
        setErrorMsg("Veuillez sélectionner votre filière.");
        hasError = true;
      }
      if (!studentMatricule.trim()) {
        setStudentMatriculeError("Ce champ est obligatoire.");
        hasError = true;
      } else if (!/^ETU\d+$/.test(studentMatricule.trim())) {
        setStudentMatriculeError("Numéro d'étudiant invalide. Format attendu : ETU suivi de chiffres.");
        hasError = true;
      }
    } else if (activeTab === 'diplome') {
      if (!filiere) {
        setErrorMsg("Veuillez sélectionner votre filière.");
        hasError = true;
      }
      if (!gradMatricule.trim()) {
        setGradMatriculeError("Ce champ est obligatoire.");
        hasError = true;
      } else if (!/^ETU\d+$/.test(gradMatricule.trim())) {
        setGradMatriculeError("Numéro d'étudiant invalide. Format attendu : ETU suivi de chiffres.");
        hasError = true;
      }
      if (!gradYear) {
        setGradYearError("Vous devez renseigner votre année de diplôme pour vous inscrire comme étudiant diplômé.");
        hasError = true;
      }
      if (!thesisTitle.trim()) {
        setGradThesisTitleError("Veuillez renseigner le titre de votre mémoire.");
        hasError = true;
      } else if (thesisTitle.trim().length < 10) {
        setGradThesisTitleError("Le titre exact du mémoire doit faire au moins 10 caractères.");
        hasError = true;
      }
      if (!thesisYear.trim() || isNaN(Number(thesisYear)) || Number(thesisYear) < 1990 || Number(thesisYear) > 2026) {
        setErrorMsg("Veuillez renseigner une année de soutenance valide (ex: 2024).");
        hasError = true;
      }
      if (!pdfFile) {
        setErrorMsg("Veuillez téléverser votre mémoire (fichier PDF, max 50 Mo).");
        hasError = true;
      }
    } else if (activeTab === 'enseignant') {
      if (!teacherMatricule.trim()) {
        setTeacherMatriculeError("Le numéro de matricule professeur est obligatoire.");
        hasError = true;
      } else if (!/^PRO\d+$/.test(teacherMatricule.trim())) {
        setTeacherMatriculeError("Numéro professeur invalide. Format attendu : PRO suivi de chiffres.");
        hasError = true;
      }
      if (!teacherGrade) {
        setTeacherGradeError("Veuillez sélectionner votre grade académique.");
        hasError = true;
      }
      if (specialties.length === 0) {
        setErrorMsg("Veuillez cocher au moins une spécialité académique.");
        hasError = true;
      }
    }

    if (hasError) {
      return;
    }

    // Toutes les validations ont été passées avec succès
    setSubmitting(true);

    setTimeout(() => {
      try {
        const usersStr = localStorage.getItem('gm_users') || '[]';
        const thesesStr = localStorage.getItem('gm_theses') || '[]';
        const registrationsStr = localStorage.getItem('gm_registrations') || '[]';
        const logsStr = localStorage.getItem('gm_logs') || '[]';

        const currentUsers = JSON.parse(usersStr);
        const currentTheses = JSON.parse(thesesStr);
        const currentRegistrations = JSON.parse(registrationsStr);
        const currentLogs = JSON.parse(logsStr);

        const newUserId = `user-${Date.now()}`;

        if (activeTab === 'non-diplome') {
          // FORMULAIRE 1 — Inscription : Étudiant non diplômé (en recherche)
          const newStudent = {
            id: newUserId,
            firstName,
            lastName,
            email,
            role: 'student' as const,
            details: {
              studentId: studentMatricule.trim(),
              faculty: filiere,
              cycle: "Licence en cours",
              status: "En attente",
              avatarUrl: ""
            }
          };

          const newReg = {
            id: `reg-${Date.now()}`,
            firstName,
            lastName,
            email,
            role: 'student' as const,
            date: "À l'instant"
          };

          const newLog = {
            id: `log-${Date.now()}`,
            text: `Nouvelle demande d'inscription d'étudiant non diplômé reçue de ${firstName} ${lastName} (Matricule: ${studentMatricule.trim()}).`,
            date: "À l'instant",
            type: 'info' as const
          };

          localStorage.setItem('gm_users', JSON.stringify([...currentUsers, newStudent]));
          localStorage.setItem('gm_registrations', JSON.stringify([newReg, ...currentRegistrations]));
          localStorage.setItem('gm_logs', JSON.stringify([newLog, ...currentLogs]));

          setSuccessMsg("Votre demande est en attente de validation par le Directeur des Études.");

        } else if (activeTab === 'diplome') {
          // FORMULAIRE 2 — Inscription : Étudiant diplômé (soumission de mémoire)
          const newGradStudent = {
            id: newUserId,
            firstName,
            lastName,
            email,
            role: 'student-grad' as const,
            details: {
              studentId: gradMatricule.trim(),
              faculty: filiere,
              cycle: `Diplômé d'études (Promo ${gradYear})`,
              status: "Actif",
              avatarUrl: ""
            }
          };

          const newThesis = {
            id: `thesis-${Date.now()}`,
            title: thesisTitle,
            domain: filiere,
            year: parseInt(gradYear) || parseInt(thesisYear) || 2026,
            studentId: gradMatricule.trim(),
            studentName: `${firstName} ${lastName}`,
            studentEmail: email,
            status: 'pending' as const,
            comments: [],
            history: [
              {
                id: `hist-${Date.now()}`,
                version: "v1.0",
                date: "À l'instant",
                status: 'pending' as const,
                title: thesisTitle,
                submittedBy: `${firstName} ${lastName}`,
                notes: `Dépôt initial du fichier mémoire lors de l'inscription par le diplômé de la promo ${gradYear}.`
              }
            ],
            fileUrl: pdfFileName || "document_memoire.pdf"
          };

          const newLog = {
            id: `log-${Date.now()}`,
            text: `Le diplômé ${firstName} ${lastName} (Matricule: ${gradMatricule.trim()}, Promo: ${gradYear}) s'est inscrit et a déposé son mémoire "${thesisTitle}".`,
            date: "À l'instant",
            type: 'success' as const
          };

          localStorage.setItem('gm_users', JSON.stringify([...currentUsers, newGradStudent]));
          localStorage.setItem('gm_theses', JSON.stringify([newThesis, ...currentTheses]));
          localStorage.setItem('gm_logs', JSON.stringify([newLog, ...currentLogs]));

          setSuccessMsg("Votre mémoire a bien été soumis. Il est en attente de validation par votre maître de mémoire.");

        } else if (activeTab === 'enseignant') {
          // FORMULAIRE 3 — Inscription : Maître de mémoire / Professeur
          const newTeacher = {
            id: newUserId,
            firstName,
            lastName,
            email,
            role: 'teacher' as const,
            details: {
              titleOffice: teacherGrade,
              status: "En attente",
              avatarUrl: "",
              specialties: specialties.join(', ')
            }
          };

          const newReg = {
            id: `reg-${Date.now()}`,
            firstName,
            lastName,
            email,
            role: 'teacher' as const,
            date: "À l'instant"
          };

          const newLog = {
            id: `log-${Date.now()}`,
            text: `Nouvelle demande d'inscription d'enseignant reçue de ${firstName} ${lastName} (Grade: ${teacherGrade}, Matricule: ${teacherMatricule.trim()}, Spécialités: ${specialties.join(', ')}).`,
            date: "À l'instant",
            type: 'info' as const
          };

          localStorage.setItem('gm_users', JSON.stringify([...currentUsers, newTeacher]));
          localStorage.setItem('gm_registrations', JSON.stringify([newReg, ...currentRegistrations]));
          localStorage.setItem('gm_logs', JSON.stringify([newLog, ...currentLogs]));

          setSuccessMsg("Votre demande est en attente de validation par le Directeur des Études.");
        }
      } catch (err) {
        console.error(err);
        setErrorMsg("Un problème technique est survenu.");
      } finally {
        setSubmitting(false);
      }
    }, 1200);
  };

  return (
    <div className="bg-background text-on-surface min-h-screen">
      {/* Top Header */}
      <header className="fixed top-0 left-0 w-full z-50 bg-white border-b border-outline-variant px-6 py-4 flex flex-col gap-2 shadow-sm">
        <div className="flex justify-between items-center max-w-7xl mx-auto w-full">
          <div className="flex items-center gap-2">
            <School className="text-primary w-6 h-6" />
            <span className="font-bold text-lg text-primary tracking-tight">GesMemoires</span>
          </div>
          <div className="flex items-center">
            <span className="text-xs font-bold text-secondary uppercase tracking-wider">Inscription</span>
          </div>
        </div>
        <div className="w-full bg-surface-container-high h-1 absolute bottom-0 left-0 animate-pulse">
          <div className="bg-primary h-full w-full transition-all duration-300"></div>
        </div>
      </header>

      <main className="min-h-screen pt-24 pb-16 px-6 flex items-center justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-7xl w-full">
          {/* Left Side: Brand Text */}
          <div className="hidden lg:flex lg:col-span-5 flex-col justify-center pr-8 space-y-6">
            <h1 className="text-4xl lg:text-5xl font-bold text-primary leading-tight tracking-tight">
              L'excellence académique commence ici.
            </h1>
            <p className="text-secondary text-base leading-relaxed max-w-md">
              Rejoignez la plateforme académique de référence de l'UAC pour la gestion, le dépôt et la consultation des mémoires de recherche scientifique.
            </p>
            <div className="pt-4">
              <img 
                alt="Modern library" 
                className="rounded-xl shadow-sm w-full object-cover h-64 border border-outline-variant" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1V8lJkGKn6LOso1zTAAbORRakDejIqkguYtFAZepSJ95DKak6QpWz-cFrsu036HjALUmCiqdfwGLn6TtHRiAYhT_HbvTP1FOdhZZbTI5JtlXf7XF0761WMdlfYLXZMZh6ZcNjeclIle-FPfFZOBMUMND_HpVijOSQioEv-ClwCNht67a_fT-syLiy0H22sby01NExzIx4hxFKkR5lY5yt8yn3ZPv8sSShgOOJig7m_MSVhJapIZo2p_pGSiR4k2uwVHzNqwZR9h4" 
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Right Side: Tabbed Form Cards */}
          <div className="lg:col-span-7 flex items-center justify-center">
            <div className="bg-white border border-outline-variant p-6 md:p-8 rounded-xl shadow-sm w-full max-w-xl transition-all">
              
              {/* Success message view */}
              {successMsg ? (
                <div id="registration-success-card" className="text-center py-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-emerald-600 animate-bounce" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Félicitations !</h3>
                  <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-xl text-emerald-800 font-medium text-sm leading-relaxed mb-4 max-w-md mx-auto shadow-xs">
                    "{successMsg}"
                  </div>

                  {/* Indicateur visuel de temps d'attente estimé sous le message de succès */}
                  <div className="mb-8 p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs text-left max-w-md mx-auto flex items-start gap-3 shadow-2xs">
                    <div className="p-1 bg-amber-100 rounded-lg shrink-0 mt-0.5">
                      <svg className="w-4 h-4 text-amber-700 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-bold tracking-tight uppercase text-[10px] text-amber-800">Temps d'attente estimé de validation :</p>
                      <p className="mt-1 font-semibold text-amber-700 leading-normal">
                        Environ <span className="underline decoration-wavy">24 à 48 heures ouvrables</span>. <br />
                        Le Directeur des Études étudie votre dossier académique pour valider ou rejeter votre accès. Vous recevrez une notification par email dès que le statut de votre profil sera mis à jour.
                      </p>
                    </div>
                  </div>

                  <button 
                    onClick={() => onNavigate('login')} 
                    className="px-8 py-3 bg-primary text-white text-sm font-semibold rounded-lg hover:bg-primary/95 shadow-sm hover:shadow active:scale-95 transition-all w-full cursor-pointer"
                  >
                    Aller à la page de connexion
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-primary tracking-tight">Créer votre compte</h2>
                    <p className="text-xs text-secondary mt-1">
                      Choisissez votre profil universitaire ci-dessous pour remplir le formulaire requis.
                    </p>
                  </div>

                  {/* PROFILES TAB SWITCHER */}
                  <div className="flex flex-col sm:flex-row bg-slate-100 p-1.5 rounded-xl gap-1 border border-outline-variant/65 mb-6">
                    <button
                      type="button"
                      id="tab-non-diplome"
                      onClick={() => { setActiveTab('non-diplome'); setErrorMsg(null); }}
                      className={`flex-1 text-center py-2.5 px-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        activeTab === 'non-diplome'
                          ? 'bg-primary text-white shadow'
                          : 'text-secondary hover:text-primary hover:bg-white/40'
                      }`}
                    >
                      Non Diplômé
                    </button>
                    <button
                      type="button"
                      id="tab-diplome"
                      onClick={() => { setActiveTab('diplome'); setErrorMsg(null); }}
                      className={`flex-1 text-center py-2.5 px-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        activeTab === 'diplome'
                          ? 'bg-primary text-white shadow'
                          : 'text-secondary hover:text-primary hover:bg-white/40'
                      }`}
                    >
                      Diplômé (Dépôt)
                    </button>
                    <button
                      type="button"
                      id="tab-enseignant"
                      onClick={() => { setActiveTab('enseignant'); setErrorMsg(null); }}
                      className={`flex-1 text-center py-2.5 px-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        activeTab === 'enseignant'
                          ? 'bg-primary text-white shadow'
                          : 'text-secondary hover:text-primary hover:bg-white/40'
                      }`}
                    >
                      Maître de mémoire
                    </button>
                  </div>

                  {/* Informational Sub-badge */}
                  <div className="bg-slate-50 border border-slate-200/60 p-3 rounded-lg flex items-start gap-2 mb-6 text-xs text-secondary">
                    <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <div>
                      {activeTab === 'non-diplome' && (
                        <span>Formulaire d'inscription pour les étudiants encore en formation (recherche de mémoires, préparation du projet)</span>
                      )}
                      {activeTab === 'diplome' && (
                        <span>Formulaire d'inscription pour les diplômés académiques souhaitant archiver et soumettre officiellement leur mémoire</span>
                      )}
                      {activeTab === 'enseignant' && (
                        <span>Portail d'évaluation et de direction académique pour les professeurs et encadrants d'études universitaires</span>
                      )}
                    </div>
                  </div>

                  {/* Message Anti-fraude */}
                  <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg flex items-start gap-2 mb-6 text-xs text-amber-900 leading-relaxed font-semibold shadow-xs">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>
                      Toute inscription dans une catégorie qui ne correspond pas à votre statut réel entraînera le rejet automatique de votre dossier par le Directeur des Études.
                    </span>
                  </div>

                  {errorMsg && (
                    <div className="mb-4 bg-error-container/20 border border-error/20 p-3.5 rounded-lg flex items-center gap-2.5 text-xs text-error font-medium">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {/* FORM RENDER */}
                  <form onSubmit={handleFormSubmit} className="space-y-4">
                    
                    {/* Nom & Prénom communs */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex flex-col gap-1.5">
                        <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="first_name">
                          Prénom <span className="text-error">*</span>
                        </label>
                        <input 
                          required
                          className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm" 
                          id="first_name" 
                          placeholder="Ex: Koffi" 
                          type="text"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="last_name">
                          Nom <span className="text-error">*</span>
                        </label>
                        <input 
                          required
                          className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm" 
                          id="last_name" 
                          placeholder="Ex: Zannou" 
                          type="text"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Email institutionnel commun */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="email">
                        Email institutionnel <span className="text-error">*</span>
                      </label>
                      <input 
                        required
                        className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm" 
                        id="email" 
                        placeholder={activeTab === 'enseignant' ? "professeur@uac.bj" : "etudiant@uac.bj"}
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>

                    {/* Mot de passe commun */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="password">
                        Mot de passe <span className="text-error">*</span>
                      </label>
                      <div className="relative">
                        <input 
                          required
                          className="w-full pl-3.5 pr-10 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm" 
                          id="password" 
                          placeholder="••••••••" 
                          type={showPassword ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                        />
                        <button 
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-primary transition-colors cursor-pointer" 
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <p className="text-[10px] text-secondary">
                        Minimum 8 caractères, requis pour sécuriser votre compte.
                      </p>
                    </div>

                    {/* SPECIFIC TAB FIELDS */}
                    
                    {/* FORMULAIRE 1 — Étudiant non diplômé (en recherche) */}
                    {activeTab === 'non-diplome' && (
                      <div className="space-y-4 pt-2 border-t border-slate-100 animate-fadeIn">
                        
                        {/* Choix de la filière */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="filiere_non_diplome">
                            Choix de la filière <span className="text-error">*</span>
                          </label>
                          <select 
                            required
                            id="filiere_non_diplome"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            value={filiere}
                            onChange={(e) => setFiliere(e.target.value)}
                          >
                            <option value="">-- Sélectionnez une filière --</option>
                            {listFilieres.map((fName) => (
                              <option key={fName} value={fName}>{fName}</option>
                            ))}
                          </select>
                        </div>

                        {/* Numéro d'étudiant (matricule) */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="matricule_non_diplome">
                            Numéro d'étudiant (matricule) <span className="text-error">*</span>
                          </label>
                          <input 
                            required
                            id="matricule_non_diplome"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            placeholder="Ex: ETU001"
                            type="text"
                            value={studentMatricule}
                            onChange={(e) => {
                              setStudentMatricule(e.target.value);
                              setStudentMatriculeError('');
                            }}
                          />
                          <p className="text-[11px] text-secondary mt-1">
                            Votre numéro d'étudiant vous a été remis par l'administration à votre inscription à l'UATM GASA.
                          </p>
                          {studentMatriculeError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {studentMatriculeError}
                            </p>
                          )}
                        </div>

                        {/* Type d'utilisateur coché automatiquement */}
                        <div className="flex flex-col gap-1.5">
                          <span className="text-xs font-semibold text-on-surface-variant font-sans">Type d'utilisateur</span>
                          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200/50 p-3 rounded-lg">
                            <input 
                              type="radio" 
                              id="type_non_diplome" 
                              name="type_profile_non_diplome" 
                              checked 
                              readOnly 
                              className="w-4 h-4 text-primary accent-primary" 
                            />
                            <label htmlFor="type_non_diplome" className="text-xs font-bold text-primary cursor-pointer">
                              Étudiant non diplômé (Consultation / Recherche)
                            </label>
                          </div>
                        </div>

                        <div className="pt-4">
                          <button 
                            disabled={submitting}
                            className="w-full bg-primary text-white py-3 rounded-lg shadow-sm hover:bg-primary/95 transition-all font-semibold flex justify-center items-center gap-2 cursor-pointer active:scale-95 duration-200" 
                            type="submit"
                          >
                            {submitting ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                                Inscription en cours...
                              </>
                            ) : (
                              <>
                                S'inscrire
                                <ArrowRight className="w-4 h-4" />
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* FORMULAIRE 2 — Étudiant diplômé (soumission de mémoire) */}
                    {activeTab === 'diplome' && (
                      <div className="space-y-4 pt-2 border-t border-slate-100 animate-fadeIn">
                        
                        {/* Choix de la filière */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="filiere_diplome">
                            Choix de la filière d'obtention <span className="text-error">*</span>
                          </label>
                          <select 
                            required
                            id="filiere_diplome"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            value={filiere}
                            onChange={(e) => setFiliere(e.target.value)}
                          >
                            <option value="">-- Sélectionnez une filière --</option>
                            {listFilieres.map((fName) => (
                              <option key={fName} value={fName}>{fName}</option>
                            ))}
                          </select>
                        </div>

                        {/* Numéro d'étudiant (matricule) */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="matricule_diplome">
                            Numéro d'étudiant (matricule) <span className="text-error">*</span>
                          </label>
                          <input 
                            required
                            id="matricule_diplome"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            placeholder="Ex: ETU042"
                            type="text"
                            value={gradMatricule}
                            onChange={(e) => {
                              setGradMatricule(e.target.value);
                              setGradMatriculeError('');
                            }}
                          />
                          {gradMatriculeError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {gradMatriculeError}
                            </p>
                          )}
                        </div>

                        {/* Année de diplôme */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="annee_diplome">
                            Année de diplôme <span className="text-error">*</span>
                          </label>
                          <select 
                            required
                            id="annee_diplome"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            value={gradYear}
                            onChange={(e) => {
                              setGradYear(e.target.value);
                              setGradYearError('');
                            }}
                          >
                            <option value="">-- Sélectionnez votre année de diplôme --</option>
                            {listGradYears.map((yr) => (
                              <option key={yr} value={yr}>{yr}</option>
                            ))}
                          </select>
                          {gradYearError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {gradYearError}
                            </p>
                          )}
                        </div>

                        {/* Type d'utilisateur coché automatiquement */}
                        <div className="flex flex-col gap-1.5">
                          <span className="text-xs font-semibold text-on-surface-variant font-sans">Type d'utilisateur</span>
                          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200/50 p-3 rounded-lg">
                            <input 
                              type="radio" 
                              id="type_diplome" 
                              name="type_profile_diplome" 
                              checked 
                              readOnly 
                              className="w-4 h-4 text-primary accent-primary" 
                            />
                            <label htmlFor="type_diplome" className="text-xs font-bold text-primary cursor-pointer">
                              Étudiant diplômé (Soumission officielle active)
                            </label>
                          </div>
                        </div>

                        {/* Title of Thesis */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="thesis_title">
                            Titre exact de votre mémoire <span className="text-error">*</span>
                          </label>
                          <input 
                            required
                            id="thesis_title"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            placeholder="Minimum 10 caractères"
                            type="text"
                            value={thesisTitle}
                            onChange={(e) => {
                              setThesisTitle(e.target.value);
                              setGradThesisTitleError('');
                            }}
                          />
                          {gradThesisTitleError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {gradThesisTitleError}
                            </p>
                          )}
                        </div>

                        {/* Year of Thesis hidden or set to 2026/same as gradYear */}
                        <div className="hidden flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="thesis_year">
                            Année de soutenance <span className="text-error">*</span>
                          </label>
                          <input 
                            required
                            id="thesis_year"
                            type="number"
                            min="1990"
                            max="2026"
                            value={thesisYear || gradYear || "2026"}
                            onChange={(e) => setThesisYear(e.target.value)}
                          />
                        </div>

                        {/* Note visible officielle GASA */}
                        <div className="bg-slate-50 border border-slate-200/50 p-3 rounded-lg text-[11px] text-secondary leading-normal">
                          Seuls les étudiants ayant obtenu leur diplôme à l'UATM GASA peuvent s'inscrire dans cette catégorie. Votre dossier sera vérifié par le Directeur des Études avant validation.
                        </div>

                        {/* Upload du mémoire PDF, max 50Mo */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans">
                            Téléverser le mémoire (Format PDF - Max 50 Mo) <span className="text-error">*</span>
                          </label>
                          
                          <div className="relative border-2 border-dashed border-outline-variant/80 rounded-xl p-6 bg-slate-50/50 hover:bg-slate-50 transition-colors flex flex-col items-center justify-center text-center">
                            <input 
                              type="file" 
                              accept="application/pdf"
                              id="pdf_file_input"
                              onChange={handleFileChange}
                              className="absolute inset-0 opacity-0 cursor-pointer z-10"
                            />
                            <Upload className="w-8 h-8 text-primary/70 mb-2" />
                            <p className="text-xs font-semibold text-slate-700">Glissez-déposez ou cliquez pour parcourir</p>
                            <p className="text-[10px] text-secondary mt-1">Fichiers PDF uniquement autorisés</p>

                            {pdfFileName && (
                              <div className="mt-3 flex items-center gap-1.5 bg-emerald-50 border border-emerald-100 p-2 rounded-lg text-emerald-800 text-[11px] font-medium animate-fadeIn z-20">
                                <FileText className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span className="truncate max-w-[200px]">{pdfFileName}</span>
                              </div>
                            )}

                            {pdfError && (
                              <div className="mt-2.5 text-error text-[10px] font-bold bg-error-container/20 border border-error/10 px-2.5 py-1.5 rounded-md animate-shake">
                                {pdfError}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="pt-4">
                          <button 
                            disabled={submitting}
                            className="w-full bg-primary text-white py-3 rounded-lg shadow-sm hover:bg-primary/95 transition-all font-semibold flex justify-center items-center gap-2 cursor-pointer active:scale-95 duration-200" 
                            type="submit"
                          >
                            {submitting ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                                Traitement et dépôt en cours...
                              </>
                            ) : (
                              <>
                                Soumettre ma demande
                                <ArrowRight className="w-4 h-4" />
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* FORMULAIRE 3 — Maître de mémoire / Professeur */}
                    {activeTab === 'enseignant' && (
                      <div className="space-y-4 pt-2 border-t border-slate-100 animate-fadeIn">
                        
                        {/* Numéro de matricule professeur */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="matricule_professeur">
                            Numéro de matricule professeur <span className="text-error">*</span>
                          </label>
                          <input 
                            required
                            id="matricule_professeur"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            placeholder="Ex: PRO001"
                            type="text"
                            value={teacherMatricule}
                            onChange={(e) => {
                              setTeacherMatricule(e.target.value);
                              setTeacherMatriculeError('');
                            }}
                          />
                          {teacherMatriculeError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {teacherMatriculeError}
                            </p>
                          )}
                        </div>

                        {/* Grade académique */}
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="grade_professeur">
                            Grade académique <span className="text-error">*</span>
                          </label>
                          <select 
                            required
                            id="grade_professeur"
                            className="w-full px-3.5 py-2.5 rounded-lg border border-outline-variant bg-surface focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm"
                            value={teacherGrade}
                            onChange={(e) => {
                              setTeacherGrade(e.target.value);
                              setTeacherGradeError('');
                            }}
                          >
                            <option value="">-- Sélectionnez votre grade --</option>
                            {listGrades.map((g) => (
                              <option key={g} value={g}>{g}</option>
                            ))}
                          </select>
                          {teacherGradeError && (
                            <p className="text-xs text-error font-semibold mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              {teacherGradeError}
                            </p>
                          )}
                        </div>

                        {/* Note visible officielle GASA Enseignant */}
                        <div className="bg-slate-50 border border-slate-200/50 p-3 rounded-lg text-[11px] text-secondary leading-normal">
                          Seuls les enseignants en poste à l'UATM GASA peuvent s'inscrire comme maître de mémoire. Votre matricule sera vérifié par le Directeur des Études.
                        </div>

                        {/* Colonne "Spécialités" avec checkboxes */}
                        <div className="flex flex-col gap-2">
                          <span className="text-xs font-semibold text-on-surface-variant font-sans">
                            Vos Spécialités académiques (Sélectionnez une ou plusieurs) <span className="text-error">*</span>
                          </span>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 bg-slate-50 border border-slate-200/50 p-4 rounded-xl">
                            {listSpecialties.map((spec) => {
                              const isChecked = specialties.includes(spec);
                              return (
                                <div 
                                  key={spec}
                                  onClick={() => handleSpecialtyChange(spec)}
                                  className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer select-none transition-all ${
                                    isChecked 
                                      ? 'bg-white border-primary shadow-xs' 
                                      : 'bg-white/50 border-outline-variant hover:border-slate-300'
                                  }`}
                                >
                                  <input 
                                    type="checkbox" 
                                    id={`spec_${spec}`}
                                    checked={isChecked}
                                    onChange={() => {}} // Géré par le parent div
                                    className="w-4 h-4 text-primary accent-primary rounded cursor-pointer"
                                  />
                                  <label 
                                    htmlFor={`spec_${spec}`} 
                                    className="text-xs font-medium text-slate-700 cursor-pointer w-full"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    {spec}
                                  </label>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        <div className="pt-4">
                          <button 
                            disabled={submitting}
                            className="w-full bg-primary text-white py-3 rounded-lg shadow-sm hover:bg-primary/95 transition-all font-semibold flex justify-center items-center gap-2 cursor-pointer active:scale-95 duration-200" 
                            type="submit"
                          >
                            {submitting ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                                Inscription en cours...
                              </>
                            ) : (
                              <>
                                S'inscrire comme maître de mémoire
                                <ArrowRight className="w-4 h-4" />
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Switch to login option */}
                    <div className="pt-4 border-t border-outline-variant text-center">
                      <p className="text-xs text-secondary">
                        Déjà inscrit ?{' '}
                        <button 
                          onClick={() => onNavigate('login')}
                          type="button"
                          className="text-primary font-bold hover:underline cursor-pointer"
                        >
                          Se connecter
                        </button>
                      </p>
                    </div>

                  </form>
                </>
              )}

            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 w-full bg-surface-container-low py-3 px-6 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-xs text-secondary">
          <p>© 2026 GesMemoires — Portail Universitaire de Recherche</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-primary transition-colors">Confidentialité</a>
            <a href="#" className="hover:text-primary transition-colors">Support Académique</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
