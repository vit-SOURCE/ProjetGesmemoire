import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  const distPath = path.join(__dirname, 'dist');
  const hasDist = fs.existsSync(distPath);

  if (process.env.NODE_ENV === 'production' || hasDist) {
    if (hasDist) {
      console.log('\x1b[32m[GesMemoires] Mode Production : Chargement du dossier "dist"...\x1b[0m');
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    } else {
      console.log('\x1b[31m[GesMemoires] Erreur : Dossier "dist" introuvable. Lancement du serveur en mode Développement...\x1b[0m');
      // Fallback section below
    }
  }

  // Si pas de production ou fallback si dist introuvable
  if (process.env.NODE_ENV !== 'production' && !hasDist) {
    console.log('\x1b[34m[GesMemoires] Mode Développement : Lancement de l\'environnement d\'exécution Vite...\x1b[0m');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log('\x1b[36m──────────────────────────────────────────────────\x1b[0m');
    console.log(`\x1b[1;32m[GesMemoires] Serveur démarré avec succès !\x1b[0m`);
    console.log(`\x1b[34m👉 En local  : http://localhost:${PORT}\x1b[0m`);
    console.log(`\x1b[90m👉 Commande  : run "node index.js" ou "npm run dev" pour démarrer\x1b[0m`);
    console.log('\x1b[36m──────────────────────────────────────────────────\x1b[0m');
  });
}

startServer().catch((err) => {
  console.error('\x1b[31m[GesMemoires] Échec du démarrage du serveur :\x1b[0m', err);
});
