/**
 * GesMemoires - Unified Shared State Machine & UI Helper Utilities
 * Pure ES6 standard client architecture with LocalStorage integration
 */

// 1. Initial database seeding datasets
const INITIAL_USERS = [
  {
    id: 'user-dean',
    firstName: 'Romuald',
    lastName: 'Agbodjan',
    email: 'admin@uatmgasa.bj',
    role: 'dean',
    details: { titleOffice: 'Dir. des Études' }
  },
  {
    id: 'user-teacher',
    firstName: 'Arnaud',
    lastName: 'Houessou',
    email: 'arnaud.houessou@uatmgasa.bj',
    role: 'teacher',
    details: { titleOffice: 'Maître de Conférences' }
  },
  {
    id: 'user-student',
    firstName: 'Koffi',
    lastName: 'Zannou',
    email: 'koffi.zannou@uatmgasa.bj',
    role: 'student',
    details: {
      studentId: '2024-KH882',
      faculty: 'Sciences Appliquées',
      cycle: 'Master II - Recherche',
      status: 'Actif'
    }
  }
];

const INITIAL_THESES = [
  {
    id: 'thesis-ia-edu',
    title: "Analyse des systèmes d'intelligence artificielle dans l'enseignement universitaire au Bénin",
    domain: 'Informatique',
    year: 2023,
    studentId: '2024-KH882',
    studentName: 'Koffi Zannou',
    studentEmail: 'koffi.zannou@uatmgasa.bj',
    status: 'accepted',
    submissionNotes: "Version finale validée par le jury.",
    fileUrl: '#',
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [
      {
        id: 'c1',
        authorName: 'Dr. Brice Soglo',
        authorRole: 'Rapporteur du jury',
        date: "Il y a 3 jours",
        text: "Excellentes corrections apportées à la section méthodologique. L'échantillonnage de l'étude est désormais très clair.",
        position: 'Page 14, Ligne 12'
      }
    ],
    history: [
      { id: 'h1', version: 'Version 2.1', date: '12 Oct. 2023', status: 'accepted', notes: "Dernières corrections" }
    ]
  },
  {
    id: 'thesis-numerique-ens',
    title: "Analyse de l'impact du numérique sur l'enseignement supérieur au Bénin",
    domain: 'Sciences Économiques',
    year: 2023,
    studentId: 'student-amoussou-c',
    studentName: 'Clarisse Amoussou',
    studentEmail: 'clarisse.amoussou@uatmgasa.bj',
    status: 'accepted',
    submissionNotes: "Rapport de soutenance validé avec mention Très Bien.",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Hervé Tokpanou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-grh-pme',
    title: "Contribution à l'étude de la gestion des ressources humaines dans les PME béninoises",
    domain: 'Gestion',
    year: 2022,
    studentId: 'student-dossou',
    studentName: 'Rodrigue Dossou',
    studentEmail: 'rodrigue.dossou@uatmgasa.bj',
    status: 'accepted',
    submissionNotes: "Travail de recherche finalisé et certifié conforme.",
    assignedTeacherName: 'Pr. Fatoumata Alabi',
    comments: [],
    history: []
  },
  {
    id: 'thesis-ged-univ',
    title: "Mise en place d'un système de gestion électronique des documents dans les universités publiques",
    domain: 'Informatique',
    year: 2024,
    studentId: 'student-agbodjan',
    studentName: 'Koffi Agbodjan',
    studentEmail: 'koffi.agbodjan@uatmgasa.bj',
    status: 'accepted',
    submissionNotes: "Mémoire accepté par le comité de lecture et validé pour soutenance.",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Wilfried Lokossou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-ppp-admin',
    title: "Les opportunités et défis du contrat de partenariat public-privé en droit administratif béninois",
    domain: 'Droit',
    year: 2021,
    studentId: 'student-videgla',
    studentName: 'Chancelle Vidégla',
    studentEmail: 'chancelle.videgla@uatmgasa.bj',
    status: 'accepted',
    submissionNotes: "Document final accepté après levée des réserves du jury.",
    assignedTeacherName: 'Dr. Hervé Tokpanou',
    comments: [],
    history: []
  },
  {
    id: 'thesis-chaussees',
    title: "Étude géotechnique et dimensionnement des chaussées face aux inondations récurrentes à Cotonou",
    domain: 'Génie Civil',
    year: 2023,
    studentName: 'Brice Dossou',
    studentEmail: 'brice.dossou@uatmgasa.bj',
    status: 'rejected',
    submissionNotes: "Rejeté pour insuffisance méthodologique et manque de données d'essais en laboratoire.",
    assignedTeacherName: 'Pr. Fatoumata Alabi',
    comments: [
      {
        id: 'c_geo_1',
        authorName: 'Pr. Fatoumata Alabi',
        authorRole: 'Maître de mémoire',
        date: 'Il y a 4 jours',
        text: "Les essais de pénétration et l'analyse granulométrique des sols de Cotonou ne sont pas présentés de manière rigoureuse dans le chapitre 3."
      }
    ],
    history: []
  },
  {
    id: 'thesis-ia-agile',
    title: "Impact de l'IA Générative sur le développement logiciel agile au sein des tech hubs béninois",
    domain: 'Informatique',
    year: 2023,
    studentName: 'Rodrigue Gbaguidi',
    studentEmail: 'rodrigue.gbaguidi@uatmgasa.bj',
    status: 'pending',
    submissionNotes: "Version 2.0 reçue hier.",
    assignedTeacherId: 'user-teacher',
    assignedTeacherName: 'Dr. Arnaud Houessou',
    comments: [],
    history: [
      { id: 'h201', version: 'Version 2.0', date: 'Hier', status: 'pending', notes: "Version 2.5 mise à jour" }
    ]
  }
];

const INITIAL_REGISTRATIONS = [
  { id: 'p-1', firstName: 'Rodrigue', lastName: 'Dansou', email: 'rodrigue.dansou@uatmgasa.bj', role: 'student', date: 'Il y a 2h' },
  { id: 'p-2', firstName: 'Fatoumata', lastName: 'Alabi', email: 'fatoumata.alabi@uatmgasa.bj', role: 'teacher', date: 'Il y a 5h' },
  { id: 'p-3', firstName: 'Gildas', lastName: 'Tokpanou', email: 'gildas.tokpanou@uatmgasa.bj', role: 'student', date: 'Hier' }
];

const INITIAL_LOGS = [
  { id: 'l-1', text: "Le Directeur des Études a validé le mémoire de Koffi Zannou.", date: "Il y a 10 minutes", type: 'success' },
  { id: 'l-2', text: "Nouvelle inscription d'étudiant Rodrigue Dansou.", date: "Il y a 2 heures", type: 'info' }
];

const CHAPTERS_CONTENT = [
  { title: "Résumé / Abstract", text: "Ce travail de recherche analyse l'adoption et l'impact potentiel des systèmes d'intelligence artificielle (IA) au sein de l'écosystème de l'enseignement supérieur au Bénin. À travers une enquête quantitative menée auprès de 320 étudiants et 45 enseignants de l'UATM GASA Formation, nous caractérisons les usages actifs (principalement des outils d'assistance à la rédaction et de programmation), les défis d'accès aux infrastructures de calcul, et la perception éthique de l'IA. Les résultats révèlent une forte appétence des apprenants contrastant avec une absence de cadre réglementaire et institutionnel." },
  { title: "Chapitre 1 : Introduction", text: "La transformation numérique des universités béninoises s'accélère avec l'introduction des technologies cognitives. Ce chapitre définit la problématique, les objectifs de recherche axés sur l'évaluation des compétences méthodologiques acquises à l'UATM GASA, et formule trois hypothèses clés relatives à l'optimisation des parcours d' apprentissage guidés par la recommandation algorithmique de contenus éducatifs." },
  { title: "Chapitre 2 : Cadre Méthodologique", text: "Nous avons adopté une approche méthodologique mixte. Le volet quantitatif s'est basé sur un questionnaire en ligne distribué au département d'informatique et des sciences économiques de l'UATM GASA. Pour le traitement des données quantitatives, nous avons utilisé l'analyse statistique multidimensionnelle via le logiciel SPSS. Le volet qualitatif repose sur des entretiens semi-directifs menés auprès du décanat." },
  { title: "Chapitre 3 : Résultats & discussion", text: "Nos analyses révèlent une adéquation remarquable avec nos hypothèses de recherche de départ. Des recommandations substantielles ont été élaborées pour le décanat de l'UATM GASA. 76% des étudiants interrogés utilisent régulièrement l'IA pour déboguer des prototypes. Le principal blocage réside dans l'accès aux infrastructures de calcul de pointe." },
  { title: "Conclusion Générale", text: "En conclusion, l'établissement d'une feuille de route pour intégrer de façon éthique les intelligences génératives est crucial pour l'avenir de l'UATM GASA Formation. Les perspectives futures ouvrent la voie à des systèmes d'évaluation dynamiques et personnalisés basés sur le mentorat continu." }
];

// 2. Global State Storage managers
let state = {
  users: [...INITIAL_USERS],
  theses: [...INITIAL_THESES],
  registrations: [...INITIAL_REGISTRATIONS],
  logs: [...INITIAL_LOGS]
};

// Seed or load local state immediately
function loadState() {
  const saved = localStorage.getItem('gm_state');
  if (saved) {
    state = JSON.parse(saved);
  } else {
    saveState();
  }
  return state;
}

function saveState() {
  localStorage.setItem('gm_state', JSON.stringify(state));
}

// 3. User session utilities
function getCurrentUser() {
  const user = localStorage.getItem('gm_user');
  return user ? JSON.parse(user) : null;
}

function setCurrentUser(user) {
  if (user) {
    localStorage.setItem('gm_user', JSON.stringify(user));
  } else {
    localStorage.removeItem('gm_user');
  }
}

function logout() {
  setCurrentUser(null);
  showAlert("À bientôt ! Vous avez été déconnecté avec succès de votre portail sécurisé.", "Déconnexion réussie", "success");
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 1000);
}

// Route Guard mechanism
function checkAuth(allowedRoles) {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'login.html';
    return null;
  }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    alert("Accès refusé : vous n'avez pas les habilitations pour visualiser cette interface.");
    window.location.href = 'index.html';
    return null;
  }
  return user;
}

// 4. Lucide icons wrapper
function safeCreateIcons(parentNode = document) {
  if (typeof lucide !== 'undefined') {
    lucide.createIcons({
      node: parentNode
    });
  }
}

// 5. Shared Alert Modal system injections
function showAlert(message, title = "Notification GesMemoires", type = "info") {
  let alertModal = document.getElementById('custom-alert');
  
  // If the popup is missing from the hardcoded HTML, inject it dynamically
  if (!alertModal) {
    const alertDiv = document.createElement('div');
    alertDiv.id = "custom-alert";
    alertDiv.className = "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 hidden backdrop-blur-[2px]";
    alertDiv.innerHTML = `
      <div class="bg-white rounded-2xl shadow-2xl border border-outline-variant max-w-sm w-full overflow-hidden text-left relative transform duration-300 scale-95 opacity-0" id="custom-alert-box">
        <div id="alert-header-bg" class="px-5 py-4 flex items-center gap-3 text-white">
          <i id="alert-icon" data-lucide="info" class="w-5 h-5 shrink-0"></i>
          <h3 id="alert-title" class="font-bold text-xs tracking-wider uppercase">NOTIFICATION</h3>
        </div>
        <div class="p-5 text-sm leading-relaxed text-slate-700 text-center font-medium">
          <p id="alert-message" class="whitespace-pre-line"></p>
        </div>
        <div class="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-center">
          <button onclick="closeAlert()" class="w-full py-2 bg-primary text-white hover:bg-primary-container text-xs font-bold rounded-xl transition-all shadow-sm">Compris</button>
        </div>
      </div>
    `;
    document.body.appendChild(alertDiv);
    alertModal = alertDiv;
  }

  const containerBox = document.getElementById('custom-alert-box');
  const headerBg = document.getElementById('alert-header-bg');
  const iconEl = document.getElementById('alert-icon');
  const titleEl = document.getElementById('alert-title');
  const textEl = document.getElementById('alert-message');

  // Colors config
  if (type === 'success') {
    headerBg.className = "px-5 py-4 flex items-center gap-3 text-white bg-emerald-600";
    iconEl.setAttribute('data-lucide', 'check-circle');
  } else if (type === 'error') {
    headerBg.className = "px-5 py-4 flex items-center gap-3 text-white bg-red-650 bg-red-600";
    iconEl.setAttribute('data-lucide', 'alert-circle');
  } else if (type === 'warning') {
    headerBg.className = "px-5 py-4 flex items-center gap-3 text-white bg-amber-500";
    iconEl.setAttribute('data-lucide', 'alert-triangle');
  } else {
    headerBg.className = "px-5 py-4 flex items-center gap-3 text-white bg-[#031635]";
    iconEl.setAttribute('data-lucide', 'info');
  }

  titleEl.innerText = title.toUpperCase();
  textEl.innerText = message;

  // Animation show
  alertModal.classList.remove('hidden');
  setTimeout(() => {
    containerBox.classList.remove('scale-95', 'opacity-0');
    containerBox.classList.add('scale-100', 'opacity-100');
  }, 10);

  safeCreateIcons(alertModal);
}

function closeAlert() {
  const containerBox = document.getElementById('custom-alert-box');
  const alertModal = document.getElementById('custom-alert');
  if (containerBox && alertModal) {
    containerBox.classList.add('scale-95', 'opacity-0');
    containerBox.classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
      alertModal.classList.add('hidden');
    }, 160);
  }
}

// 6. Dynamic Shared Support Chat overlay injection
function injectSupportChat() {
  const chatBubble = document.createElement('div');
  chatBubble.className = "fixed bottom-6 right-6 z-40";
  chatBubble.innerHTML = `
    <!-- Floating Trigger -->
    <button onclick="toggleSupportChat()" class="w-12 h-12 bg-primary hover:bg-primary-container text-white rounded-full flex items-center justify-center shadow-2xl border border-white/10 relative cursor-pointer group active:scale-95 transition-all">
      <i id="support-icon-normal" data-lucide="help-circle" class="w-6 h-6"></i>
      <i id="support-icon-close" data-lucide="x" class="w-5 h-5 hidden"></i>
      <span class="absolute -top-1 -right-1 flex h-3 w-3">
        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
        <span class="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
      </span>
    </button>
    <!-- Chat Windows -->
    <div id="support-chat-window" class="absolute bottom-16 right-0 w-[330px] bg-white rounded-2xl shadow-2xl border border-outline-variant/60 overflow-hidden transform duration-200 scale-95 opacity-0 hidden">
      <div class="bg-primary text-white p-4 flex items-center gap-2.5">
        <div class="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-extrabold text-[11px] leading-none shrink-0 border border-white/20">A</div>
        <div>
          <h4 class="font-extrabold text-xs tracking-tight">Assistant Académique</h4>
          <p class="text-[9px] text-emerald-400 font-bold flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse"></span> BOT EN LIGNE</p>
        </div>
      </div>
      <div id="support-chat-stream" class="p-4 h-64 overflow-y-auto space-y-3.5 custom-scrollbar bg-slate-50 border-b border-slate-100 flex flex-col text-xs font-medium text-slate-700">
        <div class="flex items-start gap-2 max-w-[85%]">
          <div class="bg-indigo-50/70 border border-indigo-100/50 p-2.5 rounded-2xl rounded-tl-none leading-relaxed text-indigo-950">
            Bonjour ! Je suis votre tuteur d'IA d'assistance méthodologique. Posez-moi vos questions par rapport à la rédaction, au <b>plagiat</b> ou au format du manuscrit.
          </div>
        </div>
      </div>
      <form onsubmit="handleSupportSend(event)" class="p-3 bg-white flex items-center gap-2">
        <input type="text" id="support-chat-input" placeholder="Poser une question..." class="flex-grow text-xs border border-outline-variant rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary">
        <button type="submit" class="p-2 bg-primary hover:bg-primary-container text-white rounded-lg transition-colors cursor-pointer active:scale-95"><i data-lucide="send" class="w-3.5 h-3.5"></i></button>
      </form>
    </div>
  `;
  document.body.appendChild(chatBubble);
}

function toggleSupportChat() {
  const windowChat = document.getElementById('support-chat-window');
  const iconNormal = document.getElementById('support-icon-normal');
  const iconClose = document.getElementById('support-icon-close');
  if (!windowChat) return;

  const isHidden = windowChat.classList.contains('hidden');
  if (isHidden) {
    windowChat.classList.remove('hidden');
    setTimeout(() => {
      windowChat.classList.remove('scale-95', 'opacity-0');
      windowChat.classList.add('scale-100', 'opacity-100');
    }, 10);
    iconNormal.classList.add('hidden');
    iconClose.classList.remove('hidden');
  } else {
    windowChat.classList.add('scale-95', 'opacity-0');
    windowChat.classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
      windowChat.classList.add('hidden');
    }, 300);
    iconNormal.classList.remove('hidden');
    iconClose.classList.add('hidden');
  }
}

function handleSupportSend(e) {
  e.preventDefault();
  const input = document.getElementById('support-chat-input');
  const stream = document.getElementById('support-chat-stream');
  if (!input || !stream) return;
  const text = input.value.trim();
  if (!text) return;

  // User message Bubble
  const userBubble = document.createElement('div');
  userBubble.className = "flex items-start gap-2 max-w-[85%] ml-auto justify-end";
  userBubble.innerHTML = `
    <div class="bg-primary text-white p-2.5 rounded-2xl rounded-tr-none leading-relaxed text-right font-medium">
      ${text}
    </div>
  `;
  stream.appendChild(userBubble);
  input.value = '';

  // Scroll to bottom
  stream.scrollTop = stream.scrollHeight;

  // Reply delay
  setTimeout(() => {
    const replyText = getTutorResponse(text);
    const botBubble = document.createElement('div');
    botBubble.className = "flex items-start gap-2 max-w-[85%]";
    botBubble.innerHTML = `
      <div class="bg-slate-100 text-slate-800 p-2.5 rounded-2xl rounded-tl-none leading-relaxed">
        ${replyText}
      </div>
    `;
    stream.appendChild(botBubble);
    stream.scrollTop = stream.scrollHeight;
  }, 700);
}

function getTutorResponse(q) {
  const low = q.toLowerCase();
  if (low.includes('plagiat')) {
    return "Le seuil de tolérance anti-plagiat légal requis à l'UATM GASA Formation est fixé à un maximum de 10% d'éléments similaires.";
  }
  if (low.includes('format') || low.includes('pdf')) {
    return "Tous les manuscrits finis de Master ou Licence doivent être encapsulés impérativement au format PDF.";
  }
  if (low.includes('directeur') || low.includes('tuteur') || low.includes('maître') || low.includes('maitre')) {
    return "Pour qu'un maître de mémoire vous suive officiellement, le décanat doit approuver l'affectation via le terminal de validation générale.";
  }
  return "Cette question est enregistrée. Pour une assistance méthodologique approfondie, nous vous conseillons d'interroger directement votre maître de mémoire.";
}

// 7. Common Navigation Sync (Updates Navbar on load)
function syncHeaderNavbar() {
  const navDesktop = document.getElementById('nav-desktop');
  const navUserProfile = document.getElementById('nav-user-profile');
  const navUserText = document.getElementById('nav-user-text');
  const currentUser = getCurrentUser();

  if (currentUser) {
    if (navDesktop) navDesktop.classList.add('hidden');
    if (navUserProfile) {
      navUserProfile.classList.remove('hidden');
      navUserProfile.classList.add('flex');
    }
    if (navUserText) {
      let roleFr = 'Étudiant';
      if (currentUser.role === 'dean') roleFr = 'DE';
      if (currentUser.role === 'teacher') roleFr = 'Maître';
      navUserText.innerText = `${currentUser.firstName} ${currentUser.lastName} (${roleFr})`;
    }
    
    // Inject active dashboard shortcut in desktop header if accessible
    let linkContainer = document.getElementById('header-nav-shortcuts');
    if (!linkContainer && navUserProfile) {
      linkContainer = document.createElement('div');
      linkContainer.id = "header-nav-shortcuts";
      linkContainer.className = "items-center gap-4 mr-4 hidden md:flex text-slate-600 font-semibold text-xs";
      
      let dashboardPage = 'student-dashboard.html';
      if (currentUser.role === 'dean') dashboardPage = 'dean-dashboard.html';
      if (currentUser.role === 'teacher') dashboardPage = 'teacher-dashboard.html';

      linkContainer.innerHTML = `
        <a href="index.html" class="hover:text-primary transition-colors">Catalogue</a>
        <a href="${dashboardPage}" class="text-primary font-bold hover:opacity-80 transition-colors">Mon Espace de Travail</a>
      `;
      navUserProfile.parentNode.insertBefore(linkContainer, navUserProfile);
    }
  } else {
    if (navDesktop) {
      navDesktop.classList.remove('hidden');
      navDesktop.classList.add('flex');
    }
    if (navUserProfile) navUserProfile.classList.add('hidden');
  }
}

// Global initialization
let readerFontSize = 15;
let activeChapterIndex = 0;

function openReader(thesisId) {
  const th = state.theses.find(t => t.id === thesisId);
  if (!th) return;

  let modal = document.getElementById('view-reader-modal');
  if (!modal) {
    const modalDiv = document.createElement('div');
    modalDiv.id = "view-reader-modal";
    modalDiv.className = "fixed inset-0 z-50 bg-slate-900/90 hidden backdrop-blur-md flex items-center justify-center p-4";
    modalDiv.innerHTML = `
      <div class="bg-white w-full max-w-6xl h-[88vh] rounded-3xl shadow-2xl border border-slate-700 overflow-hidden flex flex-col transform duration-300 scale-95 opacity-0" id="reader-modal-box">
        <!-- Top stamp header -->
        <div class="bg-primary text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full bg-white/10 text-emerald-400 flex items-center justify-center font-bold font-mono">C</div>
            <div>
              <h3 id="reader-memoir-title" class="text-xs font-bold leading-none truncate max-w-lg"></h3>
              <p id="reader-memoir-meta" class="text-[9px] text-slate-300 font-medium tracking-wide mt-1"></p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <button onclick="downloadReportPDF()" class="bg-white/10 text-emerald-400 text-[10px] px-3 py-1.5 rounded-lg hover:bg-white/20 font-bold transition-all flex items-center gap-1.5 shrink-0"><i data-lucide="download-cloud" class="w-3.5 h-3.5"></i> Télécharger le PDF Certifié</button>
            <button onclick="scaleReportFont(true)" class="p-1.5 bg-white/5 text-white/80 rounded hover:bg-white/10 text-xs font-semibold select-none">A+</button>
            <button onclick="scaleReportFont(false)" class="p-1.5 bg-white/5 text-white/80 rounded hover:bg-white/10 text-xs font-semibold select-none">A-</button>
            <button onclick="closeReader()" class="p-1.5 bg-white/5 text-white hover:bg-white/10 hover:text-red-400 rounded transition-all shrink-0"><i data-lucide="x" class="w-4 h-4"></i></button>
          </div>
        </div>

        <!-- Split body panes -->
        <div class="flex-grow flex flex-col md:flex-row overflow-hidden min-h-0">
          <!-- Sidebar Navigation Index pane -->
          <div class="w-full md:w-64 bg-slate-50 border-r border-slate-150 flex flex-col shrink-0">
            <p class="text-[10px] font-extrabold uppercase text-secondary tracking-widest px-4 py-3 bg-slate-100 border-b">Table des Matières</p>
            <div class="flex-grow overflow-y-auto divide-y divide-slate-100 custom-scrollbar" id="reader-chapters-toc">
            </div>
            <!-- Watermark widget -->
            <div class="p-4 bg-emerald-50 border-t border-emerald-100 text-[10px] text-emerald-700 leading-normal space-y-1 select-none">
              <p class="font-bold uppercase tracking-wider flex items-center gap-1"><i data-lucide="check-check" class="w-3.5 h-3.5 text-emerald-600"></i> Archive Authentique Béninoise</p>
              <p>Ce manuscrit est protégé par le Décret Cadre d'excellence de l'UATM GASA Formation.</p>
            </div>
          </div>

          <!-- Document Content Reading pane -->
          <div class="flex-grow overflow-y-auto p-6 bg-slate-50 flex justify-center custom-scrollbar" id="reader-text-pane">
            <div class="bg-white max-w-2xl w-full p-8 md:p-12 shadow-md rounded-2xl border border-slate-150 font-serif leading-8 text-[#212121]" style="font-size: 15px;" id="reader-document-text">
            </div>
          </div>

          <!-- Review report sidebar pane -->
          <div class="w-full md:w-80 border-l border-slate-150 bg-white flex flex-col shrink-0">
            <p class="text-[10px] font-extrabold uppercase text-secondary tracking-widest px-4 py-3 bg-slate-100 border-b">Évaluation Anti-Plagiat</p>
            <div class="p-6 space-y-6 flex-grow overflow-y-auto custom-scrollbar">
              <!-- Metric meter circle -->
              <div class="text-center space-y-2">
                <div class="inline-flex relative items-center justify-center p-3 bg-slate-50 rounded-full border border-slate-100 shadow-sm animate-pulse">
                  <span class="text-2xl font-black text-emerald-600">99.7%</span>
                </div>
                <h4 class="text-xs font-extrabold text-primary uppercase">Originalité Certifiée</h4>
                <p class="text-[10px] text-secondary leading-normal">L'algorithme de contrôle académique n'a détecté aucune similarité constitutive d'infraction au plagiat dans cette production de recherche.</p>
              </div>
              
              <div class="space-y-4">
                <h4 class="text-[10px] font-bold text-primary uppercase tracking-widest border-b pb-1">Signature Numérique</h4>
                <div class="text-[10px] font-mono text-secondary space-y-1 py-1">
                  <p>Hash: SHA256-GASA-2026-X882</p>
                  <p>Date: Certifié conforme</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modalDiv);
    modal = modalDiv;
  }

  const modalBox = document.getElementById('reader-modal-box');

  // Populate meta
  document.getElementById('reader-memoir-title').innerText = th.title;
  document.getElementById('reader-memoir-meta').innerText = `Étudiant : ${th.studentName} • Encadrant : ${th.assignedTeacherName || 'N/A'} • Promotion GASA ${th.year}`;

  // Populate navigation Chapters TOC
  const toc = document.getElementById('reader-chapters-toc');
  toc.innerHTML = '';
  CHAPTERS_CONTENT.forEach((ch, idx) => {
    const button = document.createElement('button');
    button.className = "w-full text-left px-4 py-3 text-xs font-semibold uppercase leading-tight hover:bg-slate-100 " + (idx === 0 ? "text-primary border-l-4 border-primary bg-indigo-50/50" : "text-secondary border-l-4 border-transparent");
    button.onclick = (e) => selectReaderChapter(idx, e.currentTarget);
    button.innerText = ch.title;
    toc.appendChild(button);
  });

  // Set initial text
  activeChapterIndex = 0;
  document.getElementById('reader-document-text').innerText = CHAPTERS_CONTENT[0].text;

  modal.classList.remove('hidden');
  setTimeout(() => {
    modalBox.classList.remove('scale-95', 'opacity-0');
    modalBox.classList.add('scale-100', 'opacity-100');
  }, 10);

  safeCreateIcons(modal);
}

function selectReaderChapter(idx, buttonElement) {
  activeChapterIndex = idx;
  
  // Update text
  document.getElementById('reader-document-text').innerText = CHAPTERS_CONTENT[idx].text;

  // Reset border active indicator
  const toc = document.getElementById('reader-chapters-toc');
  toc.querySelectorAll('button').forEach(btn => {
    btn.className = "w-full text-left px-4 py-3 text-xs font-semibold uppercase leading-tight hover:bg-slate-100 text-secondary border-l-4 border-transparent";
  });

  buttonElement.className = "w-full text-left px-4 py-3 text-xs font-semibold uppercase leading-tight bg-indigo-50/50 text-primary border-l-4 border-primary";
}

function scaleReportFont(increase) {
  if (increase && readerFontSize < 25) {
    readerFontSize += 1.5;
  } else if (!increase && readerFontSize > 11) {
    readerFontSize -= 1.5;
  }
  document.getElementById('reader-document-text').style.fontSize = readerFontSize + 'px';
}

function closeReader() {
  const modal = document.getElementById('view-reader-modal');
  const modalBox = document.getElementById('reader-modal-box');
  if (modal && modalBox) {
    modalBox.classList.add('scale-95', 'opacity-0');
    modalBox.classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
      modal.classList.add('hidden');
    }, 200);
  }
}

function downloadReportPDF() {
  showAlert("Préparation et compilation de votre document au format PDF certifié en cours. Le téléchargement débutera sous peu.", "Téléchargement initié", "success");
  
  // Simulate download timing
  setTimeout(() => {
    const link = document.createElement('a');
    link.href = "data:application/pdf;base64,JVBERi0xLjQKJSDi48U="; // Minimal valid base64 PDF representation
    link.download = `Memoire_Certifie_UATM_GASA.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, 1500);
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
  loadState();
  injectSupportChat();
  syncHeaderNavbar();
  safeCreateIcons();
});
