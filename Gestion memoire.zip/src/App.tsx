import React, { useState, useEffect } from 'react';
import { User, Thesis, PendingRegistration, ActivityLog, UserRole, HistoryEntry } from './types';
import { AppApiService } from './services/api';
import { Loader2, Database } from 'lucide-react';

// Component imports
import LandingPage from './components/LandingPage';
import Login from './components/Login';
import RegisterStep1 from './components/RegisterStep1';
import RegisterStep2 from './components/RegisterStep2';
import StudentDashboard from './components/StudentDashboard';
import SubmitForm from './components/SubmitForm';
import TrackingView from './components/TrackingView';
import TeacherDashboard from './components/TeacherDashboard';
import DeanDashboard from './components/DeanDashboard';
import MemoirReader from './components/MemoirReader';

export default function App() {
  const [state, setState] = useState<{
    users: User[];
    theses: Thesis[];
    registrations: PendingRegistration[];
    logs: ActivityLog[];
  }>({
    users: [],
    theses: [],
    registrations: [],
    logs: []
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isApiLoading, setIsApiLoading] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<string>('landing');
  const [registerStep, setRegisterStep] = useState<1 | 2>(1);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [tempRegisterData, setTempRegisterData] = useState<any>(null);
  const [selectedThesis, setSelectedThesis] = useState<Thesis | null>(null);
  const [readingThesis, setReadingThesis] = useState<Thesis | null>(null);

  const [customAlert, setCustomAlert] = useState<{
    isOpen: boolean;
    message: string;
    title: string;
    type: 'success' | 'error' | 'warning' | 'info';
  }>({
    isOpen: false,
    message: '',
    title: '',
    type: 'info'
  });

  // Remplacer window.alert par un magnifique modal au milieu de l'écran
  useEffect(() => {
    window.alert = (message: string) => {
      let title = "Notification GesMemoires";
      let type: 'success' | 'error' | 'warning' | 'info' = 'info';

      const msgLower = message.toLowerCase();
      if (
        msgLower.includes('réussie') ||
        msgLower.includes('succès') ||
        msgLower.includes('félicitations') ||
        msgLower.includes('confirmée') ||
        msgLower.includes('enregistré') ||
        msgLower.includes('validé') ||
        msgLower.includes('approuvé') ||
        msgLower.includes('bienvenue')
      ) {
        type = 'success';
        title = "Succès - Action Validée";
      } else if (
        msgLower.includes('erreur') ||
        msgLower.includes('invalide') ||
        msgLower.includes('incorrect') ||
        msgLower.includes('requis') ||
        msgLower.includes('impossible') ||
        msgLower.includes('échoué') ||
        msgLower.includes('veuillez') ||
        msgLower.includes('devez') ||
        msgLower.includes('doit')
      ) {
        type = 'error';
        title = "Information requise / Erreur";
      } else if (
        msgLower.includes('attention') ||
        msgLower.includes('rejeté') ||
        msgLower.includes('rejet') ||
        msgLower.includes('refus') ||
        msgLower.includes('plagiat')
      ) {
        type = 'warning';
        title = "Avertissement Académique";
      }

      setCustomAlert({
        isOpen: true,
        message,
        title,
        type
      });
    };
  }, []);

  // Charger les données de l'API lors du montage
  useEffect(() => {
    let active = true;
    const fetchInitialData = async () => {
      try {
        const data = await AppApiService.getInitialState();
        if (active) {
          setState(data);
        }
      } catch (err) {
        console.error("Erreur d'initialisation API :", err);
      } finally {
        if (active) {
          setIsLoading(false);
        }
      }
    };
    fetchInitialData();
    return () => {
      active = false;
    };
  }, []);

  // Synchroniser l'état local lors du changement de vue (après une inscription)
  useEffect(() => {
    let active = true;
    const syncState = async () => {
      try {
        const data = await AppApiService.getInitialState();
        if (active) {
          setState(data);
        }
      } catch (err) {
        console.error("Erreur de synchronisation :", err);
      }
    };
    if (currentView === 'login' || currentView === 'dean-dashboard' || currentView === 'student-dashboard') {
      syncState();
    }
    return () => {
      active = false;
    };
  }, [currentView]);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'dean') {
      setCurrentView('dean-dashboard');
    } else if (user.role === 'teacher') {
      setCurrentView('teacher-dashboard');
    } else {
      setCurrentView('student-dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setSelectedThesis(null);
    setCurrentView('landing');
  };

  // Register Step 1
  const handleRegister1 = (data: any) => {
    setTempRegisterData(data);
    setRegisterStep(2);
    setCurrentView('register-step2');
  };

  // Register Step 2
  const handleRegister2 = async (role: UserRole) => {
    setIsApiLoading(true);
    try {
      const { user } = await AppApiService.registerUser({
        firstName: tempRegisterData?.firstName || 'Koffi',
        lastName: tempRegisterData?.lastName || 'Zannou',
        email: tempRegisterData?.email || 'koffi.zannou@uatmgasa.bj',
        role: role
      });

      // Recalculate local state through the API layer
      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);
      
      if (role === 'teacher' || role === 'dean') {
        alert(`Votre demande d'inscription pour le rôle de Maître de mémoire a été transmise au Directeur des Études pour validation.`);
        setCurrentView('login');
      } else {
        alert(`Inscription réussie! Bienvenue sur GesMemoires.`);
        handleLoginSuccess(user);
      }
    } catch (err: any) {
      alert(err.message || "Une erreur est survenue lors de l'inscription.");
    } finally {
      setIsApiLoading(false);
      setRegisterStep(1);
      setTempRegisterData(null);
    }
  };

  // Student thesis submission
  const handleThesisSubmit = async (newSubmission: { title: string; domain: string; year: number; fileName: string }) => {
    const studentUser = currentUser || state.users[2]; // Fallback to demo user if null
    
    setIsApiLoading(true);
    try {
      await AppApiService.submitThesis({
        title: newSubmission.title,
        domain: newSubmission.domain,
        year: newSubmission.year,
        fileName: newSubmission.fileName,
        student: studentUser
      });

      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);

      alert("Félicitations ! Votre mémoire a été soumis et est en attente d'évaluation.");
      setCurrentView('student-dashboard');
    } catch (err: any) {
      alert(err.message || "Erreur lors du dépôt du mémoire.");
    } finally {
      setIsApiLoading(false);
    }
  };

  // Thesis re-submission from feedback sheet
  const handleResubmit = async (notes: string, fileName: string) => {
    if (!selectedThesis) return;

    const studentUser = currentUser || state.users[2];
    setIsApiLoading(true);

    try {
      const { updatedThesis } = await AppApiService.resubmitThesis({
        thesisId: selectedThesis.id,
        notes: notes,
        fileName: fileName,
        student: studentUser
      });

      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);
      setSelectedThesis(updatedThesis); // Update local active detail preview

      alert("Votre révision a été transmise avec succès.");
    } catch (err: any) {
      alert(err.message || "Erreur de transmission de la correction.");
    } finally {
      setIsApiLoading(false);
    }
  };

  // Director approves registration requests
  const handleApproveRegistration = async (id: string) => {
    const reg = state.registrations.find(r => r.id === id);
    if (!reg) return;

    setIsApiLoading(true);
    try {
      await AppApiService.approveRegistration(id, { firstName: reg.firstName, lastName: reg.lastName });
      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);
    } catch (err: any) {
      alert(err.message || "Erreur lors de la validation.");
    } finally {
      setIsApiLoading(false);
    }
  };

  const handleRejectRegistration = async (id: string) => {
    const reg = state.registrations.find(r => r.id === id);
    if (!reg) return;

    setIsApiLoading(true);
    try {
      await AppApiService.rejectRegistration(id, { firstName: reg.firstName, lastName: reg.lastName });
      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);
    } catch (err: any) {
      alert(err.message || "Erreur lors du refus.");
    } finally {
      setIsApiLoading(false);
    }
  };

  // Fast assignments of students to supervisors
  const handleAssignTeacher = async (studentName: string, teacherName: string) => {
    setIsApiLoading(true);
    try {
      await AppApiService.assignSupervisor(studentName, teacherName);
      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);
    } catch (err: any) {
      alert(err.message || "Erreur lors de l'affectation.");
    } finally {
      setIsApiLoading(false);
    }
  };

  // Update thesis status / comments from the supervisor board
  const handleUpdateThesis = async (id: string, updatedParams: Partial<Thesis>) => {
    setIsApiLoading(true);
    try {
      const updated = await AppApiService.updateThesis(id, updatedParams);
      const updatedState = await AppApiService.getInitialState();
      setState(updatedState);

      if (selectedThesis && selectedThesis.id === id) {
        setSelectedThesis(updated);
      }
    } catch (err: any) {
      alert(err.message || "Erreur d'enregistrement.");
    } finally {
      setIsApiLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-slate-800">
        <div className="bg-white px-8 py-10 rounded-2xl shadow-xl max-w-sm w-full text-center border border-slate-100 flex flex-col items-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
          <h2 className="text-xl font-bold mb-1 font-sans">Initialisation de GesMemoires</h2>
          <p className="text-sm text-slate-500 mb-6">Connexion sécurisée aux services de l'Université...</p>
          <div className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-lg border border-slate-100 text-xs text-slate-600">
            <Database className="w-4 h-4 text-emerald-500 animate-pulse" />
            <span>Chargement asynchrone prêt</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="font-sans antialiased min-h-screen text-on-surface bg-surface">
      
      {/* Network / API Call Overlay */}
      {isApiLoading && (
        <div className="fixed inset-0 z-[100] bg-black/30 backdrop-blur-xs flex items-center justify-center pointer-events-auto">
          <div className="bg-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-4 border border-outline-variant">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
            <span className="text-sm font-semibold text-primary">Synchronisation avec l'API...</span>
          </div>
        </div>
      )}



      


      {/* Main Views Router */}
      {currentView === 'landing' && (
        <LandingPage 
          onNavigate={setCurrentView} 
          theses={state.theses} 
          onReadThesis={setReadingThesis}
        />
      )}

      {currentView === 'login' && (
        <Login 
          onNavigate={setCurrentView} 
          allUsers={state.users} 
          onLoginSuccess={handleLoginSuccess}
        />
      )}

      {currentView === 'register' && registerStep === 1 && (
        <RegisterStep1 
          onNext={handleRegister1} 
          onNavigate={setCurrentView} 
        />
      )}

      {currentView === 'register-step2' && (
        <RegisterStep2 
          onBack={() => {
            setCurrentView('register');
            setRegisterStep(1);
          }} 
          onSubmit={handleRegister2} 
        />
      )}

      {currentView === 'student-dashboard' && currentUser && (
        <StudentDashboard 
          currentUser={currentUser} 
          theses={state.theses} 
          onNavigate={setCurrentView} 
          onSelectThesis={(thesis) => {
            setSelectedThesis(thesis);
            setCurrentView('tracking-memoir');
          }} 
          onReadThesis={setReadingThesis}
          onLogout={handleLogout}
        />
      )}

      {currentView === 'submit-memoir' && (
        <SubmitForm 
          onBack={() => setCurrentView('student-dashboard')} 
          onSubmitSuccess={handleThesisSubmit} 
        />
      )}

      {currentView === 'tracking-memoir' && selectedThesis && (
        <TrackingView 
          thesis={selectedThesis} 
          onBack={() => setCurrentView('student-dashboard')} 
          onResubmit={handleResubmit} 
          onReadThesis={setReadingThesis}
        />
      )}

      {currentView === 'teacher-dashboard' && currentUser && (
        <TeacherDashboard 
          currentUser={currentUser} 
          theses={state.theses} 
          onNavigate={setCurrentView} 
          onUpdateThesis={handleUpdateThesis} 
          onReadThesis={setReadingThesis}
          onLogout={handleLogout}
        />
      )}

      {currentView === 'dean-dashboard' && currentUser && (
        <DeanDashboard 
          currentUser={currentUser} 
          theses={state.theses} 
          registrations={state.registrations} 
          logs={state.logs}
          onApproveRegistration={handleApproveRegistration} 
          onRejectRegistration={handleRejectRegistration} 
          onAssignTeacher={handleAssignTeacher} 
          onNavigate={setCurrentView} 
          onReadThesis={setReadingThesis}
          onLogout={handleLogout}
          allUsers={state.users}
          onUpdateThesis={handleUpdateThesis}
        />
      )}

      {readingThesis && (
        <MemoirReader 
          thesis={readingThesis} 
          onClose={() => setReadingThesis(null)} 
        />
      )}

      {/* Pop-up de notification au milieu de l'écran avec design corporatif GASA */}
      {customAlert.isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-[2px] animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl border border-outline-variant/65 max-w-sm w-full overflow-hidden animate-scale-up text-left">
            {/* Colonne de couleur supérieure selon le type de message */}
            <div className={`px-5 py-4 flex items-center gap-3 text-white ${
              customAlert.type === 'success' ? 'bg-emerald-600' :
              customAlert.type === 'error' ? 'bg-red-650 lg:bg-rose-750 bg-red-600' :
              customAlert.type === 'warning' ? 'bg-amber-500' : 'bg-primary'
            }`}>
              {customAlert.type === 'success' && (
                <div className="p-1.5 bg-white/20 rounded-full shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
              {customAlert.type === 'error' && (
                <div className="p-1.5 bg-white/20 rounded-full shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>
              )}
              {customAlert.type === 'warning' && (
                <div className="p-1.5 bg-white/20 rounded-full shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>
              )}
              {customAlert.type === 'info' && (
                <div className="p-1.5 bg-white/20 rounded-full shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              )}
              <h3 className="font-bold text-xs tracking-wider uppercase font-sans">{customAlert.title}</h3>
            </div>

            {/* Contenu textuel */}
            <div className="p-5 text-sm leading-relaxed text-slate-700 font-sans text-center">
              <p className="whitespace-pre-line font-medium">{customAlert.message}</p>
            </div>

            {/* Bouton de confirmation en bas */}
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-center">
              <button
                onClick={() => setCustomAlert({ ...customAlert, isOpen: false })}
                className="w-full py-2 bg-primary text-white hover:bg-primary-container text-xs font-bold rounded-xl transition-all shadow-sm active:scale-95 cursor-pointer uppercase tracking-wider font-sans text-center"
              >
                Compris
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
