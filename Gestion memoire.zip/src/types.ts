export type UserRole = 'student' | 'student-grad' | 'teacher' | 'dean';

export interface UserDetails {
  studentId?: string;
  faculty?: string;
  cycle?: string;
  status?: string;
  titleOffice?: string;
  avatarUrl?: string;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
  details?: UserDetails;
}

export interface Comment {
  id: string;
  authorName: string;
  authorRole: string;
  date: string;
  text: string;
  position?: string;
}

export interface HistoryEntry {
  id: string;
  version: string;
  date: string;
  status: 'pending' | 'accepted' | 'rejected' | 'draft';
  title: string;
  submittedBy: string;
  notes?: string;
}

export interface Thesis {
  id: string;
  title: string;
  domain: string;
  year: number;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentAvatar?: string;
  status: 'pending' | 'accepted' | 'rejected' | 'draft';
  comments: Comment[];
  history: HistoryEntry[];
  fileUrl?: string;
  submissionNotes?: string;
  assignedTeacherId?: string;
  assignedTeacherName?: string;
}

export interface PendingRegistration {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
  date: string;
}

export interface ActivityLog {
  id: string;
  text: string;
  date: string;
  type: 'info' | 'success' | 'warning';
}
