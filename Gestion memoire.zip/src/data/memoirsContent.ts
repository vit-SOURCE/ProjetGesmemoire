export interface MemoirSection {
  title: string;
  content: string[];
}

export interface MemoirFullText {
  id: string;
  title: string;
  author: string;
  supervisor: string;
  institution: string;
  faculty: string;
  year: number;
  sections: MemoirSection[];
}

export const MEMOIRS_CONTENT: Record<string, MemoirFullText> = {
  'thesis-ia-edu': {
    id: 'thesis-ia-edu',
    title: "Analyse des systèmes d'intelligence artificielle dans l'enseignement universitaire au Bénin",
    author: "Koffi Zannou",
    supervisor: "Dr. Arnaud Houessou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Faculté des Sciences et Techniques (FAST)",
    year: 2023,
    sections: [
      {
        title: "Dédicaces & Remerciements",
        content: [
          "À mes parents, qui ont consenti d'immenses sacrifices pour guider mes premiers pas vers le savoir. Votre soutien indéfectible et vos prières ont été mon pilier tout au long de ce parcours universitaire.",
          "À mon superviseur de mémoire, Dr. Arnaud Houessou, pour sa rigueur scientifique, sa bienveillance et ses précieux conseils. Il a su orienter mes recherches vers des problématiques d'actualité avec une patience pédagogique exemplaire.",
          "Aux enseignants du département d'Informatique pour la qualité de la formation reçue, ainsi qu'aux étudiants et doyens qui ont accepté de répondre à notre questionnaire."
        ]
      },
      {
        title: "Résumé / Abstract",
        content: [
          "Résumé : Ce travail de recherche analyse l'adoption et l'impact potentiel des systèmes d'intelligence artificielle (IA) au sein de l'écosystème de l'enseignement supérieur au Bénin. À travers une enquête quantitative menée auprès de 320 étudiants et 45 enseignants de l'UATM GASA Formation, nous caractérisons les usages actuels (principalement des outils d'assistance à la rédaction et de programmation), les défis d'accès aux infrastructures de calcul, et la perception éthique de l'IA. Les résultats révèlent une forte appétence des apprenants contrastant avec une absence de cadre réglementaire et institutionnel.",
          "Abstract: This research analyzes the adoption and potential impact of artificial intelligence (AI) systems within Benin's higher education ecosystem. Through a quantitative survey of 320 students and 45 lecturers at UATM GASA Formation, we characterize current usages (mainly writing and programming assistance tools), computational infrastructure access challenges, and ethical perceptions of AI. Results show highly eager learners contrasting with a complete absence of institutional and regulatory frameworks."
        ]
      },
      {
        title: "Introduction Générale",
        content: [
          "L'enseignement supérieur mondial traverse une révolution pédagogique accélérée par l'avènement des technologies d'intelligence artificielle générative. En Afrique subsaharienne, et particulièrement au Bénin, cette transition s'inscrit dans un contexte de massification des effectifs étudiants et de ressources d'encadrement limitées.",
          "La problématique de notre étude s'articule autour de la question suivante : Comment intégrer l'intelligence artificielle de manière éthique, équitable et efficace pour améliorer les apprentissages universitaires au Bénin sans accentuer la fracture numérique ?"
        ]
      },
      {
        title: "Chapitre 1 : Revue de Littérature",
        content: [
          "L'IA en éducation (AIED) fait l'objet d'intenses débats. Selon Roll et Wylie (2016), l'IA peut agir comme un tuteur intelligent, fournissant un retour personnalisé en temps réel. Copeland et al. (2021) soulignent néanmoins que ces modèles de traitement de langage naturel reproduisent souvent des biais cognitifs et géoculturels occidentaux.",
          "Dans le contexte béninois, des chercheurs comme Tossou (2019) ont identifié que l'intégration du numérique fait face à deux obstacles majeurs : l'instabilité de la connexion internet haut débit et la faible pénétration des plateformes de gestion des apprentissages (LMS)."
        ]
      },
      {
        title: "Chapitre 2 : Cadre Méthodologique",
        content: [
          "Nous avons adopté une approche méthodologique mixte. Le volet quantitatif s'est basé sur un questionnaire en ligne distribué au département d'informatique et des sciences économiques de l'UATM GASA.",
          "Pour le traitement des données quantitatives, nous avons utilisé l'analyse statistique multidimensionnelle via le logiciel SPSS. Le volet qualitatif repose sur des entretiens semi-directifs menés auprès du décanat et de membres du rectorat pour explorer les perspectives d'adaptation des curricula."
        ]
      },
      {
        title: "Chapitre 3 : Résultats et Discussion",
        content: [
          "Nos analyses montrent que 76 % des étudiants interrogés utilisent régulièrement (au moins une fois par semaine) des outils d'IA (ex: ChatGPT, Claude) pour expliquer des théories complexes ou déboguer du code. Cependant, seuls 15 % des enseignants intègrent explicitement l'IA dans leur démarche d'évaluation.",
          "Figure 1.1 : Répartition des outils d'IA préférés par les étudiants de l'UATM GASA.",
          "Le défi principal évoqué par les enseignants est la crainte du plagiat automatisé et de la perte d'esprit critique chez les étudiants, suggérant la nécessité d'une refonte des modalités d'évaluation vers des examens oraux et des projets pratiques de terrain."
        ]
      },
      {
        title: "Conclusion & Perspectives",
        content: [
          "L'IA est déjà ancrée dans le quotidien académique béninois. L'interdire s'avère vain et contre-productif. Nous préconisons la création d'une charte universitaire nationale sur l'usage de l'IA, la formation continue des enseignants et le déploiement de serveurs locaux pour héberger des modèles d'IA souverains, adaptés aux langues d'Afrique de l'Ouest.",
          "Ce travail de recherche pose les premiers jalons d'un processus inéluctable de transformation numérique inclusive de nos universités."
        ]
      },
      {
        title: "Références Bibliographiques",
        content: [
          "[1] Roll, I., & Wylie, R. (2016). Evolution and revolution in artificial intelligence in education. International Journal of Artificial Intelligence in Education, 26, 582-599.",
          "[2] Tossou, S. F. (2019). Éducation et technologies au Bénin : défis de la fracture numérique. Revue Africaine de Pédagogie, 14(2), 112-128.",
          "[3] UNESCO (2021). Draft Recommendation on the Ethics of Artificial Intelligence. Paris: UNESCO."
        ]
      }
    ]
  },
  'thesis-numerique-ens': {
    id: 'thesis-numerique-ens',
    title: "Analyse de l'impact du numérique sur l'enseignement supérieur au Bénin",
    author: "Clarisse Amoussou",
    supervisor: "Dr. Hervé Tokpanou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Faculté des Sciences Économiques et de Gestion (FASEG)",
    year: 2023,
    sections: [
      {
        title: "Dédicaces & Remerciements",
        content: [
          "À ma famille, qui a toujours cru en moi.",
          "À mon directeur de recherche, Dr. Hervé Tokpanou, pour sa disponibilité, sa rigueur scientifique et ses encouragements."
        ]
      },
      {
        title: "Résumé / Abstract",
        content: [
          "Ce mémoire analyse la corrélation entre l'indice de connectivité des infrastructures académiques et le taux d'assimilation des cours par les étudiants en sciences de gestion.",
          "This dissertation analyzes the correlation between academic connectivity infrastructure and the learning performance of management students in Benin."
        ]
      },
      {
        title: "Introduction Générale",
        content: [
          "La démocratisation de l'accès aux réseaux mobiles à haut débit au Bénin ouvre de formidables opportunités pour décongestionner les amphithéâtres surchargés de l'UATM GASA Formation."
        ]
      },
      {
        title: "Chapitre 1 : Revue de Littérature",
        content: [
          "Les travaux sur l'e-learning de Karsenti (2014) en Afrique de l'Ouest montrent que la motivation des apprenants est renforcée par l'utilisation de contenus multimédias interactifs."
        ]
      },
      {
        title: "Chapitre 2 : Méthodologie",
        content: [
          "Étude statistique basée sur un échantillon empirique représentatif de 400 étudiants de la FASEG."
        ]
      },
      {
        title: "Chapitre 3 : Résultats",
        content: [
          "L'accès régulier à des cours numérisés hébergés sur un cloud universitaire augmente de 1.8 point la moyenne générale des étudiants, principalement grâce à la flexibilité temporelle d'apprentissage."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Il est recommandé d'alléger le coût des forfaits éducatifs de télécommunication pour les étudiants de l'UATM GASA."
        ]
      }
    ]
  },
  'thesis-grh-pme': {
    id: 'thesis-grh-pme',
    title: "Contribution à l'étude de la gestion des ressources humaines dans les PME béninoises",
    author: "Rodrigue Dossou",
    supervisor: "Pr. Fatoumata Alabi",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "École Nationale d'Économie Appliquée et de Management (ENEAM)",
    year: 2022,
    sections: [
      {
        title: "Résumé",
        content: [
          "Analyse des dynamiques de fidélisation du personnel qualifié dans un marché du travail informel très mouvant au Sud du Bénin."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Les petites et moyennes entreprises forment plus de 85% du tissu économique béninois mais font face à un fort taux de rotation de leurs cadres."
        ]
      },
      {
        title: "Chapitre 1 : Théories GRH",
        content: [
          "Explorer les modèles de satisfaction au travail de Herzberg adaptés au climat managérial d'Afrique francophone."
        ]
      },
      {
        title: "Chapitre 2 : Méthodologie",
        content: [
          "Enquête de terrain auprès de 50 PME implantées dans la zone industrielle de Gbégamey à Cotonou."
        ]
      },
      {
        title: "Chapitre 3 : Résultats",
        content: [
          "Les facteurs non-monétaires (climat relationnel familial, perspectives de formation, flexibilité) impactent davantage l'engagement des employés que les compléments salariaux bruts."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Les gestionnaires doivent s'orienter vers des méthodes de GRH participatives et une meilleure assurance santé sociale."
        ]
      }
    ]
  },
  'thesis-ged-univ': {
    id: 'thesis-ged-univ',
    title: "Mise en place d'un système de gestion électronique des documents dans les universités publiques",
    author: "Koffi Agbodjan",
    supervisor: "Dr. Wilfried Lokossou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Institut de Formation et de Recherche en Informatique (IFRI)",
    year: 2024,
    sections: [
      {
        title: "Résumé",
        content: [
          "Conception et déploiement d'une architecture Open-Source pour simplifier la signature électronique, le stockage crypté et la consultation des relevés de notes et mémoires."
        ]
      },
      {
        title: "Introduction",
        content: [
          "L'archivage physique dans nos secrétariats académiques fait face à des risques de dégradation climatique constante et de lourdeurs procédurales."
        ]
      },
      {
        title: "Chapitre 1 : Technologies de GED",
        content: [
          "Comparaison des performances des architectures Alfresco, Nuxeo et de l'intégration personnalisée avec des bases de données orientées documents."
        ]
      },
      {
        title: "Chapitre 2 : Architecture Proposée",
        content: [
          "Nous décrivons le modèle 'GesGED-UATM-GASA' reposant sur une API Gateway Node.js et un serveur de stockage décentralisé sur site de l'Université."
        ]
      },
      {
        title: "Chapitre 3 : Tests et Sécurité",
        content: [
          "Les temps de réponse pour la recherche documentaire sont passés de 25 minutes (recherche manuelle en classeurs) à moins de 800 millisecondes."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Ce prototype sécurisé offre une réponse immédiate aux enjeux de traçabilité de l'UATM GASA Formation."
        ]
      }
    ]
  },
  'thesis-ppp-admin': {
    id: 'thesis-ppp-admin',
    title: "Les opportunités et défis du contrat de partenariat public-privé en droit administratif béninois",
    author: "Chancelle Vidégla",
    supervisor: "Dr. Hervé Tokpanou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Faculté de Droit et de Science Politique (FADESP)",
    year: 2021,
    sections: [
      {
        title: "Résumé",
        content: [
          "Analyse juridique comparative du cadre législatif des PPP instauré par la loi de 2017 et de ses implications dans l'exécution des projets d'infrastructures routières."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Le déficit d'investissement public dans les pays en développement exige le recours aux capitaux privés, entraînant d'importants défis d'évaluation des risques budgétaires pour l'État."
        ]
      },
      {
        title: "Chapitre 1 : Le Cadre Réglementaire",
        content: [
          "Étude de l'évolution du droit coutumier des concessions vers des modèles complexes de Partenariats Public-Privé."
        ]
      },
      {
        title: "Chapitre 2 : Cas d'études",
        content: [
          "Analyse de la concession du Port Autonome de Cotonou et des projets de raccordement routier."
        ]
      },
      {
        title: "Chapitre 3 : Recommandations juridiques",
        content: [
          "Sécuriser le rôle régulateur du Tribunal Administratif face aux clauses arbitrales étrangères généralement insérées dans ces contrats d'envergure."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Les PPP constituent un levier exceptionnel si l'asymétrie d'information juridique est maîtrisée par l'appareil d'État béninois."
        ]
      }
    ]
  },
  'thesis-chaussees': {
    id: 'thesis-chaussees',
    title: "Étude géotechnique et dimensionnement des chaussées face aux inondations récurrentes à Cotonou",
    author: "Brice Dossou",
    supervisor: "Pr. Fatoumata Alabi",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "École Polytechnique (UATM GASA)",
    year: 2023,
    sections: [
      {
        title: "Dédicaces et Résumé",
        content: [
          "À tous les ingénieurs de génie civil qui œuvrent pour l'assainissement de nos villes africaines.",
          "Ce mémoire formule des alternatives de dimensionnement géotechnique des structures de chaussée soumises aux phénomènes d'immersion prolongée à Cotonou (zones de Fidjrossé et d'Akpakpa)."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Les pluies intenses associées à la montée du niveau de la nappe phréatique côtière à Cotonou favorisent une dégradation précoce des enrobés bitumineux traditionnels."
        ]
      },
      {
        title: "Chapitre 1 : Caractérisation des Sols Subordonnés",
        content: [
          "Analyse de la teneur en eau naturelle, propriétés de retrait-gonflement et indice CBR (California Bearing Ratio) de la terre rouge de barre locale."
        ]
      },
      {
        title: "Chapitre 2 : Modélisation Méthodologique",
        content: [
          "Calculs de dimensionnement structurel avec le logiciel Alizé-Chaussée pour des cycles d'immersion sous charge lourde de 13 tonnes à l'essieu."
        ]
      },
      {
        title: "Chapitre 3 : Résultats de Laboratoire",
        content: [
          "Un béton de sol stabilisé au ciment montre des qualités de conservation mécanique nettement supérieures (perte de cohésion limitée de 10% seulement après 72h sous eaux), comparé aux couches classiques de sable latéritique qui se liquéfient de façon abrupte."
        ]
      },
      {
        title: "Conclusion & Perspectives",
        content: [
          "Nous suggérons une révision complète du catalogue des structures de chaussées du Bénin pour y intégrer des fondations drainantes plus adaptées."
        ]
      }
    ]
  },
  'thesis-ia-agile': {
    id: 'thesis-ia-agile',
    title: "Impact de l'IA Générative sur le développement logiciel agile au sein des tech hubs béninois",
    author: "Rodrigue Gbaguidi",
    supervisor: "Dr. Arnaud Houessou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Institut de Formation et de Recherche en Informatique (IFRI)",
    year: 2023,
    sections: [
      {
        title: "Résumé",
        content: [
          "Étude sur l'accélération de la vélocité des sprints Scrum grâce à l'implémentation de copilotes IA et son impact sur la qualité du code livré."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Les startups technologiques à Cotonou adoptent rapidement des assistants IA génératifs pour compenser le manque de développeurs séniors."
        ]
      },
      {
        title: "Chapitre 1 : Agilité et Systèmes Génératifs",
        content: [
          "Review des métriques classiques d'agilité (burndown charts, vélocité, taux de bugs introduits) au regard des théories du travail augmenté."
        ]
      },
      {
        title: "Chapitre 2 : Méthodologie Expérimentale",
        content: [
          "Étude comparative sur deux mois avec 4 équipes de développement travaillant sur des projets identiques avec et sans assistance d'IA."
        ]
      },
      {
        title: "Chapitre 3 : Résultats & Métriques",
        content: [
          "La vélocité des sprints a progressé de 32% pour l'écriture de boilerplate et des tests unitaires. Cependant, la détection tardive de failles de sécurité ou de hallucinations a requis 12% d'effort de relecture de code supplémentaire."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "L'incorporation de l'IA doit être accompagnée de solides politiques de 'Review' par des développeurs séniors."
        ]
      }
    ]
  },
  'thesis-thermal': {
    id: 'thesis-thermal',
    title: "Optimisation de la climatisation passive et thermique des habitats en zone côtière : Cas de Cotonou",
    author: "Wilfried Amoussou",
    supervisor: "Dr. Arnaud Houessou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "École Polytechnique (UATM GASA)",
    year: 2022,
    sections: [
      {
        title: "Résumé",
        content: [
          "Proposition d'une enveloppe bioclimatique exploitant la brique de terre compressée (BTC) et les brise-soleil orientables pour minimiser le recours à la climatisation électrique à Cotonou."
        ]
      },
      {
        title: "Introduction",
        content: [
          "A Cotonou, la forte humidité de l'air conjuguée aux fortes températures crée un inconfort thermique majeur résolu d'ordinaire par des équipements de climatisation énergivores."
        ]
      },
      {
        title: "Chapitre 1 : Bioclimatisme Tropical Humide",
        content: [
          "Principes de la ventilation naturelle traversante et du déphasage thermique des matériaux de mur."
        ]
      },
      {
        title: "Chapitre 2 : Méthode Expérimentale",
        content: [
          "Relevés de température dans un abri d'essai construit en parpaings classiques d'un côté, et en BTC locale stabilisée au ciment de l'autre."
        ]
      },
      {
        title: "Chapitre 3 : Analyse des Résultats",
        content: [
          "La brique de terre compressée permet de réduire la température intérieure moyenne de 3.2°C l'après-midi et restitue la fraîcheur nocturne avec un déphasage d'environ 6.5 heures."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "La réglementation d'urbanisme béninoise gagnerait à encourager la fabrication et l'usage des briques de terre compressées."
        ]
      }
    ]
  },
  'thesis-biopolymers': {
    id: 'thesis-biopolymers',
    title: "Valorisation des déchets de coques de coton au Bénin pour la synthèse de biopolymères",
    author: "Adjoua Dansou",
    supervisor: "Dr. Arnaud Houessou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "École Polytechnique (UATM GASA)",
    year: 2024,
    sections: [
      {
        title: "Résumé",
        content: [
          "Recherche exploratoire sur l'extraction de nanocristaux de cellulose à partir des résidus agricoles de la filière coton au Nord-Bénin pour la production d'emballages biodégradables."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Première culture d'exportation du Bénin, le coton génère d'immenses volumes de déchets non valorisés pouvant pourtant devenir une alternative majeure aux plastiques d'origine fossile importés."
        ]
      },
      {
        title: "Chapitre 1 : Polymères bio-sourcés",
        content: [
          "Analyse chimique des composants des résidus cellulosiques lignifiés de la coque de coton."
        ]
      },
      {
        title: "Chapitre 2 : Processus d'extraction",
        content: [
          "Traitement alcalin suivi d'un blanchiment au chlorite de sodium puis d'une hydrolyse acide sulfurique contrôlée."
        ]
      },
      {
        title: "Chapitre 3 : Propriétés Physico-Mécaniques",
        content: [
          "Les films de biopolymères obtenus possèdent une résistance en traction décente (32 MPa) et se dégradent en compost de sol en moins de 18 jours de manière inoffensive."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Ce procédé brevetable crée une valeur circulaire extraordinaire pour la filière cotonnière béninoise."
        ]
      }
    ]
  },
  'thesis-blockchain': {
    id: 'thesis-blockchain',
    title: "Blockchain et traçabilité de la filière cajou au Bénin : Transparence des marchés",
    author: "Clarisse Kpènou",
    supervisor: "Dr. Arnaud Houessou",
    institution: "UATM GASA Formation (UATM GASA)",
    faculty: "Faculté des Sciences Économiques et de Gestion (FASEG)",
    year: 2023,
    sections: [
      {
        title: "Résumé",
        content: [
          "Modélisation d'un registre décentralisé Hyperledger Fabric pour consigner l'historique d'achat des noix brutes de cajou auprès des coopératives paysannes du Nord-Bénin."
        ]
      },
      {
        title: "Introduction",
        content: [
          "Le cajou souffre d'un manque criant de transparence au niveau de la fixation des prix d'achat, lésant les petits producteurs au profit d'intermédiaires multiples."
        ]
      },
      {
        title: "Chapitre 1 : Blockchain et Chaîne de valeur",
        content: [
          "Pourquoi les contrats intelligents (smart contracts) permettent de garantir une juste répartition de la valeur ajoutée agricole."
        ]
      },
      {
        title: "Chapitre 2 : Modèle Smart Contract",
        content: [
          "Conception des transactions de pesée, de transport maritime et de paiement instantané aux coopératives agricoles."
        ]
      },
      {
        title: "Chapitre 3 : Résultats de simulation",
        content: [
          "L'automatisation élimine 3 intermédiaires spéculatifs inutiles et garantit un prix d'achat supérieur de 18% aux paysans tout en traçant l'origine biologique certifiée."
        ]
      },
      {
        title: "Conclusion",
        content: [
          "Le déploiement à l'échelle nationale catalysera une autonomisation des communautés rurales béninoises."
        ]
      }
    ]
  }
};
