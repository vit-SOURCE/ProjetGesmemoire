import React, { useState } from 'react';
import { School, Bell, Search, Download, UserPlus, Users, CheckSquare, Clock, ShieldAlert, Check, X, ArrowDown, Link, Home, Award, UserCheck, Plus, FileText, MessageSquare } from 'lucide-react';
import { User, Thesis, PendingRegistration, ActivityLog } from '../types';
import { generateDeanReportPDF } from '../utils/pdfGenerator';
import InternalChatAndBot from './InternalChatAndBot';

interface DeanDashboardProps {
  currentUser: User;
  theses: Thesis[];
  registrations: PendingRegistration[];
  logs: ActivityLog[];
  onApproveRegistration: (id: string) => void;
  onRejectRegistration: (id: string) => void;
  onAssignTeacher: (studentName: string, teacherName: string) => void;
  onNavigate: (view: string) => void;
  onReadThesis?: (thesis: Thesis) => void;
  onLogout: () => void;
  allUsers?: User[];
  onUpdateThesis?: (id: string, updatedParams: Partial<Thesis>) => void;
}

export default function DeanDashboard({
  currentUser,
  theses,
  registrations,
  logs,
  onApproveRegistration,
  onRejectRegistration,
  onAssignTeacher,
  onNavigate,
  onReadThesis,
  onLogout,
  allUsers = [],
  onUpdateThesis
}: DeanDashboardProps) {

  const [selectedStudent, setSelectedStudent] = useState('');
  const [selectedTeacher, setSelectedTeacher] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState<string>('all');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeCommentThesisId, setActiveCommentThesisId] = useState<string | null>(null);
  const [newCommentText, setNewCommentText] = useState('');

  // Filter theses based on research search term AND academic year selection
  const filteredTheses = theses.filter(t => {
    if (selectedYear !== 'all' && t.year.toString() !== selectedYear) {
      return false;
    }
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase();
      const matchesTitle = t.title.toLowerCase().includes(term);
      const matchesStudent = t.studentName.toLowerCase().includes(term) || t.studentId.toLowerCase().includes(term);
      const matchesTeacher = t.assignedTeacherName ? t.assignedTeacherName.toLowerCase().includes(term) : false;
      const matchesDomain = t.domain.toLowerCase().includes(term);
      return matchesTitle || matchesStudent || matchesTeacher || matchesDomain;
    }
    return true;
  });

  const availableYears = Array.from(new Set([...theses.map(t => t.year), 2024, 2023, 2022])).sort((a, b) => b - a);

  // Stats
  const totalUserCount = 1284;
  const validatedManuscriptsCount = filteredTheses.filter(t => t.status === 'accepted').length + (selectedYear === 'all' ? 448 : (selectedYear === '2023' ? 220 : selectedYear === '2024' ? 180 : 48)); 
  const inEvaluationCount = filteredTheses.filter(t => t.status === 'pending').length + (selectedYear === 'all' ? 86 : (selectedYear === '2023' ? 30 : selectedYear === '2024' ? 45 : 11)); 
  const pendingAccountsCount = registrations.length + 23; // Total 26

  const handleAssignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedTeacher) {
      alert("Veuillez sélectionner un étudiant et un maître de mémoire.");
      return;
    }
    const targetThesis = theses.find(t => t.id === selectedStudent);
    const targetTeacher = allUsers.find(u => u.id === selectedTeacher);
    
    const sName = targetThesis ? targetThesis.studentName : selectedStudent;
    const tName = targetTeacher ? `Dr. ${targetTeacher.firstName} ${targetTeacher.lastName}` : selectedTeacher;

    onAssignTeacher(selectedStudent, selectedTeacher);
    alert(`Assignation confirmée! ${sName} est maintenant encadré par ${tName}.`);
    setSelectedStudent('');
    setSelectedTeacher('');
  };

  const handleExport = () => {
    alert("Exportation des données au format CSV initiée...");
  };

  const handleGeneratePdf = () => {
    generateDeanReportPDF(filteredTheses, {
      totalUsers: totalUserCount,
      validatedCount: validatedManuscriptsCount,
      inEvaluationCount: inEvaluationCount,
      pendingAccountsCount: pendingAccountsCount
    });
  };

  return (
    <div className="bg-background text-on-surface min-h-screen pb-32">
      
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-white border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2">
          <School className="text-primary w-6 h-6" />
          <span className="font-bold text-lg md:text-xl text-primary tracking-tight">GesMemoires</span>
        </div>

        {/* Search Bar Desktop */}
        <div className="hidden md:flex flex-1 max-w-xl mx-8 px-4 items-center bg-surface-container-low rounded-lg border border-outline-variant focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
          <Search className="text-secondary w-4 h-4 mr-2" />
          <input 
            className="w-full bg-transparent border-none focus:ring-0 py-2 text-xs text-on-surface" 
            placeholder="Rechercher un étudiant, un mémoire ou un tuteur..." 
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-100 rounded-lg text-xs font-bold text-primary border border-primary/20 transition-all cursor-pointer relative"
            title="Messagerie Interne & Chatbot"
          >
            <MessageSquare className="w-4 h-4 text-primary" />
            <span className="hidden md:inline">Salon & Chatbot</span>
            <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
          </button>

          <button className="relative p-2 hover:bg-surface-container-low rounded-full transition-colors active:scale-95 cursor-pointer">
            <Bell className="text-secondary w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-error rounded-full"></span>
          </button>
          <div className="flex items-center gap-2.5 border-l border-outline-variant pl-4">
            <div className="w-8 h-8 rounded-full bg-primary-container flex items-center justify-center text-white font-bold text-xs uppercase">
              {currentUser.firstName[0]}{currentUser.lastName[0]}
            </div>
            <div className="hidden lg:block text-left">
              <p className="text-xs font-bold text-on-surface leading-none">{currentUser.firstName} {currentUser.lastName}</p>
              <p className="text-[10px] text-secondary font-medium mt-0.5">Dir. des Études</p>
            </div>
            <button 
              onClick={onLogout}
              className="text-xs text-error hover:underline font-semibold cursor-pointer ml-2"
            >
              Quitter
            </button>
          </div>
        </div>
      </header>

      {/* Main layout grid */}
      <main className="pt-24 px-6 max-w-7xl mx-auto flex flex-col gap-8">
        
        {/* Dashboard Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-primary mb-1">Tableau de bord</h1>
            <p className="text-xs text-secondary font-medium font-sans">Bienvenue, voici l'état actuel des thèses et des comptes.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="bg-white border border-outline-variant text-secondary hover:bg-slate-50 px-3 py-2 rounded-lg text-xs font-semibold shadow-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary cursor-pointer"
            >
              <option value="all">Toutes les années</option>
              {availableYears.map((year) => (
                <option key={year} value={year.toString()}>
                  Année : {year}
                </option>
              ))}
            </select>
            <button 
              onClick={handleGeneratePdf}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 px-4 py-2 rounded-lg text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              Générer rapport
            </button>
            <button 
              onClick={handleExport}
              className="flex items-center gap-1.5 bg-white border border-outline-variant text-secondary hover:bg-slate-50 px-4 py-2 rounded-lg text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Exporter
            </button>
            <button 
              onClick={() => alert("Formulaire de création d'étudiant classique.")}
              className="flex items-center gap-1.5 bg-primary-container text-white px-4 py-2 rounded-lg text-xs font-semibold hover:opacity-95 shadow-sm transition-all active:scale-95 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              Nouvel Étudiant
            </button>
          </div>
        </div>

        {/* Bento Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Stat Card 1 */}
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="p-2 bg-slate-100 rounded-lg text-primary">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-emerald-600 font-bold text-[10px] flex items-center gap-0.5">
                +12%
              </span>
            </div>
            <div className="mt-4">
              <p className="text-[10px] font-bold tracking-wider text-secondary uppercase">Total Utilisateurs</p>
              <h2 className="text-2xl font-bold mt-1 text-primary">{totalUserCount}</h2>
            </div>
          </div>

          {/* Stat Card 2 */}
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="p-2 bg-slate-100 rounded-lg text-primary">
                <CheckSquare className="w-4 h-4" />
              </div>
              <span className="text-emerald-600 font-bold text-[10px] flex items-center gap-0.5">
                +5%
              </span>
            </div>
            <div className="mt-4">
              <p className="text-[10px] font-bold tracking-wider text-secondary uppercase">Mémoires Validés</p>
              <h2 className="text-2xl font-bold mt-1 text-primary">{validatedManuscriptsCount}</h2>
            </div>
          </div>

          {/* Stat Card 3 */}
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="p-2 bg-slate-100 rounded-lg text-primary">
                <Clock className="w-4 h-4" />
              </div>
              <span className="text-amber-600 font-bold text-[10px] flex items-center gap-0.5">
                14 En attente
              </span>
            </div>
            <div className="mt-4">
              <p className="text-[10px] font-bold tracking-wider text-secondary uppercase">En cours d'examen</p>
              <h2 className="text-2xl font-bold mt-1 text-primary">{inEvaluationCount}</h2>
            </div>
          </div>

          {/* Stat Card 4 */}
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="p-2 bg-slate-100 rounded-lg text-primary">
                <ShieldAlert className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-[10px] font-bold tracking-wider text-secondary uppercase">Comptes à valider</p>
              <h2 className="text-2xl font-bold mt-1 text-primary">{pendingAccountsCount}</h2>
            </div>
          </div>
        </div>

        {/* Main Content Sections: Two Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Accounts Waiting Validation */}
          <div className="lg:col-span-2 flex flex-col gap-6">
            <div className="bg-white rounded-xl border border-outline-variant shadow-sm overflow-hidden">
              <div className="p-5 border-b border-outline-variant flex justify-between items-center bg-white">
                <h3 className="font-bold text-sm text-primary uppercase tracking-wider">Inscriptions en attente</h3>
                <span className="text-xs font-semibold text-secondary">{registrations.length} demandes</span>
              </div>
              
              {registrations.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-xs text-secondary">Toutes les inscriptions ont été validées.</p>
                </div>
              ) : (
                <div>
                  {/* Desktop view */}
                  <div className="hidden md:block overflow-x-auto text-xs">
                    <table className="w-full text-left font-sans">
                      <thead className="bg-surface-container-low border-b border-outline-variant">
                        <tr>
                          <th className="px-5 py-3 font-bold text-secondary">Utilisateur</th>
                          <th className="px-5 py-3 font-bold text-secondary">Type</th>
                          <th className="px-5 py-3 font-bold text-secondary">Date</th>
                          <th className="px-5 py-3 font-bold text-secondary text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-outline-variant bg-white">
                        {registrations.map((reg) => (
                          <tr key={reg.id} className="hover:bg-slate-50 transition-colors">
                            <td className="px-5 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-[11px] uppercase">
                                  {reg.firstName[0]}
                                  {reg.lastName[0]}
                                </div>
                                <div>
                                  <p className="font-semibold text-primary">{reg.firstName} {reg.lastName}</p>
                                  <p className="text-[11px] text-secondary font-medium">{reg.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-5 py-4">
                              <span className="px-2.5 py-0.5 rounded bg-slate-100 text-secondary font-bold text-[10px] tracking-wide uppercase">
                                {reg.role === 'teacher' ? 'Maître de mémoire' : 'Étudiant'}
                              </span>
                            </td>
                            <td className="px-5 py-4 text-secondary">
                              {reg.date}
                            </td>
                            <td className="px-5 py-4 text-right">
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => onRejectRegistration(reg.id)}
                                  className="p-2 text-error hover:bg-error-container/45 rounded-md transition-colors cursor-pointer border border-error/10"
                                  title="Rejeter"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => onApproveRegistration(reg.id)}
                                  className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer border border-emerald-200/50"
                                  title="Valider"
                                >
                                  <Check className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile View with clean card UI */}
                  <div className="block md:hidden p-4 space-y-4">
                    {registrations.map((reg) => (
                      <div key={reg.id} className="p-4 bg-slate-50 border border-slate-150 rounded-xl flex flex-col gap-3 text-xs">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm uppercase shrink-0">
                            {reg.firstName[0]}
                            {reg.lastName[0]}
                          </div>
                          <div>
                            <p className="font-bold text-primary text-sm">{reg.firstName} {reg.lastName}</p>
                            <p className="text-xs text-secondary mt-0.5">{reg.email}</p>
                          </div>
                        </div>

                        <div className="flex justify-between items-center text-xs text-secondary mt-1">
                          <span className="px-2 py-0.5 rounded bg-white border border-slate-200 text-secondary font-bold text-[9px] uppercase tracking-wide">
                            {reg.role === 'teacher' ? 'Maître' : 'Étudiant'}
                          </span>
                          <span className="text-[10px]">{reg.date}</span>
                        </div>

                        <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200/60">
                          <button
                            onClick={() => onRejectRegistration(reg.id)}
                            className="flex-1 py-2 text-error border border-error/20 hover:bg-error-container/20 rounded-lg font-bold text-xs cursor-pointer min-h-[40px] text-center uppercase tracking-wide"
                          >
                            Rejeter
                          </button>
                          <button
                            onClick={() => onApproveRegistration(reg.id)}
                            className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer min-h-[40px] text-center uppercase tracking-wide shadow-sm"
                          >
                            Valider
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* List of Theses / Mémoires */}
            <div className="bg-white rounded-xl border border-outline-variant shadow-sm overflow-hidden animate-fade-in">
              <div className="p-5 border-b border-outline-variant flex flex-col sm:flex-row justify-between sm:items-center gap-3 bg-white">
                <div>
                  <h3 className="font-bold text-sm text-primary uppercase tracking-wider">Suivi des Mémoires</h3>
                  <p className="text-[10px] text-secondary font-medium tracking-normal mt-0.5">
                    {selectedYear === 'all' ? "Toutes les années académiques" : `Année académique : ${selectedYear}`} | {filteredTheses.length} mémoire(s) trouvé(s)
                  </p>
                </div>
                {searchTerm && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-secondary border border-outline-variant/60">
                    Terme : "{searchTerm}"
                  </span>
                )}
              </div>

              {filteredTheses.length === 0 ? (
                <div className="text-center py-12 px-4 shadow-inner bg-slate-50/50">
                  <p className="text-xs text-secondary font-sans font-medium">Aucun mémoire trouvé correspondant à ces critères de recherche ou de filtre.</p>
                </div>
              ) : (
                <div className="overflow-x-auto text-xs w-full">
                  <table className="min-w-[800px] w-full text-left font-sans">
                    <thead className="bg-surface-container-low border-b border-outline-variant">
                      <tr>
                        <th className="px-5 py-3 font-bold text-secondary">Étudiant</th>
                        <th className="px-5 py-3 font-bold text-secondary">Mémoire / Thématique</th>
                        <th className="px-5 py-3 font-bold text-secondary">Maître / Encadrant</th>
                        <th className="px-5 py-3 font-bold text-secondary">Statut</th>
                        <th className="px-5 py-3 font-bold text-secondary text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-outline-variant bg-white">
                      {filteredTheses.map((thesis) => (
                        <React.Fragment key={thesis.id}>
                          <tr className="hover:bg-slate-50/80 transition-colors">
                            <td className="px-5 py-4">
                              <div>
                                <p className="font-semibold text-primary">{thesis.studentName}</p>
                                <p className="text-[10px] text-secondary font-medium mt-0.5">{thesis.studentId}</p>
                              </div>
                            </td>
                            <td className="px-5 py-4 max-w-xs md:max-w-md">
                              <div>
                                <p className="font-semibold text-primary leading-snug">{thesis.title}</p>
                                <div className="flex gap-2 mt-1.5">
                                  <span className="px-2 py-0.5 rounded bg-slate-100 text-[9px] text-secondary font-medium uppercase font-sans tracking-wide">{thesis.domain}</span>
                                  <span className="px-2 py-0.5 rounded bg-slate-100 text-[9px] text-secondary font-mono">Année {thesis.year}</span>
                                </div>
                              </div>
                            </td>
                            <td className="px-5 py-4">
                              {thesis.assignedTeacherName ? (
                                <div className="flex items-center gap-1.5">
                                  <span className="text-primary font-medium text-xs">
                                    {thesis.assignedTeacherName}
                                  </span>
                                </div>
                              ) : (
                                <span className="italic text-secondary text-[11px] font-medium bg-slate-50 px-2 py-1 rounded border border-dashed border-outline-variant/50">Non assigné</span>
                              )}
                            </td>
                            <td className="px-5 py-4 text-left">
                              {thesis.status === 'accepted' ? (
                                <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-bold text-[10px] tracking-wide border border-emerald-200">
                                  VALIDE
                                </span>
                              ) : thesis.status === 'rejected' ? (
                                <span className="px-2 py-0.5 rounded bg-red-50 text-error font-bold text-[10px] tracking-wide border border-error/20">
                                  REJETE
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-800 font-bold text-[10px] tracking-wide border border-blue-200">
                                  EXAMEN
                                </span>
                              )}
                            </td>
                            <td className="px-5 py-4 text-right">
                              <div className="flex justify-end gap-2">
                                {onReadThesis && (
                                  <button
                                    onClick={() => onReadThesis(thesis)}
                                    className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/50 px-2.5 py-1.5 rounded-md font-semibold font-sans text-[11px] cursor-pointer inline-flex items-center gap-1"
                                  >
                                    Lire
                                  </button>
                                )}
                                {onUpdateThesis && (
                                  <button
                                    onClick={() => {
                                      if (activeCommentThesisId === thesis.id) {
                                        setActiveCommentThesisId(null);
                                      } else {
                                        setActiveCommentThesisId(thesis.id);
                                        setNewCommentText('');
                                      }
                                    }}
                                    className="bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200/60 px-2.5 py-1.5 rounded-md font-semibold font-sans text-[11px] cursor-pointer inline-flex items-center gap-1 text-nowrap"
                                  >
                                    Commenter
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                          {activeCommentThesisId === thesis.id && (
                            <tr className="bg-slate-50/50">
                              <td colSpan={5} className="px-6 py-4">
                                <div className="p-4 bg-white rounded-xl border border-outline-variant shadow-xs flex flex-col gap-3 font-sans text-left">
                                  <h4 className="font-bold text-xs text-primary uppercase tracking-wide">
                                    Commentaires de correction sur ce mémoire ({thesis.comments ? thesis.comments.length : 0})
                                  </h4>
                                  
                                  {(!thesis.comments || thesis.comments.length === 0) ? (
                                    <p className="text-xs text-secondary italic">Aucun commentaire de correction déposé sur ce mémoire.</p>
                                  ) : (
                                    <div className="space-y-2 mt-1 max-h-48 overflow-y-auto pr-1">
                                      {thesis.comments.map(c => (
                                        <div key={c.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs text-left">
                                          <div className="flex justify-between text-[10px] font-bold text-secondary uppercase mb-1">
                                            <span>{c.authorName} ({c.authorRole})</span>
                                            <span>{c.date}</span>
                                          </div>
                                          <p className="text-slate-700">{c.text}</p>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                  
                                  <form 
                                    onSubmit={(e) => {
                                      e.preventDefault();
                                      if (!newCommentText.trim()) return;
                                      
                                      const newComment = {
                                        id: `c_dean_${Date.now()}`,
                                        authorName: `Dr. ${currentUser.lastName}`,
                                        authorRole: 'Directeur des Études',
                                        date: "Aujourd'hui, à " + new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
                                        text: newCommentText
                                      };
                                      
                                      if (onUpdateThesis) {
                                        onUpdateThesis(thesis.id, {
                                          comments: [newComment, ...(thesis.comments || [])]
                                        });
                                        alert("Commentaire de correction enregistré.");
                                        setNewCommentText('');
                                        setActiveCommentThesisId(null);
                                      }
                                    }}
                                    className="mt-2"
                                  >
                                    <label className="block text-[10px] font-bold text-secondary uppercase mb-1">Ajouter une annotation / consigne de correction :</label>
                                    <div className="flex gap-2">
                                      <input 
                                        type="text"
                                        placeholder="Ex: Revoir l'orthographe de la section 3 et préciser l'échantillon des PME..."
                                        className="flex-grow p-2.5 border border-outline-variant rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                                        value={newCommentText}
                                        onChange={(e) => setNewCommentText(e.target.value)}
                                        required
                                      />
                                      <button 
                                        type="submit"
                                        className="bg-primary text-white text-xs font-bold px-4 py-2.5 rounded-lg hover:bg-primary-container active:scale-95 transition-all cursor-pointer shadow-sm shrink-0"
                                      >
                                        Enregistrer
                                      </button>
                                    </div>
                                  </form>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Fast Assignment & activity */}
          <div className="flex flex-col gap-6">
            
            {/* Quick assignment box */}
            <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col gap-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-primary">Assignation Rapide</h3>
              <form onSubmit={handleAssignSubmit} className="space-y-4">
                
                <div>
                  <label className="block text-[11px] font-bold text-secondary mb-1">Étudiant non-assigné</label>
                  <select 
                    className="w-full bg-surface border border-outline-variant rounded-lg text-xs p-2.5 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                    value={selectedStudent}
                    onChange={(e) => setSelectedStudent(e.target.value)}
                  >
                    <option value="">Sélectionner un étudiant...</option>
                    {theses.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.studentName} — {t.title.slice(0, 35)}...
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex justify-center">
                  <ArrowDown className="w-4 h-4 text-secondary" />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-secondary mb-1">Maître de mémoire</label>
                  <select 
                    className="w-full bg-surface border border-outline-variant rounded-lg text-xs p-2.5 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                    value={selectedTeacher}
                    onChange={(e) => setSelectedTeacher(e.target.value)}
                  >
                    <option value="">Sélectionner un tuteur...</option>
                    {allUsers.filter(u => u.role === 'teacher').map(t => (
                      <option key={t.id} value={t.id}>
                        Dr. {t.firstName} {t.lastName} ({t.details?.titleOffice || 'Enseignant'})
                      </option>
                    ))}
                    {allUsers.filter(u => u.role === 'teacher').length === 0 && (
                      <option value="user-teacher">Dr. Arnaud Houessou (Maître de Conférences)</option>
                    )}
                  </select>
                </div>

                <button 
                  className="w-full bg-primary-container text-white py-3 rounded-lg text-xs font-semibold hover:bg-primary transition-all active:scale-95 duration-100 flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  type="submit"
                >
                  <Link className="w-4 h-4" />
                  Confirmer l'assignation
                </button>
              </form>
            </div>

            {/* Recent Activity Flow */}
            <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm">
              <h3 className="font-bold text-xs uppercase tracking-wider text-primary mb-4">Flux d'activité</h3>
              <div className="space-y-4">
                {logs.map((log) => (
                  <div key={log.id} className="flex gap-3 text-xs leading-normal">
                    <div className="relative flex flex-col items-center">
                      <div className="w-2.5 h-2.5 rounded-full bg-primary-container mt-1 shrink-0"></div>
                      <div className="w-[1px] bg-outline-variant/60 flex-1 my-1"></div>
                    </div>
                    <div>
                      <p className="text-on-surface font-sans" dangerouslySetInnerHTML={{ __html: log.text.replace(/Directeur|Koffi Zannou|Rodrigue Dansou|Fatoumata Alabi|Dr\. Houessou/gi, '<strong>$&</strong>') }}></p>
                      <span className="text-[10px] text-secondary font-medium mt-1 block">{log.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </main>



      {/* Floating action button (FAB) */}
      <button 
        onClick={() => alert("Formulaire rapide d'ajout")}
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Shared bottom navigation bar for mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-50 flex justify-around items-center bg-white border-t border-outline-variant py-2 shadow-lg h-16">
        <button onClick={() => onNavigate('landing')} className="flex flex-col items-center text-secondary">
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-1">Home</span>
        </button>
        <button className="flex flex-col items-center text-primary">
          <Award className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-1">Directeur</span>
        </button>
      </nav>

      {isChatOpen && (
        <InternalChatAndBot 
          currentUser={currentUser} 
          onClose={() => setIsChatOpen(false)} 
        />
      )}
    </div>
  );
}
