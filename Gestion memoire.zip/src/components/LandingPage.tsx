import React, { useState } from 'react';
import { School, ArrowRight, CheckCircle, Bookmark, Calendar, ExternalLink, Send, Search, Menu, X } from 'lucide-react';
import { Thesis } from '../types';

interface LandingPageProps {
  onNavigate: (view: string) => void;
  theses: Thesis[];
  onReadThesis?: (thesis: Thesis) => void;
}

export default function LandingPage({ onNavigate, theses, onReadThesis }: LandingPageProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="bg-background min-h-screen text-on-surface">
      {/* Top Navigation Bar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-surface border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-3">
          <School className="text-primary w-8 h-8" />
          <h1 className="font-bold text-xl md:text-2xl text-primary tracking-tight">GesMemoires</h1>
        </div>
        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          <a href="#" className="font-medium text-primary hover:text-primary/80 transition-colors">Accueil</a>
          <a href="#catalogue" className="font-medium text-secondary hover:text-primary transition-colors">Explorer</a>
          <a href="#contact" className="font-medium text-secondary hover:text-primary transition-colors">Support</a>
          <div className="h-6 w-[1px] bg-outline-variant mx-2"></div>
          <button 
            onClick={() => onNavigate('login')}
            className="text-secondary border border-outline px-4 py-2 rounded-lg hover:bg-surface-container-low transition-all text-sm font-semibold active:scale-95 cursor-pointer"
          >
            Connexion
          </button>
          <button 
            onClick={() => onNavigate('register')}
            className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-container transition-all text-sm font-semibold active:scale-95 cursor-pointer shadow-sm"
          >
            Inscription
          </button>
        </nav>
        {/* Mobile Actions */}
        <div className="flex md:hidden items-center gap-3">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 text-primary hover:bg-slate-100 rounded-lg transition-colors focus:outline-none"
            aria-label="Toggle Menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown Menu */}
        {isMenuOpen && (
          <div className="absolute top-16 left-0 w-full bg-white border-b border-outline-variant shadow-lg flex flex-col p-6 gap-4 md:hidden animate-fadeIn z-50">
            <a 
              href="#" 
              onClick={() => setIsMenuOpen(false)}
              className="font-semibold text-primary py-2 border-b border-slate-100"
            >
              Accueil
            </a>
            <a 
              href="#catalogue" 
              onClick={() => setIsMenuOpen(false)}
              className="font-semibold text-secondary hover:text-primary py-2 border-b border-slate-100"
            >
              Explorer
            </a>
            <a 
              href="#contact" 
              onClick={() => setIsMenuOpen(false)}
              className="font-semibold text-secondary hover:text-primary py-2 border-b border-slate-100"
            >
              Support
            </a>
            <div className="flex flex-col gap-3 pt-2">
              <button 
                onClick={() => {
                  setIsMenuOpen(false);
                  onNavigate('login');
                }}
                className="w-full text-center text-secondary border border-outline px-4 py-2.5 rounded-lg hover:bg-surface-container-low transition-all text-sm font-semibold cursor-pointer"
              >
                Connexion
              </button>
              <button 
                onClick={() => {
                  setIsMenuOpen(false);
                  onNavigate('register');
                }}
                className="w-full text-center bg-primary text-white px-4 py-2.5 rounded-lg hover:bg-primary-container transition-all text-sm font-semibold cursor-pointer shadow-sm"
              >
                Inscription
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <main className="pt-16">
        <section className="relative w-full min-h-[500px] md:h-[620px] flex items-center justify-center overflow-hidden bg-primary-container text-white py-12 md:py-0">
          <div className="absolute inset-0 z-0">
            <img 
              className="w-full h-full object-cover opacity-25" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDhBzJzioU_EKPWwiNng8R9wp8GRurlwRdAelG41KQbcV0QgoSxmKPEVIJgPBAxLsD8k1VQnFqmjoZUYUa2xdwTKZ_JrP78Dw7lbMII8IfX8eP7I43f1oAwguj8cDfPWcFVhylzxEV49t3I9KxBXqLLJEg3Ea_yUmy10EuGljaSDTZ36Sz7j8LDBrt2_jWfPbyXD9FZvT2YtnwSCQDllgP5m-gncn5PUm--NC585qvjjf_qrfQ3JOM_AzfmSGc92N7VhdKs1XhzsPs"
              alt="University Library"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/90 to-transparent"></div>
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-6 w-full grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="font-bold text-3xl md:text-5xl lg:text-6xl text-white leading-tight tracking-tight">
                L'excellence académique à portée de main
              </h2>
              <p className="font-sans text-base md:text-lg text-primary-fixed opacity-90 max-w-lg leading-relaxed">
                Simplifiez la gestion, le dépôt et la consultation des mémoires de fin d'études. Une plateforme académique unifiée pour étudiants, encadrants et chercheurs.
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <button 
                  onClick={() => onNavigate('register')}
                  className="bg-white text-primary font-semibold text-sm px-6 py-3.5 rounded-xl flex items-center gap-2 hover:bg-neutral-100 transition-all active:scale-95 cursor-pointer shadow-md"
                >
                  Commencer maintenant 
                  <ArrowRight className="w-4 h-4" />
                </button>
                <a 
                  href="#catalogue"
                  className="border border-white/30 bg-white/10 backdrop-blur-md text-white font-semibold text-sm px-6 py-3.5 rounded-xl hover:bg-white/20 transition-all text-center"
                >
                  Voir le catalogue
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 bg-surface border-b border-slate-150">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-6 bg-white sm:bg-transparent rounded-xl border border-slate-100 sm:border-0 shadow-xs sm:shadow-none space-y-2 md:border-r last:border-0 border-outline-variant/50">
                <p className="text-3xl md:text-4xl font-extrabold text-primary">4,200+</p>
                <p className="text-xs font-semibold tracking-wider text-secondary uppercase">Mémoires Indexés</p>
              </div>
              <div className="text-center p-6 bg-white sm:bg-transparent rounded-xl border border-slate-100 sm:border-0 shadow-xs sm:shadow-none space-y-2 lg:border-r last:border-0 border-outline-variant/50">
                <p className="text-3xl md:text-4xl font-extrabold text-primary">12k</p>
                <p className="text-xs font-semibold tracking-wider text-secondary uppercase">Étudiants Actifs</p>
              </div>
              <div className="text-center p-6 bg-white sm:bg-transparent rounded-xl border border-slate-100 sm:border-0 shadow-xs sm:shadow-none space-y-2 md:border-r last:border-0 border-outline-variant/50">
                <p className="text-3xl md:text-4xl font-extrabold text-primary">15</p>
                <p className="text-xs font-semibold tracking-wider text-secondary uppercase">Départements</p>
              </div>
              <div className="text-center p-6 bg-white sm:bg-transparent rounded-xl border border-slate-100 sm:border-0 shadow-xs sm:shadow-none space-y-2">
                <p className="text-3xl md:text-4xl font-extrabold text-primary">98%</p>
                <p className="text-xs font-semibold tracking-wider text-secondary uppercase">Taux de Validation</p>
              </div>
            </div>
          </div>
        </section>

        {/* Brief Presentation */}
        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-12 gap-12 items-center">
            <div className="md:col-span-5 space-y-4">
              <span className="text-primary font-bold text-sm tracking-widest uppercase">La Plateforme</span>
              <h3 className="text-3xl font-bold text-primary tracking-tight">Le pont numérique entre la recherche et la réussite académique</h3>
              <p className="text-sm md:text-base text-secondary leading-relaxed">
                GesMemoires est conçu pour répondre aux défis des universités modernes. Nous offrons un système robuste pour l'archivage numérique, facilitant la lutte contre le plagiat et assurant une visibilité optimale aux travaux de recherche de vos étudiants.
              </p>
              <ul className="space-y-3 pt-2">
                <li className="flex items-center gap-3 text-on-surface">
                  <CheckCircle className="text-primary w-5 h-5 fill-primary/10" />
                  <span className="text-sm font-medium">Archivage sécurisé, structuré et pérenne</span>
                </li>
                <li className="flex items-center gap-3 text-on-surface">
                  <CheckCircle className="text-primary w-5 h-5 fill-primary/10" />
                  <span className="text-sm font-medium">Interface de correction ergonomique pour tuteurs</span>
                </li>
                <li className="flex items-center gap-3 text-on-surface">
                  <CheckCircle className="text-primary w-5 h-5 fill-primary/10" />
                  <span className="text-sm font-medium">Recherche fine par mots-clés et technologies</span>
                </li>
              </ul>
            </div>
            <div className="md:col-span-7 grid grid-cols-2 gap-4">
              <div className="mt-8">
                <img 
                  className="rounded-xl shadow-sm h-64 w-full object-cover" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAEqTH0Rf6R8D11IR1_ZDpLp6EaXZoyuKc4f4F2i-RwNH1unjBhvuvs6uaNtKuP514AoWThgE8SoCf_tTFDLr0Q9uP-hRgL88_u4WyprfBiTpL1QejOX5B2xgHOrA_3ZoTNyuzt1o0JUhW35jBobBlFCiusJx1t3EuFH8pivNAfh2CXtaD9lAKla0vOquETApu_PfuliP3nO7RI-r94yqTS2bv3ypoNtgDIp1oRmK7qCkExMzjjv0C2wdy6-wdcJGkUpq6x02rMLeQ" 
                  alt="Laptop writing"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <img 
                  className="rounded-xl shadow-sm h-80 w-full object-cover" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCktuwJ-5KdQ2p_b2FIue8RauJ7sAK2ZzZJ1Ew1yDu_1Yw9rrUPgx0C2l5p7dP7KMMR-GTbFXGbiF9aN_ITwpPQcswMLmFuWqa_SUcQT54nKcrxNzRd5zaGfTLtr1wXQpC-HVtY0T6w-ODQ6sEVOtmf-gzZ1ZXkbeAAu5h9jtWIpGBDZdA5A9NJtRWnHgcpiZqrM1KolNbHHQ3RAEMk1OkaRMwO7aiZuFfIgnE7B6-K8VpkhSZsCB7w0gVdjk72x5xIGAJ3mn6ZdPQ" 
                  alt="Students collaboration"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Scrolling Recent Memoirs Section */}
        <section id="catalogue" className="py-20 bg-surface-container-low overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 flex justify-between items-end mb-10">
            <div>
              <h3 className="text-3xl font-bold text-primary tracking-tight">Tableau de recherche & Mémoires</h3>
              <p className="text-sm text-secondary">Dépôts récents validés par le comité de lecture</p>
            </div>
            <button 
              onClick={() => onNavigate('login')}
              className="text-primary font-semibold text-sm flex items-center gap-1 hover:underline cursor-pointer"
            >
              Voir tout 
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {theses.map((thesis) => (
              <div 
                key={thesis.id}
                onClick={() => onReadThesis ? onReadThesis(thesis) : onNavigate('login')}
                className="bg-white p-6 rounded-xl shadow-sm border border-outline-variant hover:border-primary/30 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <span className="bg-secondary-container text-primary font-semibold px-2.5 py-1 rounded-md text-xs">
                      {thesis.domain}
                    </span>
                    <Bookmark className="text-outline group-hover:text-primary transition-colors w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-lg text-primary mb-2 line-clamp-2">
                    {thesis.title}
                  </h4>
                  <p className="text-xs text-secondary mb-4">
                    Par {thesis.studentName} • Université de Recherche
                  </p>
                </div>
                <div className="flex items-center justify-between border-t border-outline-variant/60 pt-4 mt-2">
                  <div className="flex items-center gap-2 text-secondary">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs font-semibold">{thesis.year}</span>
                  </div>
                  <span className="text-primary text-xs font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Lire le mémoire <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Call To Action */}
        <section id="contact" className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-6">
            <div className="bg-primary text-white rounded-2xl p-10 md:p-16 relative overflow-hidden text-center z-10 shadow-lg">
              <div className="absolute top-0 right-0 p-10 opacity-5 -z-10">
                <School className="w-96 h-96" />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold mb-4">Prêt à valoriser vos recherches ?</h3>
              <p className="text-lg text-primary-fixed opacity-90 max-w-2xl mx-auto mb-8">
                Rejoignez des milliers d'étudiants qui partagent leur savoir et soutiennent l'excellence universitaire francophone.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => onNavigate('register')}
                  className="bg-white text-primary font-bold px-8 py-4 rounded-xl hover:bg-neutral-100 transition-all cursor-pointer"
                >
                  Créer un compte étudiant
                </button>
                <button 
                  onClick={() => onNavigate('login')}
                  className="border border-white/50 text-white font-bold px-8 py-4 rounded-xl hover:bg-white/10 transition-all cursor-pointer"
                >
                  Portail Institutionnel
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* University Footer */}
      <footer className="bg-tertiary-container text-white py-16">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <School className="text-tertiary-fixed w-6 h-6" />
              <h2 className="font-bold text-lg text-tertiary-fixed">GesMemoires</h2>
            </div>
            <p className="text-xs leading-relaxed text-on-tertiary-container">
              L'archive ouverte pour la recherche étudiante francophone. Soutenir l'innovation par la diffusion libre du savoir.
            </p>
          </div>
          <div>
            <h5 className="font-bold text-sm text-tertiary-fixed mb-4">Navigation</h5>
            <ul className="space-y-2 text-xs text-on-tertiary-container">
              <li><a href="#" onClick={() => onNavigate('login')} className="hover:text-white transition-colors">Recherche Avancée</a></li>
              <li><a href="#" onClick={() => onNavigate('login')} className="hover:text-white transition-colors">Dépôt de Mémoire</a></li>
              <li><a href="#" onClick={() => onNavigate('login')} className="hover:text-white transition-colors">Contact Support</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-bold text-sm text-tertiary-fixed mb-4">Légal</h5>
            <ul className="space-y-2 text-xs text-on-tertiary-container">
              <li><a href="#" className="hover:text-white transition-colors">Mentions Légales</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Politique de Confidentialité</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Propriété Intellectuelle</a></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-bold text-sm text-tertiary-fixed mb-4">Newsletter</h5>
            <p className="text-xs text-on-tertiary-container">Recevez les publications les plus citées.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email" 
                className="bg-tertiary text-white placeholder-neutral-400 border border-outline-variant/20 rounded-lg focus:outline-none focus:ring-1 focus:ring-tertiary-fixed flex-1 px-3 py-2 text-xs" 
              />
              <button className="bg-tertiary-fixed text-primary p-2 rounded-lg cursor-pointer">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-12 pt-6 border-t border-outline/20 text-center text-xs text-on-tertiary-container opacity-60">
          © 2026 GesMemoires. Tous droits réservés. Développé pour l'excellence universitaire.
        </div>
      </footer>
    </div>
  );
}
