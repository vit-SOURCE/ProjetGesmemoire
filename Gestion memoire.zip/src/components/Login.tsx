import React, { useState } from 'react';
import { School, Loader2 } from 'lucide-react';
import { User, UserRole } from '../types';

interface LoginProps {
  onNavigate: (view: string) => void;
  onLoginSuccess: (user: User) => void;
  allUsers: User[];
}

export default function Login({ onNavigate, onLoginSuccess, allUsers }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    // Simulate database lookup
    setTimeout(() => {
      // Find matching user
      const found = allUsers.find(
        (u) => {
          const emailLower = email.toLowerCase().trim();
          const targetEmail = u.email.toLowerCase().trim();
          return targetEmail === emailLower || 
                 (emailLower === 'arnaud.sessou@uatmgasa.bj' && targetEmail === 'arnaud.houessou@uatmgasa.bj') ||
                 (emailLower === 'koffi.houndegnon@uatmgasa.bj' && targetEmail === 'koffi.zannou@uatmgasa.bj');
        }
      );

      if (found) {
        onLoginSuccess(found);
      } else {
        // Parse email to get a personalized name instead of defaulting statically!
        const prefix = email.split('@')[0];
        const parts = prefix.split(/[\._\-]/);
        let firstName = 'Rodrigue';
        let lastName = 'Dansou';
        if (parts.length >= 2) {
          firstName = parts[0].charAt(0).toUpperCase() + parts[0].slice(1).toLowerCase();
          lastName = parts.slice(1).map(p => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase()).join(' ');
        } else if (parts.length === 1) {
          firstName = parts[0].charAt(0).toUpperCase() + parts[0].slice(1).toLowerCase();
          lastName = '';
        }

        // Map French names to elegant African alternatives
        if (firstName === 'Pierre' && lastName === 'Dupont') {
          firstName = 'Rodrigue';
          lastName = 'Dansou';
        } else if (firstName === 'Lucie' && lastName === 'Laurent') {
          firstName = 'Fatoumata';
          lastName = 'Alabi';
        }

        // Determine role based on email or keywords
        let role: UserRole = 'student';
        if (email.toLowerCase().includes('grad') || email.toLowerCase().includes('diplom') || email.toLowerCase().includes('ancien')) {
          role = 'student-grad';
        } else if (email.toLowerCase().includes('dean') || email.toLowerCase().includes('admin') || email.toLowerCase().includes('dir')) {
          role = 'dean';
        } else if (email.toLowerCase().includes('teacher') || email.toLowerCase().includes('prof') || email.toLowerCase().includes('tuteur') || email.toLowerCase().includes('sessou') || email.toLowerCase().includes('encadrant')) {
          role = 'teacher';
        } else if (email.toLowerCase().includes('student') || email.toLowerCase().includes('koffi') || email.toLowerCase().includes('eleve') || email.toLowerCase().includes('houndegnon')) {
          // If the user's email specifically has e.g. "student-grad", then use role student-grad
          role = email.toLowerCase().includes('grad') ? 'student-grad' : 'student';
        } else {
          // Fallback default role
          role = 'student-grad';
        }

        // Check if there's an existing mock user of this role to inherit details from, but with the new name!
        const templateUser = allUsers.find(u => u.role === role) || allUsers[2];

        const customUser: User = {
          id: `user-custom-${Date.now()}`,
          firstName,
          lastName,
          email: email.trim(),
          role,
          details: {
            ...templateUser.details,
            studentId: role.startsWith('student') ? `2026-${firstName[0]?.toUpperCase()}${lastName[0]?.toUpperCase() || 'X'}882` : undefined,
            avatarUrl: ''
          }
        };

        onLoginSuccess(customUser);
      }
    }, 1200);
  };

  // Pre-fill helper for quick review & simulation
  const handlePrefill = (role: 'student' | 'teacher' | 'dean') => {
    if (role === 'dean') {
      setEmail('admin@uatmgasa.bj');
    } else if (role === 'teacher') {
      setEmail('arnaud.houessou@uatmgasa.bj');
    } else {
      setEmail('koffi.zannou@uatmgasa.bj');
    }
    setPassword('password123');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface p-6 relative">
      <main className="w-full max-w-[440px] flex flex-col gap-10">
        
        {/* Logo & Brand Identity */}
        <header className="flex flex-col items-center gap-2 text-center">
          <div className="w-16 h-16 bg-primary-container rounded-lg flex items-center justify-center mb-1 shadow-sm">
            <School className="text-white w-9 h-9" />
          </div>
          <h1 className="text-3xl font-bold text-primary tracking-tight">GesMemoires</h1>
          <p className="text-xs font-medium text-secondary">
            Portail académique de gestion des mémoires
          </p>
        </header>

        {/* Login Form Container */}
        <div className="bg-white rounded-lg border border-outline-variant p-10 flex flex-col gap-6 shadow-sm">
          <div className="flex flex-col gap-1">
            <h2 className="text-xl font-bold text-on-surface">Bienvenue</h2>
            <p className="text-xs text-secondary">
              Veuillez vous connecter pour accéder à votre espace.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            {/* Email Field */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="email">
                Adresse e-mail
              </label>
              <input 
                className="w-full px-4 py-3 rounded-lg border border-outline-variant bg-white text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all duration-200"
                id="email" 
                name="email" 
                placeholder="nom@uatmgasa.bj" 
                required 
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            {/* Password Field */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-on-surface-variant font-sans" htmlFor="password">
                  Mot de passe
                </label>
                <a 
                  onClick={() => alert('Option bientôt disponible')} 
                  className="text-xs font-medium text-primary hover:underline cursor-pointer"
                >
                  Mot de passe oublié ?
                </a>
              </div>
              <input 
                className="w-full px-4 py-3 rounded-lg border border-outline-variant bg-white text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all duration-200"
                id="password" 
                name="password" 
                placeholder="••••••••" 
                required 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {errorMsg && (
              <p className="text-xs font-medium text-error bg-error-container/40 p-3 rounded-lg">
                {errorMsg}
              </p>
            )}

            {/* Submit Button */}
            <button 
              className="w-full bg-primary-container hover:bg-primary text-white py-3 px-4 rounded-lg font-bold text-sm hover:opacity-95 transition-all duration-200 mt-2 flex items-center justify-center gap-2 cursor-pointer" 
              type="submit"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  Connexion en cours...
                </>
              ) : (
                'Se connecter'
              )}
            </button>
          </form>

          {/* Prefill helper boxes */}
          <div className="mt-2 border-t border-dashed border-outline-variant pt-4">
            <p className="text-[10px] font-semibold text-secondary uppercase tracking-wider mb-2 text-center">
              Comptes de test rapide
            </p>
            <div className="grid grid-cols-3 gap-1.5">
              <button 
                onClick={() => handlePrefill('student')}
                className="text-[10px] font-medium bg-surface-container-low text-primary py-1.5 px-1 rounded-md hover:bg-outline-variant/30 transition-all border border-outline-variant/50"
              >
                Étudiant
              </button>
              <button 
                onClick={() => handlePrefill('teacher')}
                className="text-[10px] font-medium bg-surface-container-low text-primary py-1.5 px-1 rounded-md hover:bg-outline-variant/30 transition-all border border-outline-variant/50"
              >
                Tuteur
              </button>
              <button 
                onClick={() => handlePrefill('dean')}
                className="text-[10px] font-medium bg-surface-container-low text-primary py-1.5 px-1 rounded-md hover:bg-outline-variant/30 transition-all border border-outline-variant/50"
              >
                Directeur
              </button>
            </div>
          </div>
        </div>

        {/* Secondary Actions & Footer */}
        <footer className="flex flex-col items-center gap-6">
          <div className="flex items-center gap-2 text-sm justify-center">
            <span className="text-secondary">Nouvel étudiant ?</span>
            <button 
              onClick={() => onNavigate('register')}
              className="font-semibold text-primary hover:underline cursor-pointer"
            >
              Créer un compte
            </button>
          </div>
          
          <div className="flex items-center gap-4 pt-4 border-t border-outline-variant w-full justify-center">
            <img 
              alt="Logo Université" 
              className="h-8 grayscale opacity-50 hover:opacity-100 transition-opacity" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFCRlyPQKMowEUUqJjX0iBNZompd4xcXKK6j_QHXVXhlKEB-LPhRVGrN4pWJAh4c20qP1VX_OwE10Y_BIpP__x0qrZyDtOmwTqd7WZiAtfPOlY4Uz5NhcDDQT3Ju-yHyr0LoqTUBiZUY22Pe5o3hPBl1K7jNkAi1N-8rVU0c-Ljyl4i8ClLtmPrXJ60xOgspht_8DOWwvaVW2jNDvOZYJVX9BkIpIv4C0__s3b0XtBt4oKUhfkXDUczYIN-rjNovhl6pVqA848xZ4" 
              referrerPolicy="no-referrer"
            />
            <div className="h-4 w-[1px] bg-outline-variant"></div>
            <p className="text-xs text-secondary font-medium">© 2026 GesMemoires</p>
          </div>
        </footer>
      </main>

      {/* Decorative top strip */}
      <div className="fixed top-0 left-0 w-full h-1 bg-primary-container"></div>
    </div>
  );
}
