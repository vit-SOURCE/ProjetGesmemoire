import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, Sparkles, X, MessageSquare, Compass, Clipboard } from 'lucide-react';
import { User } from '../types';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  text: string;
  date: string;
  isAi?: boolean;
}

interface InternalChatAndBotProps {
  currentUser: User;
  onClose: () => void;
}

export default function InternalChatAndBot({ currentUser, onClose }: InternalChatAndBotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggested academic prompt chips
  const suggestedQueries = [
    { label: "Normes de rédaction GASA", text: "Quelles sont les normes de rédaction officielles à l'UATM GASA ?" },
    { label: "Périodes de soutenance", text: "Quelle est la période officielle des soutenances de mémoire ?" },
    { label: "Méthode de validation", text: "Comment valider ou rejeter un mémoire depuis l'espace tuteur ?" },
    { label: "Aide à la formulation", text: "Aidez-moi à rédiger une note de correction constructive pour un étudiant." }
  ];

  // Load chats from LocalStorage or seed with initial messages
  useEffect(() => {
    const stored = localStorage.getItem('gm_internal_chats');
    if (stored) {
      setMessages(JSON.parse(stored));
    } else {
      const initial: ChatMessage[] = [
        {
          id: 'm1',
          senderId: 'system-ai',
          senderName: 'Direct\'IA (Co-pilote Académique)',
          senderRole: 'Assistant IA UATM GASA',
          text: 'Bienvenue dans l\'espace d\'échange Direction ↔ Enseignants de l\'UATM GASA. Je suis votre co-pilote universitaire. Posez-moi vos questions administratives, de formulation de feedback ou d\'exigences académiques.',
          date: 'Aujourd\'hui',
          isAi: true
        },
        {
          id: 'm2',
          senderId: 'user-dean',
          senderName: 'Directeur des Études (Agbodjan)',
          senderRole: 'Directeur des Études',
          text: 'Chers collègues Maîtres de mémoire, merci de finaliser vos rapports d\'examen d\'ici la fin de la semaine pour que nous puissions planifier les jurys.',
          date: 'Il y a 2 heures'
        }
      ];
      setMessages(initial);
      localStorage.setItem('gm_internal_chats', JSON.stringify(initial));
    }
  }, []);

  // Sync messages update to LocalStorage
  const saveMessages = (newMsgs: ChatMessage[]) => {
    setMessages(newMsgs);
    localStorage.setItem('gm_internal_chats', JSON.stringify(newMsgs));
  };

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isAiTyping]);

  // Handle send user message
  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const formattedRole = currentUser.role === 'dean' ? 'Directeur des Études' : 'Maître de mémoire';
    const formattedName = currentUser.role === 'dean' 
      ? `Directeur des Études (${currentUser.lastName})` 
      : `${currentUser.details?.titleOffice || 'Dr.'} ${currentUser.firstName} ${currentUser.lastName}`;

    const newMsg: ChatMessage = {
      id: `m-${Date.now()}`,
      senderId: currentUser.id,
      senderName: formattedName,
      senderRole: formattedRole,
      text: textToSend,
      date: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
    };

    const updated = [...messages, newMsg];
    saveMessages(updated);
    setInputText('');

    // Trigger Chatbot response if user asks chatbot specifically or type academic words
    const queryLower = textToSend.toLowerCase();
    const wantsAi = queryLower.includes('ia') || 
                     queryLower.includes('direct\'ia') || 
                     queryLower.includes('chatbot') || 
                     queryLower.includes('norme') || 
                     queryLower.includes('soutenance') ||
                     queryLower.includes('aide') ||
                     queryLower.includes('comment') ||
                     queryLower.includes('rédiger') ||
                     queryLower.includes('règlement');

    if (wantsAi) {
      triggerAiReply(textToSend, updated);
    }
  };

  // Chatbot logic with rich responses
  const triggerAiReply = (userQuery: string, currentList: ChatMessage[]) => {
    setIsAiTyping(true);

    setTimeout(() => {
      let responseText = "";
      const query = userQuery.toLowerCase();

      if (query.includes('norme') || query.includes('redaction') || query.includes('rédaction') || query.includes('mise en page') || query.includes('gasa')) {
        responseText = `### 📋 Normes de rédaction de mémoire officielles (UATM GASA) :\n\n` + 
                       `1. **Volume requis** : Entre **50 et 80 pages** maximum (hors bibliographie & annexes).\n` +
                       `2. **Police** : **Times New Roman**, Taille **12** pour le corps du texte (Taille 14 en gras pour les sous-sections).\n` +
                       `3. **Interligne** : **1.5**, alignement **justifié**.\n` +
                       `4. **Marges** : Gauche : 3 cm (pour reliure), Droite : 2.5 cm, Haut/Bas : 2.5 cm.\n` +
                       `5. **Structure standard** : Introduction générale, Problématique, Revue de la littérature, Approche méthodologique (avec variables), Résultats, Analyse, Recommandations, Conclusion générale, Bibliographie conforme (APA ou Harvard).`;
      } else if (query.includes('soutenance') || query.includes('date') || query.includes('periode') || query.includes('période')) {
        responseText = `### 📅 Calendrier & Soutenances de mémoire - Année 2026 :\n\n` +
                       `- **Dépôt des mémoires finalisés** : Au plus tard 15 jours avant la date de la première de soutenance.\n` +
                       `- **Période officielle des soutenances** : Du **01 juillet au 31 juillet 2026**.\n` +
                       `- **Composition du jury** : 1 Président du jury, 1 Maître de mémoire (Rapporteur), et 1 Examinateur externe habilité.\n` +
                       `- **Validation avant soutenance** : Seuls les mémoires marqués comme **Approuvés et Validés** par les encadrants dans GesMemoires peuvent être transmis au Secrétariat Général pour programmation.`;
      } else if (query.includes('comment') || query.includes('valider') || query.includes('rejeter')) {
        responseText = `### ⚙️ Procédure de validation / rejet :\n\n` +
                       `1. Connectez-vous et accédez à **"Étudiants assignés"**.\n` +
                       `2. Cliquez sur **"Lire le mémoire"** pour analyser l'extrait ou le document complet.\n` +
                       `3. Si le mémoire est conforme, cliquez sur **"Valider"**.\n` +
                       `4. Si des corrections majeures sont nécessaires, cliquez sur **"Rejeter"**, puis fournissez une justification claire. L'étudiant recevra une notification immédiate et pourra resoumettre ses corrections.`;
      } else if (query.includes('aide') || query.includes('rédiger') || query.includes('formuler') || query.includes('correction') || query.includes('constructive')) {
        responseText = `### 💡 Modèle de formulation de remarques constructives :\n\n` +
                       `*Voici un canevas pré-rédigé que vous pouvez copier-coller et adapter pour l'étudiant :*\n\n` +
                       `> "Cher(e) [Nom de l'étudiant], après lecture attentive de votre version actuelle, j'ai relevé plusieurs points à corriger avant validation :\n` +
                       `> 1. **Dans le Chapitre méthodologique** : Précisez votre échantillon (taille et critères de sélection).\n` +
                       `> 2. **Dans la Revue de littérature** : Intégrez les auteurs d'Afrique de l'Ouest pertinents sur le sujet.\n` +
                       `> 3. **Format** : Corrigez l'alignement des équations et la numérotation des tableaux.\n` +
                       `> Merci de soumettre votre version corrigée sous GesMemoires pour validation."`;
      } else {
        responseText = `### 🎓 Direct'IA - Suggestions Académiques :\n\n` +
                       `J'ai bien noté votre message concernant : *"${userQuery}"*.\n\n` +
                       `En tant que co-pilote d'UATM GASA, je vous rappelle les règles clés :\n` +
                       `- Tous les mémoires sont vérifiés contre le plagiat.\n` +
                       `- Les interactions tuteur-étudiant doivent être tracées régulièrement sur la plateforme.\n\n` +
                       `👉 Tapez **"Normes"**, **"Soutenances"** ou **"Aide rédaction"** pour des informations ciblées, ou poursuivez l'échange avec vos collègues !`;
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        senderId: 'system-ai',
        senderName: 'Direct\'IA (Co-pilote Académique)',
        senderRole: 'Assistant IA UATM GASA',
        text: responseText,
        date: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        isAi: true
      };

      saveMessages([...currentList, aiMsg]);
      setIsAiTyping(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-[110] w-full sm:w-96 bg-white shadow-2xl border-l border-outline-variant flex flex-col justify-between h-full animate-slide-right md:rounded-l-2xl">
      {/* Header */}
      <div className="p-4 bg-primary text-white flex justify-between items-center shrink-0 md:rounded-tl-2xl">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-white/10 rounded-lg">
            <Bot className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <h3 className="text-sm font-bold leading-none">Messagerie & Assistant IA</h3>
            <p className="text-[10px] text-slate-200 mt-1 font-sans">Espace direction ↔ enseignants</p>
          </div>
        </div>

        <button 
          onClick={onClose}
          className="text-white hover:text-slate-200 hover:bg-white/10 p-1.5 rounded-lg transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Suggestion box explaining the connection */}
      <div className="p-3 bg-slate-50 border-b border-slate-100 text-[10px] text-secondary leading-normal flex items-start gap-1.5 shrink-0">
        <Sparkles className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
        <span>Cet espace vous permet d'échanger directement entre Directeur des Études et Maîtres de mémoire. Posez une question au chatbot Direct'IA à tout moment ou tapez simplement votre message pour l'envoyer.</span>
      </div>

      {/* Chat Messages flow container */}
      <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-slate-50 shadow-inner">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex flex-col max-w-[85%] ${msg.senderId === currentUser.id ? 'ml-auto items-end' : 'items-start'}`}
          >
            {/* Sender identity banner */}
            <span className="text-[9px] font-bold text-secondary mb-1 uppercase tracking-wide px-1">
              {msg.senderName} ({msg.senderRole})
            </span>

            {/* Bubble content */}
            <div className={`p-3 rounded-2xl text-xs leading-normal font-sans shadow-2xs ${
              msg.senderId === currentUser.id 
                ? 'bg-primary text-white rounded-tr-none' 
                : msg.isAi 
                  ? 'bg-white text-slate-800 rounded-tl-none border-l-4 border-l-emerald-500 border border-slate-200' 
                  : 'bg-white text-slate-800 rounded-tl-none border border-slate-200'
            }`}>
              {msg.isAi ? (
                <div className="space-y-2 whitespace-pre-wrap">
                  {/* Clean formatting for Markdown titles */}
                  {msg.text.split('\n').map((line, lIdx) => {
                    if (line.startsWith('###')) {
                      return <h4 key={lIdx} className="font-bold text-primary text-xs mt-2 mb-1 border-b border-slate-100 pb-1">{line.replace('###', '')}</h4>;
                    }
                    if (line.startsWith('*') || line.startsWith('-')) {
                      return <li key={lIdx} className="ml-2 list-none text-slate-700">{line}</li>;
                    }
                    if (line.startsWith('>')) {
                      return <blockquote key={lIdx} className="border-l-2 border-slate-350 pl-2 text-secondary italic my-1 bg-slate-50/50 p-1 rounded">{line.replace('>', '')}</blockquote>;
                    }
                    return <p key={lIdx}>{line}</p>;
                  })}
                </div>
              ) : (
                <p className="whitespace-pre-wrap">{msg.text}</p>
              )}
            </div>

            {/* Time label */}
            <span className="text-[8px] text-slate-400 mt-0.5 font-medium px-1">
              {msg.date}
            </span>
          </div>
        ))}

        {/* AI Typing loader */}
        {isAiTyping && (
          <div className="flex flex-col items-start max-w-[80%]">
            <span className="text-[9px] font-bold text-secondary mb-1">Direct'IA</span>
            <div className="p-3.5 bg-white text-secondary rounded-2xl rounded-tl-none shadow-xs border border-slate-200 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce delay-100"></span>
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce delay-200"></span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested academic quick-click prompt chips sidebar drawer */}
      <div className="px-4 py-2 border-t border-slate-100 bg-white shrink-0">
        <p className="text-[9px] font-bold text-secondary uppercase tracking-wider mb-1.5 flex items-center gap-1">
          <Compass className="w-3 h-3 text-primary" />
          Suggestions Instantanées du Tuteur :
        </p>
        <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto pb-1">
          {suggestedQueries.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q.text)}
              className="text-[10px] bg-slate-100 text-slate-700 hover:bg-primary-container hover:text-white px-2.5 py-1 rounded-full text-left font-medium max-w-full truncate cursor-pointer transition-all active:scale-95 flex items-center gap-1 border border-slate-200/50"
            >
              <Sparkles className="w-2.5 h-2.5 shrink-0 text-amber-500" />
              <span>{q.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Text Message controls */}
      <div className="p-4 border-t border-outline-variant bg-white shrink-0 md:rounded-bl-2xl">
        <form 
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputText);
          }} 
          className="flex gap-2"
        >
          <input 
            type="text" 
            placeholder="Posez une question, ou discutez..." 
            className="flex-grow bg-surface border border-outline-variant rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary font-sans"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          <button 
            type="submit" 
            className="p-3 bg-primary text-white rounded-xl hover:bg-primary-container transition-all active:scale-95 cursor-pointer shadow-sm shrink-0 flex items-center justify-center"
            title="Envoyer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
