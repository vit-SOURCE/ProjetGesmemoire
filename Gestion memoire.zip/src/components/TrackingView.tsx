import React, { useState } from 'react';
import { School, ArrowLeft, Info, ZoomIn, Maximize, Download, MessageSquare, History, FileUp, X, Check, Loader2, Calendar, BookOpenText, BookOpen } from 'lucide-react';
import { Thesis, Comment, HistoryEntry } from '../types';

interface TrackingViewProps {
  thesis: Thesis;
  onBack: () => void;
  onResubmit: (notes: string, fileName: string) => void;
  onReadThesis?: (thesis: Thesis) => void;
}

export default function TrackingView({ thesis, onBack, onResubmit, onReadThesis }: TrackingViewProps) {
  const [activeTab, setActiveTab] = useState<'comments' | 'history'>('comments');
  const [showResubmitModal, setShowResubmitModal] = useState(false);
  const [resubmitNotes, setResubmitNotes] = useState('');
  const [resubmittingFile, setResubmittingFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);

  // File picker simulation
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setResubmittingFile(file);
      setUploading(true);
      setUploadProgress(0);

      let current = 0;
      const interval = setInterval(() => {
        current += Math.floor(Math.random() * 20) + 10;
        if (current >= 100) {
          current = 100;
          clearInterval(interval);
          setUploading(false);
        }
        setUploadProgress(current);
      }, 100);
    }
  };

  const executeResubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resubmittingFile || uploading) {
      alert("Veuillez sélectionner et finaliser l'upload de votre document PDF.");
      return;
    }

    setSending(true);
    setTimeout(() => {
      onResubmit(resubmitNotes, resubmittingFile.name);
      setSending(false);
      setShowResubmitModal(false);
      setResubmittingFile(null);
      setResubmitNotes('');
    }, 1500);
  };

  return (
    <div className="bg-background text-on-surface min-h-screen pb-20">
      
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-white border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2">
          <School className="text-primary w-6 h-6" />
          <span className="font-bold text-lg text-primary tracking-tight">GesMemoires</span>
        </div>
      </header>

      <main className="pt-24 pb-12 px-4 max-w-md mx-auto flex flex-col gap-6">
        
        {/* Breadcrumb Path */}
        <section className="mt-2">
          <button 
            onClick={onBack}
            className="flex items-center gap-1.5 text-secondary hover:text-primary transition-colors font-semibold text-xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour au tableau de bord
          </button>
        </section>

        {/* Document Title & Status */}
        <section className="flex flex-col gap-1">
          <div className="flex justify-between items-start gap-4">
            <h2 className="font-bold text-lg text-primary leading-tight">
              {thesis.title}
            </h2>
            {thesis.status === 'rejected' && (
              <span className="bg-error-container text-on-error-container border border-error/20 px-2.5 py-1 rounded-md text-[10px] font-bold tracking-wide uppercase flex items-center gap-1 shrink-0">
                <Info className="w-3.5 h-3.5 text-error" />
                Rejeté
              </span>
            )}
            {thesis.status === 'accepted' && (
              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200/60 px-2.5 py-1 rounded-md text-[10px] font-bold tracking-wide uppercase flex items-center gap-1 shrink-0">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Validé
              </span>
            )}
            {thesis.status === 'pending' && (
              <span className="bg-blue-50 text-blue-800 border border-blue-200/60 px-2.5 py-1 rounded-md text-[10px] font-bold tracking-wide uppercase flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-ping"></span>
                En attente
              </span>
            )}
          </div>
          <p className="text-xs text-secondary mt-1">
            Version {thesis.history[0]?.version || '2.1'} — Soumis le {thesis.history[0]?.date || '12 Oct. 2026'}
          </p>
        </section>

        {/* PDF Preview Card */}
        <section className="bg-white rounded-xl shadow-sm border border-outline-variant overflow-hidden flex flex-col">
          <div 
            onClick={() => onReadThesis && onReadThesis(thesis)}
            className="relative aspect-[3/4] bg-amber-50/70 flex flex-col cursor-pointer group hover:bg-amber-100/50 transition-all p-6 text-center border-b border-outline-variant/50"
          >
            {/* Control Bar Overlay */}
            <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity z-20 flex flex-col items-center justify-center text-white gap-2">
              <BookOpenText className="w-10 h-10 text-emerald-400 animate-bounce" />
              <span className="text-sm font-bold">Ouvrir le Lecteur Intégral</span>
              <span className="text-[10px] text-slate-300">Interactif • Chapitre par Chapitre</span>
            </div>

            <div className="absolute top-0 left-0 w-full p-3 flex justify-between items-center bg-gradient-to-b from-black/20 to-transparent z-10 text-slate-800">
              <span className="text-[10px] bg-white/85 px-2.5 py-1 rounded-md shadow-xs font-bold font-mono tracking-wide">
                DOCUMENT ORIGINAL PDF
              </span>
              <span className="text-[10px] bg-emerald-150 text-emerald-800 font-bold px-2 py-0.5 rounded-md">
                CORRECTION ACTIVE
              </span>
            </div>

            {/* Simulated Academic cover layout */}
            <div className="flex-grow flex flex-col justify-between py-6 mt-4 border border-dashed border-slate-300 rounded-lg p-4 bg-white/80">
              <div className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                UATM GASA Formation
              </div>

              <div className="space-y-2 py-4">
                <span className="bg-primary/5 text-primary text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase border border-primary/15">
                  Rapport de Master II
                </span>
                <h3 className="font-extrabold text-xs text-slate-900 uppercase leading-snug line-clamp-3">
                  "{thesis.title}"
                </h3>
              </div>

              <div className="space-y-1">
                <p className="text-[9px] text-slate-400 font-bold uppercase">Auteur :</p>
                <p className="text-xs font-extrabold text-primary uppercase">{thesis.studentName}</p>
                <p className="text-[9px] text-slate-400 font-medium">Maître de mémoire : {thesis.assignedTeacherName || 'Dr. Arnaud Houessou'}</p>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="p-4 flex justify-between items-center bg-white">
            {onReadThesis ? (
              <button 
                onClick={() => onReadThesis(thesis)}
                className="flex items-center gap-1.5 text-primary font-bold text-xs hover:underline cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-primary" />
                Lire le document complet
              </button>
            ) : (
              <button 
                onClick={() => alert('Téléchargement du document initié (simulation)...')}
                className="flex items-center gap-1 text-primary font-bold text-xs hover:underline cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Télécharger PDF
              </button>
            )}
            <button 
              onClick={() => setShowResubmitModal(true)}
              className="bg-primary text-white px-5 py-2.5 rounded-lg text-xs font-bold shadow-sm hover:bg-primary-container transition-all active:scale-95 cursor-pointer"
            >
              Resoumettre
            </button>
          </div>
        </section>

        {/* Tabs section */}
        <section>
          <div className="flex border-b border-outline-variant mb-4">
            <button 
              onClick={() => setActiveTab('comments')}
              className={`flex-1 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer text-center ${
                activeTab === 'comments' ? 'text-primary border-primary' : 'text-secondary border-transparent'
              }`}
            >
              Commentaires
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer text-center ${
                activeTab === 'history' ? 'text-primary border-primary' : 'text-secondary border-transparent'
              }`}
            >
              Historique
            </button>
          </div>

          {/* Comments Tab content */}
          {activeTab === 'comments' && (
            <div className="flex flex-col gap-3">
              {thesis.comments.length === 0 ? (
                <p className="text-xs text-secondary text-center py-6 bg-slate-50 border border-outline-variant/60 rounded-xl">
                  Aucun commentaire déposé pour le moment.
                </p>
              ) : (
                thesis.comments.map((comment) => (
                  <div key={comment.id} className="p-4 bg-surface-container-low rounded-xl border border-outline-variant/80 flex flex-col gap-2">
                    <div className="flex gap-2.5 items-center mb-1">
                      <div className="w-8 h-8 rounded-full bg-primary-container text-white flex items-center justify-center font-bold text-xs uppercase shrink-0">
                        {comment.authorName.includes('.') ? comment.authorName.split('.')[1]?.trim().slice(0, 2) : comment.authorName.slice(0, 2)}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-primary">{comment.authorName}</span>
                        <span className="text-[10px] text-secondary font-medium">{comment.date}</span>
                      </div>
                    </div>
                    <p className="text-xs text-on-surface-variant leading-relaxed mb-1 font-sans">
                      {comment.text}
                    </p>
                    <div className="flex justify-between items-center mt-1">
                      <button 
                        onClick={() => alert(`Option répondre au membre du jury`)}
                        className="text-primary font-bold text-[10px] flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        Répondre
                      </button>
                      {comment.position && (
                        <span className="text-secondary text-[10px] font-bold bg-surface-container-highest px-2 py-0.5 rounded">
                          {comment.position}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* History Tab content */}
          {activeTab === 'history' && (
            <div className="flex flex-col gap-4 py-2">
              <div className="relative pl-6 border-l-2 border-outline-variant flex flex-col gap-6 ml-3">
                {thesis.history.map((entry, idx) => (
                  <div key={entry.id} className="relative">
                    {/* Visual node */}
                    <div className={`absolute -left-[31px] top-1 w-3 h-3 rounded-full border-2 bg-white ${
                      idx === 0 
                        ? entry.status === 'rejected' ? 'border-error bg-error' : 'border-primary bg-primary'
                        : 'border-outline-variant bg-white'
                    }`}></div>

                    <div className="flex flex-col gap-1">
                      <span className={`text-[10px] font-bold tracking-wide uppercase ${
                        idx === 0 
                          ? entry.status === 'rejected' ? 'text-error' : 'text-primary'
                          : 'text-secondary'
                      }`}>
                        {entry.date} — {entry.status === 'rejected' ? 'Rejeté' : entry.status === 'accepted' ? 'Validé' : 'Soumis'}
                      </span>
                      <h4 className="text-xs font-bold text-primary">{entry.version}</h4>
                      {entry.notes && (
                        <p className="text-[11px] text-secondary italic">"{entry.notes}"</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </section>

      </main>

      {/* Slide up Task-Focused Resubmit Modal */}
      {showResubmitModal && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-end">
          <div className="w-full bg-surface rounded-t-3xl p-6 flex flex-col gap-4 shadow-2xl max-w-md mx-auto animate-slide-up">
            
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-bold text-primary">Resoumettre le mémoire</h3>
              <button 
                onClick={() => {
                  setShowResubmitModal(false);
                  setResubmittingFile(null);
                }}
                className="text-secondary hover:text-primary transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={executeResubmit} className="space-y-4">
              
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-primary">Fichier PDF</label>
                
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-outline-variant rounded-xl p-6 flex flex-col items-center justify-center gap-3 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <input 
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    type="file" 
                    accept="application/pdf" 
                    className="hidden" 
                  />
                  <FileUp className="w-10 h-10 text-primary" />
                  <p className="text-xs font-bold text-center text-primary leading-snug">
                    {resubmittingFile ? resubmittingFile.name : "Cliquez pour glisser le fichier ici"}
                  </p>
                  <p className="text-[10px] text-secondary">(Max 25Mo)</p>
                </div>
              </div>

              {/* Progress Bar */}
              {(uploading || resubmittingFile) && (
                <div className="w-full bg-outline-variant h-1 rounded-full overflow-hidden">
                  <div 
                    style={{ width: `${uploadProgress}%` }}
                    className={`h-full transition-all duration-200 ${uploading ? 'bg-primary' : 'bg-green-600'}`}
                  ></div>
                </div>
              )}

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-primary">Note de modification</label>
                <textarea 
                  required
                  rows={3}
                  className="w-full rounded-lg border border-outline-variant bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary p-3 text-xs"
                  placeholder="Quelles corrections ont été apportées ?"
                  value={resubmitNotes}
                  onChange={(e) => setResubmitNotes(e.target.value)}
                />
              </div>

              <button 
                type="submit"
                disabled={sending || uploading || !resubmittingFile}
                className="w-full bg-primary text-white py-3.5 rounded-lg text-xs font-bold shadow-sm hover:bg-primary-container active:scale-95 transition-all text-center cursor-pointer disabled:opacity-50"
              >
                {sending ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    Envoi de la révision...
                  </span>
                ) : (
                  'Envoyer la révision'
                )}
              </button>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
