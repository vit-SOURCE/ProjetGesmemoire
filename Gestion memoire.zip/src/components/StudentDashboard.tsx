import React from 'react';
import { School, Bell, Plus, User as UserIcon, History, CheckCircle, XCircle, Eye, Download, Edit, Info, FileText, ArrowRight, Home, Search as SearchIcon, ClipboardList, UserCheck } from 'lucide-react';
import { User, Thesis, ActivityLog } from '../types';

interface StudentDashboardProps {
  currentUser: User;
  theses: Thesis[];
  onNavigate: (view: string) => void;
  onSelectThesis: (thesis: Thesis) => void;
  onReadThesis?: (thesis: Thesis) => void;
  onLogout: () => void;
}

export default function StudentDashboard({ 
  currentUser, 
  theses, 
  onNavigate, 
  onSelectThesis,
  onReadThesis,
  onLogout 
}: StudentDashboardProps) {

  // Filter student's own theses
  const studentTheses = theses.filter(t => t.studentId === currentUser.details?.studentId || t.studentEmail === currentUser.email);

  return (
    <div className="bg-surface text-on-surface min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-4 md:px-6 py-4 bg-white border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2 md:gap-3">
          <School className="text-primary w-5 h-5 md:w-6 md:h-6" />
          <h1 className="font-bold text-base md:text-xl text-primary tracking-tight">GesMemoires</h1>
        </div>
        <div className="flex items-center gap-2 md:gap-4">
          <button className="text-secondary hover:bg-surface-container-low p-1.5 md:p-2 rounded-full transition-colors relative cursor-pointer">
            <Bell className="w-4 h-4 md:w-5 md:h-5" />
            <span className="absolute top-1 right-1 w-1.5 h-1.5 md:w-2 md:h-2 bg-error rounded-full"></span>
          </button>
          
          <div className="flex items-center gap-2 md:gap-3 border-l pl-2 md:pl-4 border-outline-variant">
            <div className="hidden sm:block text-right">
              <p className="text-xs font-bold text-on-surface leading-none">{currentUser.firstName} {currentUser.lastName}</p>
              <p className="text-[9px] text-secondary font-medium uppercase tracking-wider mt-1">{currentUser.role === 'student-grad' ? 'Diplômé' : 'Étudiant'}</p>
            </div>
            {currentUser.details?.avatarUrl ? (
              <img 
                alt="Profile" 
                className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-secondary-container object-cover" 
                src={currentUser.details.avatarUrl}
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-primary-container text-white flex items-center justify-center font-bold text-xs md:text-sm uppercase">
                {currentUser.firstName?.[0] || ''}{currentUser.lastName?.[0] || ''}
              </div>
            )}
            <button 
              onClick={onLogout}
              className="text-xs text-error hover:underline font-semibold cursor-pointer ml-1 md:ml-2"
            >
              Déconnexion
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="pt-24 px-6 max-w-7xl mx-auto">
        {/* Welcome Section & Main Action */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-8">
          <div className="md:col-span-8 flex flex-col justify-center">
            <h2 className="text-2xl font-bold text-primary mb-1">Bonjour, {currentUser.firstName}.</h2>
            <p className="text-sm md:text-base text-secondary leading-relaxed font-sans max-w-2xl">
              Prêt à soumettre votre nouveau travail de recherche ? Gérez vos documents et suivez vos validations en temps réel.
            </p>
          </div>
          <div className="md:col-span-4 flex items-center justify-end">
            <button 
              onClick={() => onNavigate('submit-memoir')}
              className="w-full md:w-auto bg-primary hover:bg-primary-container text-white px-6 py-3.5 rounded-xl shadow-md transition-all flex items-center justify-center gap-2.5 active:scale-95 duration-200 font-bold text-sm cursor-pointer"
            >
              <Plus className="w-5 h-5 text-white" />
              Soumettre un mémoire
            </button>
          </div>
        </div>

        {/* Bento Grid Content */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Student Profile Summary card */}
          <div className="md:col-span-4 bg-white border border-outline-variant rounded-xl p-6 shadow-sm">
            <h3 className="text-sm font-bold text-primary mb-6 flex items-center gap-2">
              <UserIcon className="text-primary w-5 h-5" />
              Informations personnelles
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-outline-variant/50 pb-2">
                <span className="text-xs font-semibold text-secondary">Numéro Étudiant</span>
                <span className="text-xs font-bold text-on-surface">
                  {currentUser.details?.studentId || `2026-${(currentUser.firstName?.[0] || 'A').toUpperCase()}${(currentUser.lastName?.[0] || 'B').toUpperCase()}882`}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-outline-variant/50 pb-2">
                <span className="text-xs font-semibold text-secondary">Faculté</span>
                <span className="text-xs font-bold text-on-surface">{currentUser.details?.faculty || 'Sciences Appliquées'}</span>
              </div>
              <div className="flex justify-between items-center border-b border-outline-variant/50 pb-2">
                <span className="text-xs font-semibold text-secondary">Cycle</span>
                <span className="text-xs font-bold text-on-surface">{currentUser.details?.cycle || 'Master II'}</span>
              </div>
              <div className="flex justify-between items-center pb-2">
                <span className="text-xs font-semibold text-secondary">Statut Global</span>
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200/50 px-3 py-0.5 rounded-full font-bold text-[10px] tracking-wide uppercase">
                  {currentUser.details?.status || 'Actif'}
                </span>
              </div>
            </div>
          </div>

          {/* Submission History card */}
          <div className="md:col-span-8 bg-white border border-outline-variant rounded-xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-sm font-bold text-primary flex items-center gap-2">
                <History className="text-primary w-5 h-5" />
                Historique des soumissions
              </h3>
              <span className="text-xs text-secondary font-medium">({studentTheses.length} document)</span>
            </div>
            {studentTheses.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-sm text-secondary mb-2">Vous n'avez soumis aucun mémoire pour le moment.</p>
                <button 
                  onClick={() => onNavigate('submit-memoir')}
                  className="text-xs font-bold text-primary hover:underline"
                >
                  Faire mon premier dépôt
                </button>
              </div>
            ) : (
              <div>
                {/* Desktop view */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left font-sans text-xs">
                    <thead className="bg-surface-container-low border-b border-outline-variant">
                      <tr>
                        <th className="px-4 py-3 font-bold text-secondary">Titre du mémoire</th>
                        <th className="px-4 py-3 font-bold text-secondary">Date</th>
                        <th className="px-4 py-3 font-bold text-secondary">Statut</th>
                        <th className="px-4 py-3 font-bold text-secondary text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-outline-variant">
                      {studentTheses.map((thesis) => (
                        <tr key={thesis.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-4 py-4 font-semibold text-primary max-w-xs truncate">
                            {thesis.title}
                          </td>
                          <td className="px-4 py-4 text-secondary">
                            {thesis.year}
                          </td>
                          <td className="px-4 py-4">
                            {thesis.status === 'accepted' && (
                              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200/60 px-2.5 py-1 rounded-md font-semibold text-[11px] inline-flex items-center gap-1">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                                Validé
                              </span>
                            )}
                            {thesis.status === 'rejected' && (
                              <span className="bg-error-container text-on-error-container border border-error/20 px-2.5 py-1 rounded-md font-semibold text-[11px] inline-flex items-center gap-1">
                                <XCircle className="w-3.5 h-3.5 text-error" />
                                Rejeté
                              </span>
                            )}
                            {thesis.status === 'pending' && (
                              <span className="bg-blue-50 text-blue-800 border border-blue-200/60 px-2.5 py-1 rounded-md font-semibold text-[11px] inline-flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                                En attente
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              {onReadThesis && (
                                <button 
                                  onClick={() => onReadThesis(thesis)}
                                  className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/50 px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer text-[11px] tracking-wide"
                                >
                                  Lire
                                </button>
                              )}
                              <button 
                                onClick={() => onSelectThesis(thesis)}
                                className="bg-primary/5 hover:bg-primary/10 text-primary px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer text-[11px] tracking-wide"
                              >
                                Suivre {thesis.comments.length > 0 && <span className="bg-error text-white text-[9px] px-1 rounded-full p-0.5 ml-1">{thesis.comments.length}</span>}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile responsive cards view */}
                <div className="block md:hidden space-y-4">
                  {studentTheses.map((thesis) => (
                    <div key={thesis.id} className="p-4 bg-slate-50 border border-slate-150 rounded-xl flex flex-col gap-3">
                      <div>
                        <h4 className="font-bold text-sm text-primary line-clamp-2 leading-snug">{thesis.title}</h4>
                        <div className="flex items-center gap-2 mt-2 text-xs text-secondary font-medium">
                          <span>Dépôt: {thesis.year}</span>
                          <span>•</span>
                          <span>Domaine: {thesis.domain}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                        {/* Status badge */}
                        <div>
                          {thesis.status === 'accepted' && (
                            <span className="bg-emerald-50 text-emerald-800 border border-emerald-200/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase inline-flex items-center gap-1">
                              Validé
                            </span>
                          )}
                          {thesis.status === 'rejected' && (
                            <span className="bg-error-container text-on-error-container border border-error/20 px-2 py-0.5 rounded text-[10px] font-bold uppercase inline-flex items-center gap-1">
                              Rejeté
                            </span>
                          )}
                          {thesis.status === 'pending' && (
                            <span className="bg-blue-50 text-blue-800 border border-blue-200/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase inline-flex items-center gap-1">
                              En cours
                            </span>
                          )}
                        </div>

                        {/* Actions buttons */}
                        <div className="flex items-center gap-2">
                          {onReadThesis && (
                            <button
                              onClick={() => onReadThesis(thesis)}
                              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-150 px-3 py-2 rounded-lg font-bold text-xs cursor-pointer min-h-[40px] flex items-center justify-center justify-items-center"
                            >
                              Lire
                            </button>
                          )}
                          <button
                            onClick={() => onSelectThesis(thesis)}
                            className="bg-primary hover:bg-primary-container text-white px-3 py-2 rounded-lg font-bold text-xs cursor-pointer min-h-[40px] flex items-center justify-center justify-items-center"
                          >
                            Suivre {thesis.comments.length > 0 && <span className="bg-white text-primary text-[9px] px-1 rounded-full p-0.5 ml-1">{thesis.comments.length}</span>}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Notifications Section */}
          <div className="md:col-span-6 bg-white border border-outline-variant rounded-xl p-6 shadow-sm">
            <h3 className="text-sm font-bold text-primary mb-6 flex items-center gap-2">
              <Bell className="text-primary w-5 h-5" />
              Dernières Notifications
            </h3>
            <div className="space-y-4">
              <div className="flex gap-4 p-3 bg-surface rounded-lg border-l-4 border-primary">
                <Info className="text-primary w-5 h-5 flex-shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-on-surface">Votre mémoire sur l'IA a été assigné à un jury.</p>
                  <span className="text-[10px] text-secondary">Il y a 2 heures</span>
                </div>
              </div>
              <div className="flex gap-4 p-3 hover:bg-slate-50 rounded-lg transition-colors border-l-4 border-transparent">
                <FileText className="text-secondary w-5 h-5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-on-surface font-medium">Le guide académique de rédaction 2026 est disponible au téléchargement.</p>
                  <span className="text-[10px] text-secondary">Hier</span>
                </div>
              </div>
            </div>
          </div>

          {/* Public Archive Redirect */}
          <div 
            onClick={() => onNavigate('landing')}
            className="md:col-span-6 bg-tertiary-container text-white rounded-xl p-6 shadow-sm relative overflow-hidden group cursor-pointer flex flex-col justify-between"
          >
            <div>
              <h3 className="text-lg font-bold text-tertiary-fixed mb-2">Explorer la Bibliothèque</h3>
              <p className="text-xs text-on-primary-container leading-relaxed">
                Consultez les mémoires publics et travaux de recherche validés par nos jurys pour vous inspirer et faire avancer votre projet académique.
              </p>
            </div>
            <div className="mt-8 flex items-center gap-2 text-tertiary-fixed font-semibold text-xs transition-colors group-hover:text-white">
              Accéder aux mémoires publics
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </div>
          </div>

        </div>
      </main>



      {/* Mobile Navigation Bottom bar */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-50 flex justify-around items-center bg-white border-t border-outline-variant py-2 shadow-lg h-16">
        <button onClick={() => onNavigate('landing')} className="flex flex-col items-center text-secondary">
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-1">Home</span>
        </button>
        <button onClick={() => {}} className="flex flex-col items-center text-secondary">
          <SearchIcon className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-1">Search</span>
        </button>
        <button onClick={() => onNavigate('student-dashboard')} className="flex flex-col items-center text-primary">
          <ClipboardList className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-1">Portail</span>
        </button>
      </nav>
    </div>
  );
}
