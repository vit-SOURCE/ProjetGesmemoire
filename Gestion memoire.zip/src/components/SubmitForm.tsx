import React, { useState, useRef } from 'react';
import { School, ArrowLeft, UploadCloud, FileText, Check, ShieldCheck, Lock, History as HistoryIcon, Loader2 } from 'lucide-react';
import { Thesis } from '../types';

interface SubmitFormProps {
  onBack: () => void;
  onSubmitSuccess: (newThesis: { title: string; domain: string; year: number; fileName: string }) => void;
}

export default function SubmitForm({ onBack, onSubmitSuccess }: SubmitFormProps) {
  const [title, setTitle] = useState('');
  const [domain, setDomain] = useState('');
  const [year, setYear] = useState(2026);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    if (file.type !== 'application/pdf') {
      alert('Veuillez sélectionner un fichier PDF uniquement.');
      return;
    }
    setUploadedFile(file);
    setUploadProgress(0);
    setUploading(true);

    // Simulate upload timer
    let current = 0;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 20) + 10;
      if (current >= 100) {
        current = 100;
        clearInterval(interval);
        setUploading(false);
      }
      setUploadProgress(current);
    }, 150);
  };

  const triggerSelect = () => {
    fileInputRef.current?.click();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !domain || !uploadedFile || uploading) {
      alert("Veuillez remplir toutes les informations et attendre la fin du téléchargement.");
      return;
    }

    setSubmitting(true);
    setTimeout(() => {
      onSubmitSuccess({
        title,
        domain,
        year,
        fileName: uploadedFile.name
      });
      setSubmitting(false);
    }, 1500);
  };

  return (
    <div className="bg-surface text-on-background min-h-screen pb-20">
      
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-white border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2">
          <School className="text-primary w-6 h-6" />
          <span className="font-bold text-lg text-primary tracking-tight">GesMemoires</span>
        </div>
      </header>

      <main className="pt-24 px-6 max-w-[800px] mx-auto">
        {/* Navigation path */}
        <nav className="mb-6">
          <button 
            onClick={onBack}
            className="flex items-center gap-1.5 text-secondary hover:text-primary transition-colors font-semibold text-xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour au tableau de bord
          </button>
        </nav>

        {/* Header Section */}
        <section className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-1.5">Soumission de mémoire</h1>
          <p className="text-xs md:text-sm text-secondary leading-relaxed">
            Veuillez remplir les informations requises et téléverser votre document final au format PDF.
          </p>
        </section>

        {/* Form panel */}
        <div className="bg-white rounded-xl shadow-sm border border-outline-variant p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5 md:col-span-2">
                <label className="text-xs font-semibold text-on-surface" htmlFor="title">
                  Titre du mémoire
                </label>
                <input 
                  required
                  className="bg-white border border-outline-variant rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all placeholder:text-outline"
                  id="title" 
                  placeholder="Ex: Analyse de l'impact de l'IA sur la recherche académique" 
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-on-surface" htmlFor="domain">
                  Domaine d'étude
                </label>
                <select 
                  required
                  className="bg-white border border-outline-variant rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all cursor-pointer"
                  id="domain"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                >
                  <option value="" disabled>Sélectionnez un domaine</option>
                  <option value="Informatique">Informatique</option>
                  <option value="Économie">Économie</option>
                  <option value="Médecine">Médecine</option>
                  <option value="Droit">Droit</option>
                  <option value="Architecture Durable">Architecture Durable</option>
                  <option value="Finance">Finance</option>
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-on-surface" htmlFor="year">
                  Année académique
                </label>
                <input 
                  required
                  className="bg-white border border-outline-variant rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
                  id="year" 
                  type="number" 
                  min="2020" 
                  max="2030"
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                />
              </div>
            </div>

            {/* Document upload region */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-on-surface">
                Document du mémoire (PDF uniquement)
              </label>
              
              <div 
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={triggerSelect}
                className="border-2 border-dashed border-outline-variant rounded-xl p-8 flex flex-col items-center justify-center gap-4 transition-all cursor-pointer hover:border-primary hover:bg-slate-50 group text-center"
              >
                <input 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="application/pdf"
                  className="hidden" 
                  type="file" 
                />
                <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center group-hover:bg-primary transition-all duration-300">
                  <UploadCloud className="text-primary group-hover:text-white w-6 h-6 transition-all" />
                </div>
                <div>
                  <p className="text-sm font-bold text-primary leading-tight">Glissez-déposez votre fichier ici</p>
                  <p className="text-xs text-secondary mt-1">ou cliquez pour parcourir vos dossiers</p>
                </div>
                <span className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 bg-surface-container-high rounded-full text-secondary">
                  PDF Max 50Mo
                </span>
              </div>
            </div>

            {/* Progress Section */}
            {(uploading || uploadedFile) && (
              <div className="space-y-2 bg-surface-container-low p-4 rounded-lg">
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center gap-2">
                    <FileText className="text-primary w-4 h-4 flex-shrink-0" />
                    <span className="font-semibold text-primary truncate max-w-[260px]">
                      {uploadedFile?.name || 'document.pdf'}
                    </span>
                  </div>
                  <span className="font-bold text-secondary">
                    {uploading ? `${uploadProgress}%` : 'Téléchargement terminé'}
                  </span>
                </div>
                <div className="w-full bg-outline-variant h-1.5 rounded-full overflow-hidden">
                  <div 
                    style={{ width: `${uploadProgress}%` }}
                    className={`h-full transition-all duration-200 ${uploading ? 'bg-primary' : 'bg-emerald-600'}`}
                  ></div>
                </div>
              </div>
            )}

            {/* Form actions */}
            <div className="flex flex-col md:flex-row items-center justify-end gap-3 pt-6 border-t border-outline-variant">
              <button 
                onClick={onBack}
                type="button"
                className="w-full md:w-auto px-6 py-2.5 font-semibold text-xs text-secondary bg-surface-container-high rounded-lg hover:bg-slate-200 transition-colors cursor-pointer text-center"
              >
                Annuler
              </button>
              <button 
                type="submit"
                disabled={submitting || uploading || !uploadedFile}
                className="w-full md:w-auto px-8 py-2.5 font-semibold text-xs text-white bg-primary rounded-lg shadow-sm hover:bg-primary-container transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    Envoi en cours...
                  </>
                ) : (
                  'Envoyer le mémoire'
                )}
              </button>
            </div>

          </form>
        </div>

        {/* Guidelines info */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 font-sans">
          <div className="flex items-start gap-3 p-2">
            <ShieldCheck className="text-primary w-5 h-5 flex-shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-primary">Intégrité académique</h4>
              <p className="text-[11px] text-secondary leading-relaxed mt-0.5">Vérification automatique de similitudes et de plagiat dès réception.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-2">
            <Lock className="text-primary w-5 h-5 flex-shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-primary">Confidentialité</h4>
              <p className="text-[11px] text-secondary leading-relaxed mt-0.5">Vos documents de recherche sont stockés de façon sécurisée sur l'espace institutionnel.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-2">
            <HistoryIcon className="text-primary w-5 h-5 flex-shrink-0" />
            <div>
              <h4 className="text-xs font-bold text-primary">Suivi direct</h4>
              <p className="text-[11px] text-secondary leading-relaxed mt-0.5">Notification immédiate quand votre tuteur annote ou valide une section.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
