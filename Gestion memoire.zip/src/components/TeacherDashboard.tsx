import React, { useState } from 'react';
import { School, Bell, Search, Filter, Edit3, CheckCircle, XCircle, Info, History, ArrowRight, Loader2, Home, Users, UserCheck, BookOpen, MessageSquare } from 'lucide-react';
import { Thesis, Comment, User } from '../types';
import InternalChatAndBot from './InternalChatAndBot';

interface TeacherDashboardProps {
  currentUser: User;
  theses: Thesis[];
  onNavigate: (view: string) => void;
  onUpdateThesis: (id: string, updatedParams: Partial<Thesis>) => void;
  onReadThesis?: (thesis: Thesis) => void;
  onLogout: () => void;
}

export default function TeacherDashboard({ 
  currentUser, 
  theses, 
  onNavigate, 
  onUpdateThesis,
  onReadThesis,
  onLogout 
}: TeacherDashboardProps) {

  // Rejection panels state
  const [activeRejectionId, setActiveRejectionId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeCommentThesisId, setActiveCommentThesisId] = useState<string | null>(null);
  const [newCommentText, setNewCommentText] = useState('');

  // Stats
  const teacherTheses = theses.filter(t => t.assignedTeacherId === currentUser.id);
  const totalStudents = teacherTheses.length + 9; // Show 12 like mockup
  const pendingCount = teacherTheses.filter(t => t.status === 'pending').length + 3; // Show 04 like mockup
  const defendedCount = 5;
  const validationRate = "82%";

  const handleValidate = (id: string, studentName: string) => {
    onUpdateThesis(id, { status: 'accepted' });
    alert(`Le mémoire de ${studentName} a été validé avec succès.`);
  };

  const handleRejectSubmit = (id: string, studentName: string) => {
    if (!rejectionReason.trim()) {
      alert("La justification du rejet est requise.");
      return;
    }

    const newComment: Comment = {
      id: `c_rej_${Date.now()}`,
      authorName: `Dr. ${currentUser.lastName}`,
      authorRole: 'Maître de mémoire',
      date: "Aujourd'hui, à " + new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      text: rejectionReason
    };

    const targetThesis = theses.find(t => t.id === id);
    const existingComments = targetThesis ? [...targetThesis.comments] : [];

    onUpdateThesis(id, {
      status: 'rejected',
      comments: [newComment, ...existingComments]
    });

    alert(`Le mémoire de ${studentName} a été rejeté avec la correction demandée.`);
    setActiveRejectionId(null);
    setRejectionReason('');
  };

  const filteredTheses = teacherTheses.filter(t => 
    t.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    t.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-background text-on-surface min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-4 md:px-6 py-4 bg-white border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2 md:gap-3">
          <School className="text-primary w-5 h-5 md:w-6 md:h-6" />
          <h1 className="font-bold text-base md:text-xl text-primary tracking-tight">GesMemoires</h1>
        </div>
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 hover:bg-slate-100 rounded-lg text-xs font-bold text-primary border border-primary/20 transition-all cursor-pointer relative"
            title="Messagerie Interne & Chatbot"
          >
            <MessageSquare className="w-4 h-4 text-primary" />
            <span className="hidden sm:inline">Bot & Chat</span>
            <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
          </button>

          <button className="text-secondary hover:bg-surface-container-low p-1.5 md:p-2 rounded-full transition-colors relative cursor-pointer">
            <Bell className="w-4 h-4 md:w-5 md:h-5" />
            <span className="absolute top-1 right-1 w-1.5 h-1.5 md:w-2 md:h-2 bg-error rounded-full"></span>
          </button>
          
          <div className="flex items-center gap-2 md:gap-3 border-l pl-2 md:pl-4 border-outline-variant">
            <div className="hidden sm:block text-right">
              <span className="text-xs font-bold text-on-surface">Dr. {currentUser.lastName}</span>
            </div>
            {currentUser.details?.avatarUrl ? (
              <img 
                alt="Profile" 
                className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-secondary-container object-cover" 
                src={currentUser.details.avatarUrl}
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-primary-container text-white flex items-center justify-center font-bold text-xs md:text-sm uppercase">
                {currentUser.firstName?.[0] || ''}{currentUser.lastName?.[0] || ''}
              </div>
            )}
            <button 
              onClick={onLogout}
              className="text-xs text-error hover:underline font-semibold cursor-pointer ml-1 md:ml-2"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main content body */}
      <main className="pt-24 px-6 max-w-7xl mx-auto">
        
        {/* Header Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-primary mb-1.5">Tableau de bord Enseignant</h2>
          <p className="text-sm text-secondary leading-relaxed max-w-2xl font-sans">
            Gestion et suivi des travaux de recherche des étudiants sous votre supervision. Validez les étapes ou demandez des corrections.
          </p>
        </section>

        {/* Stats Grid */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <span className="text-[10px] font-bold tracking-wider text-secondary uppercase">Total Étudiants</span>
            <span className="text-3xl font-bold text-primary mt-2">{totalStudents}</span>
          </div>
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between border-l-4 border-l-primary">
            <span className="text-[10px] font-bold tracking-wider text-secondary uppercase">En attente</span>
            <span className="text-3xl font-bold text-primary mt-2">04</span>
          </div>
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <span className="text-[10px] font-bold tracking-wider text-secondary uppercase">Soutenus</span>
            <span className="text-3xl font-bold text-primary mt-2">0{defendedCount}</span>
          </div>
          <div className="bg-white p-5 rounded-xl border border-outline-variant shadow-sm flex flex-col justify-between">
            <span className="text-[10px] font-bold tracking-wider text-secondary uppercase">Taux Validation</span>
            <span className="text-3xl font-bold text-primary mt-2">{validationRate}</span>
          </div>
        </section>

        {/* Student List Container */}
        <section className="bg-white rounded-xl border border-outline-variant shadow-sm overflow-hidden">
          
          {/* List Toolbar header */}
          <div className="p-6 border-b border-outline-variant flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h3 className="font-bold text-lg text-primary">Étudiants assignés</h3>
            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="relative flex-grow md:flex-grow-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-secondary w-4 h-4" />
                <input 
                  type="text"
                  placeholder="Rechercher un étudiant..."
                  className="pl-9 pr-4 py-2 bg-surface border border-outline-variant rounded-lg text-xs w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button className="flex items-center gap-1 px-4 py-2 bg-secondary-container text-on-surface rounded-lg text-xs font-semibold hover:bg-outline-variant transition-colors cursor-pointer">
                <Filter className="w-3.5 h-3.5" />
                Filtres
              </button>
            </div>
          </div>

          {/* List entries */}
          <div className="divide-y divide-outline-variant bg-white min-h-[250px]">
            {filteredTheses.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-xs text-secondary">Aucun étudiant trouvé ou assigné.</p>
              </div>
            ) : (
              filteredTheses.map((thesis) => (
                <div key={thesis.id} className="p-6 hover:bg-slate-50 transition-colors duration-200">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="flex items-start gap-4">
                      {thesis.studentAvatar ? (
                        <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 shadow-sm border border-outline-variant">
                          <img 
                            className="w-full h-full object-cover" 
                            src={thesis.studentAvatar} 
                            alt={thesis.studentName}
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-surface-container-high text-primary flex items-center justify-center font-bold text-sm flex-shrink-0">
                          {thesis.studentName.slice(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <h4 className="font-bold text-sm text-primary tracking-tight">{thesis.studentName}</h4>
                        <p className="text-xs text-secondary leading-snug font-sans mt-0.5 max-w-xl">{thesis.title}</p>
                        
                        <div className="mt-3.5">
                          {thesis.status === 'pending' && (
                            <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-800 text-[10px] font-semibold tracking-wider border border-blue-200 uppercase">
                              {thesis.submissionNotes || "Version 2.0 pour review"}
                            </span>
                          )}
                          {thesis.status === 'accepted' && (
                            <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-semibold tracking-wider border border-emerald-200 uppercase flex items-center gap-1 w-fit">
                              <CheckCircle className="w-3 h-3 text-emerald-600" />
                              Approuvé & Validé
                            </span>
                          )}
                          {thesis.status === 'rejected' && (
                            <div className="flex items-center gap-1.5 text-error font-semibold text-[10px] uppercase">
                              <History className="w-3.5 h-3.5" />
                              <span>Rejeté - En attente de correction</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Direct action panel */}
                    <div className="flex flex-wrap items-center gap-2">
                      {onReadThesis && (
                        <button 
                          onClick={() => onReadThesis(thesis)}
                          className="flex items-center gap-1.5 px-4 py-2 bg-emerald-50 text-emerald-800 border border-emerald-200/50 rounded-lg text-xs font-semibold hover:bg-emerald-100/90 active:scale-95 transition-all cursor-pointer"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          Lire le mémoire
                        </button>
                      )}

                      <button 
                        onClick={() => {
                          setActiveRejectionId(null);
                          if (activeCommentThesisId === thesis.id) {
                            setActiveCommentThesisId(null);
                          } else {
                            setActiveCommentThesisId(thesis.id);
                            setNewCommentText('');
                          }
                        }}
                        className="flex items-center gap-1 px-4 py-2 bg-white border border-outline-variant text-on-surface rounded-lg text-xs font-semibold hover:bg-slate-50 active:scale-95 transition-all cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Annoter
                      </button>

                      {thesis.status === 'pending' ? (
                        <>
                          <button 
                            onClick={() => handleValidate(thesis.id, thesis.studentName)}
                            className="flex items-center gap-1 px-4 py-2 bg-primary text-white rounded-lg text-xs font-semibold hover:bg-primary/95 active:scale-95 transition-all cursor-pointer shadow-sm"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            Valider
                          </button>
                          <button 
                            onClick={() => {
                              if (activeRejectionId === thesis.id) {
                                setActiveRejectionId(null);
                              } else {
                                setActiveRejectionId(thesis.id);
                                setRejectionReason('');
                              }
                            }}
                            className="flex items-center gap-1 px-4 py-2 bg-error text-white rounded-lg text-xs font-semibold hover:bg-error/95 active:scale-95 transition-all cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            Rejeter
                          </button>
                        </>
                      ) : (
                        <button 
                          onClick={() => {
                            if (thesis.comments.length > 0) {
                              alert(`Raison du statut: "${thesis.comments[0].text}"`);
                            } else {
                              alert(`Le document est dans le statut : ${thesis.status}`);
                            }
                          }}
                          className="flex items-center gap-1 px-4 py-2 bg-slate-100 text-on-surface rounded-lg text-xs font-semibold hover:bg-slate-200 transition-all cursor-pointer"
                        >
                          <Info className="w-3.5 h-3.5" />
                          Historique
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Expandable Rejection Panel */}
                  {activeRejectionId === thesis.id && (
                    <div className="mt-4 p-4 bg-error-container/20 rounded-lg border border-error/10 flex flex-col gap-3">
                      <label className="text-xs font-bold text-on-error-container" htmlFor={`rej-${thesis.id}`}>
                        Justification du rejet (Requis)
                      </label>
                      <textarea 
                        id={`rej-${thesis.id}`}
                        rows={3}
                        className="w-full p-3 bg-white border border-error/20 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-error/20 focus:border-error"
                        placeholder="Précisez les points à corriger pour l'étudiant (ex: revoir la section 2.3)..."
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                      />
                      <div className="flex justify-end gap-2.5">
                        <button 
                          onClick={() => setActiveRejectionId(null)}
                          className="px-4 py-2 text-secondary hover:text-primary text-xs font-semibold cursor-pointer"
                        >
                          Annuler
                        </button>
                        <button 
                          onClick={() => handleRejectSubmit(thesis.id, thesis.studentName)}
                          className="px-4 py-2 bg-error text-white rounded-md text-xs font-semibold cursor-pointer shadow-sm hover:opacity-95"
                        >
                          Confirmer le rejet
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Expandable Commenting Panel */}
                  {activeCommentThesisId === thesis.id && (
                    <div className="mt-4 p-5 bg-slate-50 rounded-xl border border-outline-variant flex flex-col gap-4 animate-fadeIn font-sans">
                      <h4 className="text-xs font-bold text-primary flex items-center gap-1">
                        <span>Commentaires de correction sur ce mémoire ({thesis.comments ? thesis.comments.length : 0})</span>
                      </h4>
                      
                      {(!thesis.comments || thesis.comments.length === 0) ? (
                        <p className="text-xs text-secondary italic">Aucun commentaire de correction déposé.</p>
                      ) : (
                        <div className="space-y-2 mt-1 max-h-48 overflow-y-auto pr-1">
                          {thesis.comments.map(c => (
                            <div key={c.id} className="p-3 bg-white rounded-lg border border-slate-100 text-xs text-left">
                              <div className="flex justify-between text-[10px] font-bold text-secondary uppercase mb-1">
                                <span>{c.authorName} ({c.authorRole})</span>
                                <span>{c.date}</span>
                              </div>
                              <p className="text-slate-700">{c.text}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <form 
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (!newCommentText.trim()) return;
                          
                          const newComment = {
                            id: `c_teach_${Date.now()}`,
                            authorName: `Dr. ${currentUser.lastName}`,
                            authorRole: 'Maître de mémoire',
                            date: "Aujourd'hui, à " + new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
                            text: newCommentText
                          };
                          
                          onUpdateThesis(thesis.id, {
                            comments: [newComment, ...(thesis.comments || [])]
                          });
                          alert("Avis de correction enregistré avec succès.");
                          setNewCommentText('');
                          setActiveCommentThesisId(null);
                        }}
                        className="mt-2"
                      >
                        <label className="block text-[10px] font-bold text-secondary uppercase mb-1 text-left">Ajouter une annotation / consigne de correction :</label>
                        <div className="flex gap-2">
                          <input 
                            type="text"
                            placeholder="Entrez vos consignes pour la modification de l'étudiant..."
                            className="flex-grow p-2.5 border border-outline-variant rounded-lg text-xs bg-white focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary font-sans"
                            value={newCommentText}
                            onChange={(e) => setNewCommentText(e.target.value)}
                            required
                          />
                          <button 
                            type="submit"
                            className="bg-primary text-white text-xs font-bold px-4 py-2.5 rounded-lg hover:bg-primary-container active:scale-95 transition-all cursor-pointer shadow-sm shrink-0"
                          >
                            Enregistrer
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                </div>
              ))
            )}
          </div>

        </section>

      </main>



      {/* Shared bottom navigation bar for mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-50 flex justify-around items-center bg-white border-t border-outline-variant py-2 shadow-lg h-16">
        <button onClick={() => onNavigate('landing')} className="flex flex-col items-center text-secondary">
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-1">Home</span>
        </button>
        <button className="flex flex-col items-center text-primary">
          <Users className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-1">Dashboard</span>
        </button>
      </nav>

      {isChatOpen && (
        <InternalChatAndBot 
          currentUser={currentUser} 
          onClose={() => setIsChatOpen(false)} 
        />
      )}
    </div>
  );
}
