import React, { useState } from 'react';
import { School, CheckCircle2, Award, User, Users, ArrowRight, Loader2, ArrowLeft } from 'lucide-react';
import { UserRole } from '../types';

interface RegisterStep2Props {
  onBack: () => void;
  onSubmit: (role: UserRole) => void;
}

export default function RegisterStep2({ onBack, onSubmit }: RegisterStep2Props) {
  const [selectedRole, setSelectedRole] = useState<UserRole>('student-grad');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onSubmit(selectedRole);
      setLoading(false);
    }, 1200);
  };

  return (
    <div className="bg-surface text-on-surface min-h-screen flex flex-col">
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-surface border-b border-outline-variant shadow-sm h-16">
        <div className="flex items-center gap-2">
          <School className="text-primary w-6 h-6" />
          <h1 className="font-bold text-lg text-primary tracking-tight">GesMemoires</h1>
        </div>
      </header>

      <main className="flex-grow pt-24 pb-16 px-6 max-w-7xl mx-auto w-full flex flex-col items-center justify-center">
        {/* Progress indicator */}
        <div className="w-full max-w-3xl mb-10">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-secondary font-semibold uppercase">Étape 2 de 2</span>
            <span className="text-xs text-primary font-bold">Identification du profil</span>
          </div>
          <div className="w-full h-1 bg-surface-container-highest rounded-full overflow-hidden">
            <div className="h-full bg-primary-container w-full transition-all duration-300"></div>
          </div>
        </div>

        {/* Title & guidance */}
        <section className="text-center mb-10">
          <h2 className="text-3xl font-bold text-primary tracking-tight mb-2">Quel est votre rôle ?</h2>
          <p className="text-sm md:text-base text-secondary max-w-xl mx-auto leading-relaxed">
            Choisissez le profil qui correspond le mieux à votre situation actuelle pour personnaliser votre expérience institutionnelle.
          </p>
        </section>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="w-full max-w-3xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            
            {/* Card 1: Graduate Student */}
            <div 
              onClick={() => setSelectedRole('student-grad')}
              className={`relative cursor-pointer bg-white border rounded-xl p-6 flex flex-col items-center text-center group transition-all duration-300 ${
                selectedRole === 'student-grad' 
                  ? 'border-primary bg-slate-50 shadow-md translate-y-[-4px]' 
                  : 'border-outline-variant hover:border-outline-variant/80 hover:translate-y-[-2px]'
              }`}
            >
              <div className={`absolute top-4 right-4 transition-opacity ${selectedRole === 'student-grad' ? 'opacity-100' : 'opacity-0'}`}>
                <CheckCircle2 className="w-5 h-5 text-primary fill-primary/10" />
              </div>
              <div className="w-16 h-16 rounded-full bg-surface-container-low flex items-center justify-center mb-6 group-hover:bg-primary-fixed transition-colors">
                <Award className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg text-primary mb-2">Etudiant diplômé</h3>
              <p className="text-xs text-secondary leading-relaxed">
                Pour les anciens étudiants souhaitant consulter leurs archives, rapports ou collaborer.
              </p>
            </div>

            {/* Card 2: Student */}
            <div 
              onClick={() => setSelectedRole('student')}
              className={`relative cursor-pointer bg-white border rounded-xl p-6 flex flex-col items-center text-center group transition-all duration-300 ${
                selectedRole === 'student' 
                  ? 'border-primary bg-slate-50 shadow-md translate-y-[-4px]' 
                  : 'border-outline-variant hover:border-outline-variant/80 hover:translate-y-[-2px]'
              }`}
            >
              <div className={`absolute top-4 right-4 transition-opacity ${selectedRole === 'student' ? 'opacity-100' : 'opacity-0'}`}>
                <CheckCircle2 className="w-5 h-5 text-primary fill-primary/10" />
              </div>
              <div className="w-16 h-16 rounded-full bg-surface-container-low flex items-center justify-center mb-6 group-hover:bg-primary-fixed transition-colors">
                <User className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg text-primary mb-2">Etudiant non diplômé</h3>
              <p className="text-xs text-secondary leading-relaxed">
                Pour les étudiants en cours de cursus préparant leur projet de fin d'études.
              </p>
            </div>

            {/* Card 3: Advisor/Teacher */}
            <div 
              onClick={() => setSelectedRole('teacher')}
              className={`relative cursor-pointer bg-white border rounded-xl p-6 flex flex-col items-center text-center group transition-all duration-300 ${
                selectedRole === 'teacher' 
                  ? 'border-primary bg-slate-50 shadow-md translate-y-[-4px]' 
                  : 'border-outline-variant hover:border-outline-variant/80 hover:translate-y-[-2px]'
              }`}
            >
              <div className={`absolute top-4 right-4 transition-opacity ${selectedRole === 'teacher' ? 'opacity-100' : 'opacity-0'}`}>
                <CheckCircle2 className="w-5 h-5 text-primary fill-primary/10" />
              </div>
              <div className="w-16 h-16 rounded-full bg-surface-container-low flex items-center justify-center mb-6 group-hover:bg-primary-fixed transition-colors">
                <Users className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg text-primary mb-2">Maître de mémoire</h3>
              <p className="text-xs text-secondary leading-relaxed">
                Pour les enseignants et encadrants académiques gérant et guidant les recherches.
              </p>
            </div>

          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 max-w-3xl mx-auto border-t border-outline-variant pt-6">
            <button 
              onClick={onBack}
              type="button"
              className="px-6 py-3 font-semibold text-xs text-secondary hover:bg-surface-container-low rounded-lg transition-all cursor-pointer flex items-center gap-1"
            >
              <ArrowLeft className="w-4 h-4" />
              Retour à l'étape précédente
            </button>
            <button 
              type="submit"
              disabled={loading}
              className="w-full md:w-auto bg-primary-container text-white text-xs font-semibold px-8 py-3.5 rounded-lg shadow-sm hover:bg-primary transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  Validation...
                </>
              ) : (
                <>
                  Valider mon inscription
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      </main>

      <footer className="mt-12 py-6 px-6 bg-surface-container-low border-t border-outline-variant">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-secondary font-medium">
          <div className="flex items-center gap-2">
            <School className="text-outline w-5 h-5" />
            <p>© 2026 GesMemoires - Portail Universitaire de Recherche</p>
          </div>
          <nav className="flex gap-4">
            <a href="#" className="hover:text-primary transition-colors">Confidentialité</a>
            <a href="#" className="hover:text-primary transition-colors">Support Académique</a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
